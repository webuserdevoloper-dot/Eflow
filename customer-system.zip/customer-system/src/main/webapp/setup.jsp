<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="true" %>
<%-- CustomerFlow Setup UI — POSTs to /setup (SetupServlet) which writes to SQLite. --%>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>System Setup - CustomerFlow v3.2</title>
<!-- v3.11: OFFLINE MODE — all assets bundled locally -->
<link href="assets/css/google-fonts.css" rel="stylesheet">
<link rel="stylesheet" href="assets/css/font-awesome.min.css">
<style>
:root{--bg:#0a0e1a;--bg-elevated:#131826;--surface:#181f31;--surface-hover:#1f2839;--border:#232b3d;--border-light:#2d374e;--text:#fff;--text-muted:#a1a1aa;--text-dim:#71717a;--primary:#6366f1;--primary-glow:#818cf8;--accent:#f59e0b;--accent-glow:#fbbf24;--success:#10b981;}
*{box-sizing:border-box;margin:0;padding:0;}
body{font-family:'Plus Jakarta Sans',sans-serif;background:var(--bg);color:var(--text);display:flex;justify-content:center;align-items:center;min-height:100vh;background-image:radial-gradient(ellipse at top,rgba(99,102,241,0.10) 0%,transparent 55%),radial-gradient(ellipse at bottom right,rgba(245,158,11,0.08) 0%,transparent 55%),radial-gradient(ellipse at bottom left,rgba(6,182,212,0.06) 0%,transparent 55%);}
.setup-card{background:linear-gradient(180deg,rgba(255,255,255,0.02) 0%,transparent 100%),var(--bg-elevated);border:1px solid var(--border-light);border-radius:24px;padding:2.5rem;width:100%;max-width:520px;box-shadow:0 40px 100px -20px rgba(0,0,0,0.9),inset 0 1px 0 rgba(255,255,255,0.06);margin:1rem;}
.brand-row{display:flex;align-items:center;gap:0.75rem;justify-content:center;margin-bottom:0.5rem;}
.brand-icon{width:48px;height:48px;border-radius:14px;background:linear-gradient(135deg,var(--primary),var(--accent));display:flex;align-items:center;justify-content:center;box-shadow:0 8px 24px -6px var(--primary);font-size:1.4rem;color:#fff;}
h1{font-family:'Bricolage Grotesque',sans-serif;font-size:1.7rem;margin-bottom:0.4rem;text-align:center;letter-spacing:-0.02em;}
.subtitle{text-align:center;color:var(--text-dim);font-size:0.85rem;margin-bottom:1.5rem;}
.info-box{background:var(--bg);border:1px solid var(--border);border-radius:14px;padding:1rem;margin-bottom:1.5rem;font-size:0.75rem;color:var(--text-muted);line-height:1.7;}
.info-box strong{color:var(--text);}
.info-box code{background:var(--border-light);color:var(--primary-glow);padding:0.15rem 0.45rem;border-radius:5px;font-size:0.72rem;}
.info-box .stack{display:flex;flex-wrap:wrap;gap:0.4rem;margin-top:0.6rem;}
.info-box .tag{display:inline-flex;align-items:center;gap:0.3rem;padding:0.25rem 0.6rem;border-radius:6px;font-size:0.7rem;font-weight:700;}
.tag-sqlite{background:rgba(16,185,129,0.12);border:1px solid rgba(16,185,129,0.3);color:#34d399;}
.tag-tomcat{background:rgba(99,102,241,0.12);border:1px solid rgba(99,102,241,0.3);color:#818cf8;}
.tag-maven{background:rgba(245,158,11,0.12);border:1px solid rgba(245,158,11,0.3);color:#fbbf24;}
.tag-jdbc{background:rgba(14,165,233,0.12);border:1px solid rgba(14,165,233,0.3);color:#7dd3fc;}
label{display:block;font-size:0.7rem;font-weight:700;color:var(--text-dim);margin-bottom:0.4rem;text-transform:uppercase;letter-spacing:0.06em;}
input{width:100%;background:rgba(255,255,255,0.02);border:1px solid var(--border);color:var(--text);border-radius:12px;padding:0.8rem 1rem;font-size:0.9375rem;margin-bottom:1rem;font-family:inherit;transition:border-color 0.2s,box-shadow 0.2s;}
input:focus{outline:none;border-color:var(--primary);box-shadow:0 0 0 3px rgba(99,102,241,0.15);}
button{width:100%;padding:0.95rem;border-radius:12px;background:linear-gradient(to right,var(--primary),var(--accent));color:white;font-weight:800;font-size:1rem;border:none;cursor:pointer;transition:transform 0.15s,box-shadow 0.2s;margin-top:0.5rem;}
button:hover{transform:translateY(-1px);box-shadow:0 12px 28px -8px rgba(99,102,241,0.5);}
button:active{transform:translateY(0);}
.section-divider{border-top:1px solid var(--border);margin:1rem 0 1.25rem;padding-top:1rem;}
.section-title{font-size:0.8rem;font-weight:700;color:var(--text);margin-bottom:0.85rem;display:flex;align-items:center;gap:0.5rem;}
.section-title i{color:var(--primary-glow);}
.floor-list{background:var(--bg);border:1px solid var(--border);border-radius:12px;padding:0.75rem;font-size:0.7rem;color:var(--text-dim);margin-top:0.5rem;line-height:1.6;}
.floor-list strong{color:var(--text-muted);}
</style>
</head>
<body>
<div class="setup-card">
<div class="brand-row"><div class="brand-icon"><i class="fas fa-people-group"></i></div></div>
<h1>Initial System Setup</h1>
<p class="subtitle" style="color:var(--accent-glow);font-weight:700;font-size:0.7rem;letter-spacing:0.1em;text-transform:uppercase;margin-top:-0.5rem;margin-bottom:1rem;">✦ Onyx Pro Edition · v3.2</p>
<p class="subtitle">Configure CustomerFlow for first use</p>

<div class="info-box">
<strong><i class="fas fa-database" style="color:#34d399;margin-right:0.3rem;"></i>CustomerFlow v3.2 — Onyx Pro</strong><br>
SQLite database file: <code>C:/CustomerFlow/customerflow.db</code><br>
<strong>Auto-backup:</strong> Daily at 02:00 (time-based, server-side timer)<br>
<strong>Retention:</strong> auto-delete after 10 days
<div class="stack">
<span class="tag tag-tomcat"><i class="fas fa-server"></i> Tomcat 10.1+</span>
<span class="tag tag-maven"><i class="fas fa-cube"></i> Maven</span>
<span class="tag tag-jdbc"><i class="fas fa-plug"></i> JDBC</span>
<span class="tag tag-sqlite"><i class="fas fa-database"></i> SQLite</span>
<span class="tag" style="background:rgba(99,102,241,0.12);border:1px solid rgba(99,102,241,0.3);color:#818cf8;"><i class="fas fa-bolt"></i> v3.2 Onyx Pro</span>
</div>
</div>

<form action="setup" method="POST">
<label>Default Floor PIN (User Password)</label>
<input type="text" name="defaultPin" value="2003" required>

<div class="section-divider">
<div class="section-title"><i class="fas fa-shield-halved"></i> Security Passwords</div>
</div>

<label>Admin Login Password</label>
<input type="text" name="admin" value="Eadmin@3377" required>
<label>Dashboard Login Password</label>
<input type="text" name="dashboard" value="Elive" required>
<label>Password Manager Access Code</label>
<input type="text" name="passMgr" value="2200" required>
<label>Floor Management Password</label>
<input type="text" name="floorMgmt" value="Efloor@3377" required>
<label>Backup Password</label>
<input type="text" name="backup" value="Ebackup@3377" required>
<label>Clear Data Password</label>
<input type="text" name="clear" value="Eclear@3377" required>
<label>HO/Branch Connection Password</label>
<input type="text" name="ho" value="EHO@3377" required>

<button type="submit"><i class="fas fa-bolt"></i> &nbsp;Create Database &amp; Setup System</button>
</form>

<div class="floor-list">
<strong>Default floors (16):</strong> SST-BASEMENT, SST-GROUND-F-FRONT/BACK, SST-1ST to 5TH, ELITE-BASEMENT to 3RD, DIAMOND-FRONT/BACK-ENTRANCE
</div>
</div>
</body>
</html>
