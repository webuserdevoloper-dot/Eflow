<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="true" %>
<%-- CustomerFlow 3.5 — Onyx Pro | Maven + Tomcat + JDBC + SQLite --%>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no">
<title>Customer-System</title>
<!-- Favicon: set dynamically from company logo in settings (see applyBrandUI) -->
<link id="favicon-link" rel="icon" type="image/x-icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Crect width='100' height='100' rx='20' fill='%236366f1'/%3E%3Ctext x='50' y='65' font-size='50' text-anchor='middle' fill='white' font-family='Arial' font-weight='bold'%3EC%3C/text%3E%3C/svg%3E">
<link rel="apple-touch-icon" id="apple-touch-icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Crect width='100' height='100' rx='20' fill='%236366f1'/%3E%3Ctext x='50' y='65' font-size='50' text-anchor='middle' fill='white' font-family='Arial' font-weight='bold'%3EC%3C/text%3E%3C/svg%3E">
<!-- v3.11: OFFLINE MODE — all assets bundled locally (no CDN, no internet needed) -->
<script src="assets/js/tailwind.js"></script>
<link href="assets/css/google-fonts.css" rel="stylesheet">
<link rel="stylesheet" href="assets/css/font-awesome.min.css">
<script src="assets/js/jspdf.umd.min.js"></script>
<script src="assets/js/jspdf.plugin.autotable.min.js"></script>
<script src="assets/js/xlsx.full.min.js"></script>
<style>
:root{--bg:#0a0e1a;--bg-elevated:#131826;--surface:#181f31;--surface-hover:#1f2839;--border:#232b3d;--border-light:#2d374e;--text:#e2e8f0;--text-muted:#94a3b8;--text-dim:#64748b;--primary:#6366f1;--primary-glow:#818cf8;--primary-rgb:99,102,241;--success:#10b981;--success-glow:#34d399;--danger:#ef4444;--danger-glow:#f87171;--warning:#f59e0b;--warning-glow:#fbbf24;--accent:#f59e0b;--accent-glow:#fbbf24;--accent-rgb:245,158,11;--entry-neon:#06b6d4;--entry-glow:#22d3ee;--exit-neon:#f59e0b;--exit-glow:#fbbf24;--info:#0ea5e9;--info-glow:#38bdf8;}
*{-webkit-tap-highlight-color:transparent;box-sizing:border-box;touch-action:manipulation;}
html,body{background:var(--bg);color:var(--text);font-family:'Plus Jakarta Sans',sans-serif;overflow-x:hidden;min-height:100vh;margin:0;padding-bottom:40px;-webkit-font-smoothing:antialiased;}
.font-display{font-family:'Bricolage Grotesque',sans-serif;letter-spacing:-0.02em;}
.screen{position:relative;min-height:100vh;z-index:10;}.screen.hidden{display:none;}
.ambient-bg{position:fixed;inset:0;pointer-events:none;z-index:0;background:radial-gradient(ellipse 80% 50% at 20% 0%,rgba(99,102,241,0.08),transparent 60%),radial-gradient(ellipse 60% 50% at 80% 100%,rgba(245,158,11,0.06),transparent 60%),radial-gradient(ellipse 50% 30% at 50% 50%,rgba(6,182,212,0.04),transparent 70%);}
@keyframes neon-pulse{0%{box-shadow:0 0 10px var(--primary),0 0 20px var(--primary),inset 0 0 10px var(--primary)}50%{box-shadow:0 0 20px var(--primary-glow),0 0 40px var(--primary-glow),inset 0 0 15px var(--primary-glow)}100%{box-shadow:0 0 10px var(--primary),0 0 20px var(--primary),inset 0 0 10px var(--primary)}}
.login-container{min-height:100vh;display:flex;align-items:center;justify-content:center;padding:1rem;}
.login-card{width:100%;max-width:420px;background:var(--bg-elevated);border:1px solid var(--border-light);border-radius:24px;padding:2.5rem;box-shadow:0 30px 80px -20px rgba(0,0,0,0.8),inset 0 1px 0 rgba(255,255,255,0.1);position:relative;}
/* === V3.1 ONYX PRO — NEW LOGIN + GLASS NAV === */
.v3-login-wrap{display:flex;width:100%;max-width:920px;min-height:560px;border-radius:28px;overflow:hidden;box-shadow:0 50px 120px -30px rgba(0,0,0,0.9);border:1px solid var(--border-light);}
.v3-login-hero{flex:1;position:relative;background:linear-gradient(135deg,#0a0e1a 0%,#1e1b4b 30%,#0c1a2e 70%,#0a0e1a 100%);display:flex;align-items:center;justify-content:center;padding:3rem 2.5rem;overflow:hidden;}
.v3-hero-glow{position:absolute;inset:0;background:radial-gradient(circle at 30% 30%,rgba(99,102,241,0.3),transparent 50%),radial-gradient(circle at 70% 70%,rgba(245,158,11,0.2),transparent 50%);animation:onyx-shift 8s ease-in-out infinite alternate;}
@keyframes onyx-shift{0%{transform:scale(1) rotate(0deg);}100%{transform:scale(1.2) rotate(5deg);}}
.v3-hero-content{position:relative;z-index:2;text-align:center;color:#f8fafc;}
.v3-hero-badge{display:inline-flex;align-items:center;gap:0.4rem;padding:0.35rem 0.9rem;border-radius:20px;background:rgba(255,255,255,0.1);backdrop-filter:blur(10px);border:1px solid rgba(255,255,255,0.15);font-size:0.7rem;font-weight:700;color:#818cf8;text-transform:uppercase;letter-spacing:0.05em;margin-bottom:1.5rem;}
.v3-hero-title{font-size:2.8rem;font-weight:800;line-height:1.1;margin-bottom:0.5rem;background:linear-gradient(135deg,#818cf8,#fbbf24);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;}
.v3-hero-sub{font-size:0.85rem;color:rgba(255,255,255,0.6);margin-bottom:2rem;}
.v3-hero-feats{display:flex;flex-direction:column;gap:0.75rem;align-items:flex-start;}
.v3-feat{display:flex;align-items:center;gap:0.6rem;font-size:0.8rem;color:rgba(255,255,255,0.8);padding:0.5rem 0.9rem;border-radius:10px;background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.08);}
.v3-feat i{color:#fbbf24;width:18px;text-align:center;}
.v3-login-card{width:400px;flex-shrink:0;background:var(--bg-elevated);padding:3rem 2.5rem;display:flex;flex-direction:column;justify-content:center;}
.v3-login-header{text-align:center;margin-bottom:2rem;}
.v3-login-logo{width:64px;height:64px;border-radius:18px;display:flex;align-items:center;justify-content:center;margin:0 auto 1rem;box-shadow:0 12px 30px -8px var(--primary);}
.v3-btn-primary{width:100%;padding:0.95rem;border-radius:12px;background:linear-gradient(135deg,var(--primary),var(--accent));color:white;font-weight:800;font-size:0.95rem;border:none;cursor:pointer;transition:transform 0.2s,box-shadow 0.2s;display:flex;align-items:center;justify-content:center;}
.v3-btn-primary:hover{transform:translateY(-2px);box-shadow:0 12px 28px -6px rgba(99,102,241,0.5);}
.v3-btn-primary:active{transform:translateY(0);}
@media(max-width:768px){.v3-login-wrap{flex-direction:column;max-width:420px;min-height:auto;}.v3-login-hero{padding:2.5rem 1.5rem;}.v3-hero-title{font-size:2rem;}.v3-login-card{width:100%;padding:2rem 1.5rem;}}
.minimal-top-bar{background:rgba(7,9,15,0.8) !important;backdrop-filter:blur(20px) saturate(180%);-webkit-backdrop-filter:blur(20px) saturate(180%);}
.admin-sidebar{background:rgba(7,9,15,0.85) !important;backdrop-filter:blur(20px);-webkit-backdrop-filter:blur(20px);}
.nav-item.active{background:linear-gradient(90deg,rgba(99,102,241,0.12),transparent) !important;color:var(--primary) !important;}
.nav-item.active::before{background:var(--primary) !important;}
.input-field{width:100%;background:var(--bg);border:1px solid var(--border);color:var(--text);border-radius:12px;padding:0.875rem 1rem;font-size:1rem;transition:border-color 0.2s;font-family:inherit;color-scheme:dark;}
.input-field:focus{outline:none;border-color:var(--primary);box-shadow:0 0 0 2px rgba(99,102,241,0.2);}
.custom-select{position:relative;}
.select-options{position:absolute;top:100%;left:0;right:0;margin-top:0.5rem;background:var(--bg-elevated);border:1px solid var(--border-light);border-radius:12px;max-height:250px;overflow-y:auto;z-index:200;display:none;box-shadow:0 20px 40px rgba(0,0,0,0.5);}
.select-options.active{display:block;}
.select-option{padding:0.875rem 1rem;cursor:pointer;font-size:0.875rem;border-radius:8px;margin:0.25rem;}
.select-option:hover{background:var(--surface-hover);}
.home-main{min-height:100vh;display:flex;flex-direction:column;justify-content:center;align-items:center;padding:6rem 1rem 2rem;}
.top-dashboard-card{width:100%;max-width:900px;display:flex;justify-content:center;align-items:center;gap:0.5rem;background:var(--bg-elevated);border:1px solid var(--border);border-radius:20px;padding:1.5rem 1rem;margin-bottom:2.5rem;}
.count-item{flex:1;display:flex;flex-direction:column;align-items:center;gap:0.25rem;min-width:0;}
.count-label{font-size:0.65rem;font-weight:700;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.05em;text-align:center;}
.count-value{font-family:'Bricolage Grotesque',sans-serif;font-weight:800;font-size:2.25rem;line-height:1;transition:transform 0.2s;}
.entry-count .count-value{color:var(--entry-glow);text-shadow:0 0 30px var(--entry-neon);}
.exit-count .count-value{color:var(--exit-glow);text-shadow:0 0 30px var(--exit-neon);}
.in-store-count .count-value{color:var(--accent);text-shadow:0 0 30px var(--accent);}
.divider{width:1px;height:40px;background:var(--border-light);flex-shrink:0;}
.home-grid{display:grid;grid-template-columns:1fr 1fr;gap:1rem;width:100%;max-width:900px;padding:0 1rem;}
.home-box{position:relative;overflow:hidden;cursor:pointer;border-radius:24px;padding:2rem 1rem;transition:transform 0.2s,border-color 0.3s;background:var(--surface);border:1px solid var(--border);min-height:220px;display:flex;flex-direction:column;justify-content:center;align-items:center;text-align:center;}
.home-box:active{transform:scale(0.98);}
.home-box.entry{--accent-color:var(--entry-neon)}.home-box.exit{--accent-color:var(--exit-neon)}
.home-box-icon{width:64px;height:64px;border-radius:20px;display:flex;align-items:center;justify-content:center;margin-bottom:1rem;font-size:2rem;}
.home-box.entry .home-box-icon{background:rgba(14,165,233,0.15);border:1px solid var(--entry-neon);box-shadow:0 0 20px rgba(14,165,233,0.3);}
.home-box.exit .home-box-icon{background:rgba(16,185,129,0.15);border:1px solid var(--exit-neon);box-shadow:0 0 20px rgba(16,185,129,0.3);}
.home-box-icon i{font-size:2rem;}.home-box.entry .home-box-icon i{color:var(--entry-glow);}.home-box.exit .home-box-icon i{color:var(--exit-glow);}
.home-box-title{font-family:'Bricolage Grotesque',sans-serif;font-weight:800;font-size:1.2rem;}
.home-box.entry .home-box-title{color:var(--entry-glow);}.home-box.exit .home-box-title{color:var(--exit-glow);}
@media(min-width:640px){.top-dashboard-card{gap:1rem;padding:2rem;}.count-value{font-size:3.5rem;}.divider{height:60px;}.home-grid{gap:1.5rem;padding:0;}.home-box{padding:3.5rem 2rem;min-height:300px;border-radius:28px;}.home-box-icon{width:88px;height:88px;border-radius:24px;margin-bottom:1.75rem;}.home-box-icon i{font-size:2.5rem;}.home-box-title{font-size:clamp(1.5rem,3vw,2rem);}}
/* === v3.1 HOME DASHBOARD LAYOUT (matches user's dashboard image) === */
.home-dashboard-layout{display:flex;min-height:100vh;position:relative;z-index:1;}
.home-sidebar{width:250px;flex-shrink:0;background:rgba(10,14,26,0.9);backdrop-filter:blur(20px);-webkit-backdrop-filter:blur(20px);border-right:1px solid var(--border);display:flex;flex-direction:column;position:fixed;left:0;top:0;height:100vh;z-index:40;overflow-y:auto;}
.home-sidebar-brand{padding:1.5rem 1.25rem;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:0.75rem;}
.home-brand-icon{width:40px;height:40px;border-radius:12px;background:linear-gradient(135deg,var(--primary),var(--accent));display:flex;align-items:center;justify-content:center;box-shadow:0 8px 20px -5px var(--primary);overflow:hidden;flex-shrink:0;}
.home-brand-icon img{width:100%;height:100%;object-fit:cover;}
.home-brand-text{font-family:'Bricolage Grotesque',sans-serif;font-weight:800;font-size:1rem;color:var(--text);line-height:1.1;}
.home-floor-label{font-size:0.65rem;color:var(--accent-glow);font-weight:700;text-transform:uppercase;letter-spacing:0.08em;margin-top:2px;}
.home-sidebar-nav{flex:1;padding:1rem 0.75rem;overflow-y:auto;}
.home-nav-item{display:flex;align-items:center;gap:0.75rem;padding:0.75rem 1rem;border-radius:10px;color:var(--text-muted);cursor:pointer;transition:all 0.2s;margin-bottom:0.25rem;font-weight:600;font-size:0.875rem;border:1px solid transparent;}
.home-nav-item:hover{background:var(--surface-hover);color:var(--text);}
.home-nav-item.active{background:linear-gradient(135deg,rgba(99,102,241,0.18),rgba(99,102,241,0.08));color:var(--primary-glow);border-color:rgba(99,102,241,0.3);box-shadow:inset 0 0 0 1px rgba(99,102,241,0.2);}
.home-nav-item i{width:20px;text-align:center;font-size:1rem;}
.home-sidebar-footer{padding:1rem 1.25rem;border-top:1px solid var(--border);}
.home-db-status{background:rgba(16,185,129,0.08);border:1px solid rgba(16,185,129,0.3);border-radius:12px;padding:0.75rem;margin-bottom:1rem;}
.home-db-status-header{display:flex;align-items:center;gap:0.5rem;font-size:0.75rem;font-weight:700;color:#34d399;}
.home-db-status-header i{font-size:0.85rem;}
.home-db-path{font-size:0.6rem;color:var(--text-dim);margin-top:0.35rem;word-break:break-all;font-family:monospace;}
.home-sidebar-actions{display:flex;align-items:center;gap:0.5rem;}
.home-sidebar-actions .sync-indicator{flex:1;font-size:0.65rem;padding:0.35rem 0.5rem;}
.home-emp-btn{width:34px;height:34px;border-radius:8px;background:var(--surface);border:1px solid var(--border-light);color:var(--text-muted);cursor:pointer;display:flex;align-items:center;justify-content:center;flex-shrink:0;}
.home-emp-btn:hover{background:var(--surface-hover);color:var(--text);}
.home-logout-btn{width:34px;height:34px;border-radius:8px;background:rgba(239,68,68,0.1);border:1px solid rgba(239,68,68,0.3);color:#f87171;cursor:pointer;display:flex;align-items:center;justify-content:center;flex-shrink:0;}
.home-logout-btn:hover{background:rgba(239,68,68,0.2);color:var(--danger);}
.home-main-content{flex:1;padding:2rem 2.5rem;margin-left:250px;width:calc(100% - 250px);max-width:calc(100% - 250px);}
.home-view{display:none;}
.home-view.active{display:block;animation:fade-in 0.3s ease;}
@keyframes fade-in{from{opacity:0;transform:translateY(8px);}to{opacity:1;transform:translateY(0);}}
.home-kpi-row{display:grid;grid-template-columns:repeat(3,1fr);gap:1rem;margin-bottom:1.5rem;}
.home-kpi-card{background:var(--surface);border:1px solid var(--border);border-radius:16px;padding:1.5rem;position:relative;overflow:hidden;transition:transform 0.2s,box-shadow 0.2s;}
.home-kpi-card:hover{transform:translateY(-2px);}
.home-kpi-card.kpi-entries{border-color:rgba(99,102,241,0.3);box-shadow:0 0 24px -8px rgba(99,102,241,0.3),inset 0 1px 0 rgba(255,255,255,0.04);}
.home-kpi-card.kpi-instore{border-color:rgba(245,158,11,0.3);box-shadow:0 0 24px -8px rgba(245,158,11,0.3),inset 0 1px 0 rgba(255,255,255,0.04);}
.home-kpi-card.kpi-exits{border-color:rgba(16,185,129,0.3);box-shadow:0 0 24px -8px rgba(16,185,129,0.3),inset 0 1px 0 rgba(255,255,255,0.04);}
.home-kpi-top{display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:0.75rem;}
.home-kpi-label{font-size:0.65rem;font-weight:700;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.08em;}
.home-kpi-icon{font-size:1rem;opacity:0.5;}
.kpi-entries .home-kpi-icon{color:var(--primary-glow);}
.kpi-instore .home-kpi-icon{color:var(--accent-glow);}
.kpi-exits .home-kpi-icon{color:var(--success-glow);}
.home-kpi-value{font-family:'Bricolage Grotesque',sans-serif;font-weight:800;font-size:2.5rem;line-height:1;}
.kpi-entries .home-kpi-value{color:var(--primary-glow);text-shadow:0 0 20px rgba(99,102,241,0.4);}
.kpi-instore .home-kpi-value{color:var(--accent-glow);text-shadow:0 0 20px rgba(245,158,11,0.4);}
.kpi-exits .home-kpi-value{color:var(--success-glow);text-shadow:0 0 20px rgba(16,185,129,0.4);}
.home-chart-card{background:var(--surface);border:1px solid var(--border);border-radius:16px;padding:1.5rem;margin-bottom:1.5rem;}
.home-chart-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:1.25rem;}
.home-chart-header h3{font-family:'Bricolage Grotesque',sans-serif;font-weight:700;font-size:1.1rem;color:var(--text);}
.home-chart-sub{font-size:0.75rem;color:var(--text-dim);font-weight:400;}
.home-live-badge{display:inline-flex;align-items:center;gap:0.35rem;padding:0.25rem 0.6rem;border-radius:20px;background:rgba(16,185,129,0.1);border:1px solid rgba(16,185,129,0.3);font-size:0.65rem;font-weight:700;color:#34d399;text-transform:uppercase;letter-spacing:0.05em;}
.home-live-dot{width:6px;height:6px;border-radius:50%;background:#10b981;animation:pulse-sync 2s infinite;box-shadow:0 0 6px #10b981;}
.home-chart-body{height:180px;display:flex;flex-direction:column;justify-content:flex-end;}
.home-chart-bars{display:flex;align-items:flex-end;gap:4px;height:150px;}
.home-chart-bar{flex:1;background:linear-gradient(180deg,var(--primary-glow),var(--primary));border-radius:4px 4px 0 0;min-height:4px;transition:opacity 0.2s;position:relative;cursor:pointer;}
.home-chart-bar:hover{opacity:0.8;}
.home-chart-bar:hover::after{content:attr(data-tooltip);position:absolute;bottom:100%;left:50%;transform:translateX(-50%);background:var(--bg-elevated);border:1px solid var(--border-light);color:var(--text);padding:0.25rem 0.5rem;border-radius:6px;font-size:0.65rem;white-space:nowrap;margin-bottom:4px;z-index:10;}
.home-chart-labels{display:flex;gap:4px;margin-top:0.5rem;}
.home-chart-label{flex:1;text-align:center;font-size:0.55rem;color:var(--text-dim);}
.home-bottom-row{display:grid;grid-template-columns:1fr 1fr;gap:1rem;}
.home-panel{background:var(--surface);border:1px solid var(--border);border-radius:16px;padding:1.25rem;display:flex;flex-direction:column;}
.home-panel-full{background:var(--surface);border:1px solid var(--border);border-radius:16px;padding:1.25rem;}
.home-panel-header{display:flex;align-items:center;gap:0.5rem;margin-bottom:1rem;}
.home-panel-header i{color:var(--primary-glow);font-size:1rem;}
.home-panel-header h4{font-family:'Bricolage Grotesque',sans-serif;font-weight:700;font-size:0.95rem;color:var(--text);}
.home-chat-messages{flex:1;max-height:200px;overflow-y:auto;display:flex;flex-direction:column;gap:0.5rem;}
.home-chat-full{max-height:60vh;}
.home-chat-msg{padding:0.6rem 0.85rem;border-radius:10px;font-size:0.8rem;}
.home-chat-msg.msg-admin{background:rgba(99,102,241,0.1);border-left:3px solid var(--primary);}
.home-chat-msg.msg-floor{background:rgba(245,158,11,0.1);border-left:3px solid var(--accent);}
.home-chat-msg .msg-sender{font-weight:700;font-size:0.7rem;margin-bottom:0.2rem;}
.home-chat-msg.msg-admin .msg-sender{color:var(--primary-glow);}
.home-chat-msg.msg-floor .msg-sender{color:var(--accent-glow);}
.home-chat-msg .msg-text{color:var(--text);}
.home-chat-msg .msg-time{font-size:0.6rem;color:var(--text-dim);margin-top:0.25rem;}
.home-call-content{flex:1;display:flex;align-items:center;justify-content:center;min-height:120px;}
.home-empty-state{color:var(--text-dim);font-size:0.85rem;text-align:center;padding:2rem 1rem;}
.home-call-active{display:flex;flex-direction:column;align-items:center;gap:0.75rem;width:100%;}
.home-call-caller{font-family:'Bricolage Grotesque',sans-serif;font-weight:800;font-size:1.1rem;color:var(--success-glow);}
.home-call-status{font-size:0.75rem;color:var(--text-muted);}
.home-call-end-btn{width:52px;height:52px;border-radius:50%;background:linear-gradient(135deg,#ef4444,#dc2626);border:none;color:white;font-size:1.2rem;cursor:pointer;box-shadow:0 4px 16px -2px rgba(239,68,68,0.5);transition:transform 0.2s;margin-top:0.5rem;}
.home-call-end-btn:hover{transform:scale(1.05);}
.home-call-pulse{width:12px;height:12px;border-radius:50%;background:#10b981;animation:pulse-sync 1.5s infinite;box-shadow:0 0 8px #10b981;}
.home-settings-content{padding:1rem 0;}
@media(max-width:1024px){.home-main-content{padding:1.5rem;}}
@media(max-width:768px){
  .home-dashboard-layout{flex-direction:column;}
  .home-sidebar{width:100%;height:auto;position:relative;left:auto;top:auto;z-index:50;border-right:none;border-bottom:1px solid var(--border);overflow-y:visible;}
  .home-sidebar-brand{padding:1rem;}
  .home-sidebar-nav{display:flex;gap:0.5rem;overflow-x:auto;padding:0.75rem 1rem;}
  .home-nav-item{flex-shrink:0;margin-bottom:0;padding:0.5rem 0.75rem;font-size:0.75rem;}
  .home-nav-item span{display:none;}
  .home-sidebar-footer{display:none;}
  .home-main-content{padding:1.25rem;width:100%;max-width:100%;margin-left:0;}
  .home-kpi-row{grid-template-columns:1fr;}
  .home-bottom-row{grid-template-columns:1fr;}
  .home-kpi-value{font-size:2rem;}
}
.minimal-top-bar{position:fixed;top:0;left:0;right:0;z-index:20;display:flex;justify-content:space-between;align-items:center;padding:1.25rem 1.5rem;background:var(--bg);border-bottom:1px solid var(--border);}
.brand-mark{display:flex;align-items:center;gap:0.75rem;}
.brand-icon{width:36px;height:36px;border-radius:10px;background:linear-gradient(135deg,var(--primary),var(--accent));display:flex;align-items:center;justify-content:center;box-shadow:0 8px 20px -5px var(--primary);overflow:hidden;}
.brand-icon img{width:100%;height:100%;object-fit:cover;}
.brand-text{font-family:'Bricolage Grotesque',sans-serif;font-weight:800;font-size:1.125rem;}
.sync-indicator{display:flex;align-items:center;gap:0.5rem;padding:0.4rem 0.75rem;border-radius:8px;background:var(--surface);border:1px solid var(--border);font-size:0.7rem;font-weight:700;text-transform:uppercase;}
/* v3.12: Signal Strength Badge — local SVG icon, live on both screens */
.signal-strength-badge{display:flex;align-items:center;gap:0.4rem;padding:0.35rem 0.65rem;border-radius:8px;background:var(--surface);border:1px solid var(--border);font-size:0.65rem;font-weight:700;}
.signal-strength-badge .signal-icon{width:18px;height:18px;flex-shrink:0;}
.signal-strength-badge .signal-text{font-size:0.65rem;font-weight:700;white-space:nowrap;}
.sig-bar{opacity:0.2;transition:opacity 0.3s;}
.sig-bar.active{opacity:1;}
.sig-bar-1.active{color:#ef4444;}
.sig-bar-2.active{color:#f59e0b;}
.sig-bar-3.active{color:#10b981;}
.sig-bar-4.active{color:#10b981;}
.sig-bar-5.active{color:#10b981;}
.signal-strength-badge.connected{border-color:rgba(16,185,129,0.3);background:rgba(16,185,129,0.08);}
.signal-strength-badge.connected .signal-text{color:#34d399;}
.signal-strength-badge.weak{border-color:rgba(245,158,11,0.3);background:rgba(245,158,11,0.08);}
.signal-strength-badge.weak .signal-text{color:#fbbf24;}
.signal-strength-badge.offline{border-color:rgba(239,68,68,0.3);background:rgba(239,68,68,0.08);}
.signal-strength-badge.offline .signal-text{color:#f87171;}
@media(max-width:480px){.signal-strength-badge{padding:0.25rem 0.4rem;gap:0.25rem;}.signal-strength-badge .signal-icon{width:14px;height:14px;}.signal-strength-badge .signal-text{font-size:0.55rem;}}
.sync-dot{width:8px;height:8px;border-radius:50%;animation:pulse-sync 2s infinite;}
.sync-dot.online{background:var(--success);box-shadow:0 0 10px var(--success);}.sync-dot.offline{background:#f59e0b;box-shadow:0 0 10px #f59e0b;}
@keyframes pulse-sync{0%,100%{opacity:1}50%{opacity:0.4}}
.admin-access-btn{display:flex;align-items:center;gap:0.5rem;padding:0.625rem 1rem;border-radius:10px;background:var(--surface);border:1px solid var(--border-light);color:var(--text-muted);font-size:0.875rem;font-weight:600;cursor:pointer;}
.admin-access-btn:hover{background:var(--surface-hover);color:var(--text);border-color:var(--text-dim);}
.admin-icon-btn{display:flex;align-items:center;justify-content:center;width:40px;height:40px;border-radius:10px;background:linear-gradient(135deg,#ef4444,#dc2626);border:1px solid rgba(239,68,68,0.4);color:white;font-size:1rem;cursor:pointer;box-shadow:0 4px 12px -2px rgba(239,68,68,0.5);transition:transform 0.2s;}
.admin-icon-btn:hover{transform:scale(1.05);}
.admin-icon-btn:active{transform:scale(0.95);}
.logout-btn{background:rgba(239,68,68,0.1);border-color:rgba(239,68,68,0.3);color:#f87171;}
.logout-btn:hover{background:rgba(239,68,68,0.2);border-color:var(--danger);color:var(--danger);}
@media(max-width:480px){.minimal-top-bar{padding:0.75rem 0.5rem;}.brand-text{font-size:0.85rem;}.brand-icon{width:28px;height:28px;}.sync-indicator{padding:0.25rem 0.4rem;font-size:0.6rem;gap:0.25rem;}.admin-access-btn{padding:0.4rem 0.6rem;font-size:0.75rem;gap:0.25rem;}.admin-access-btn span{display:none;}.admin-icon-btn{width:34px;height:34px;font-size:0.875rem;}}
.admin-layout{display:flex;min-height:100vh;position:relative;z-index:1;}
.admin-sidebar{width:290px;flex-shrink:0;background:var(--bg);border-right:1px solid var(--border);display:flex;flex-direction:column;position:fixed;left:0;top:0;height:100vh;z-index:40;overflow-y:auto;}
.sidebar-brand{padding:1.5rem;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:0.75rem;}
.sidebar-nav{flex:1;padding:1rem;overflow-y:auto;}
.nav-label{font-size:0.7rem;font-weight:700;text-transform:uppercase;letter-spacing:0.1em;color:var(--text-dim);padding:0 0.75rem;margin-bottom:0.75rem;}
.nav-item{display:flex;align-items:center;gap:0.875rem;padding:0.875rem 1rem;border-radius:12px;color:var(--text-muted);cursor:pointer;transition:background 0.2s;margin-bottom:0.25rem;font-weight:600;font-size:0.875rem;border:1px solid transparent;position:relative;}
.nav-item:active{background:var(--surface-hover);color:var(--text);}
.nav-item.active{background:linear-gradient(90deg,rgba(99,102,241,0.1),transparent);color:var(--primary);border-color:var(--border-light);}
.nav-item.active::before{content:'';position:absolute;left:0;top:50%;transform:translateY(-50%);width:4px;height:60%;background:var(--primary);border-radius:0 4px 4px 0;}
.nav-item i{width:20px;text-align:center;font-size:1rem;}
.sidebar-footer{padding:1rem 1.5rem;border-top:1px solid var(--border);}
.exit-admin-btn{width:100%;padding:0.875rem;border-radius:12px;background:var(--surface);border:1px solid var(--border-light);color:var(--text-muted);font-weight:600;font-size:0.875rem;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:0.5rem;}
.exit-admin-btn:active{background:rgba(239,68,68,0.1);border-color:var(--danger);color:var(--danger);}
.admin-main{flex:1;padding:2rem 2.5rem;width:calc(100% - 290px);max-width:calc(100% - 290px);margin-left:290px;}
.admin-header{display:flex;justify-content:space-between;align-items:flex-end;margin-bottom:2.5rem;flex-wrap:wrap;gap:1rem;border-bottom:1px solid var(--border);padding-bottom:1.5rem;}
.admin-header h1{font-weight:800;text-decoration:underline;text-decoration-color:var(--primary);text-underline-offset:6px;font-family:'Bricolage Grotesque',sans-serif;font-size:2rem;line-height:1;}
@media(max-width:1024px){.admin-main{padding:1.5rem;}}
@media(max-width:768px){
  .admin-layout{flex-direction:column;}
  .admin-sidebar{width:100%;height:auto;position:relative;left:auto;top:auto;z-index:50;background:var(--bg);border-right:none;border-bottom:1px solid var(--border);overflow-y:visible;}
  .sidebar-brand{display:none;}
  .sidebar-nav{display:flex;gap:0.5rem;overflow-x:auto;padding:0.75rem 1rem;}
  .nav-label{display:none;}.nav-item{flex-shrink:0;margin-bottom:0;padding:0.625rem 0.875rem;}.nav-item.active::before{display:none;}
  .sidebar-footer{display:none;}.admin-main{padding:1.25rem;width:100%;max-width:100%;margin-left:0;}
}
.modal-backdrop{position:fixed;inset:0;background:rgba(0,0,0,0.8);z-index:1000;display:flex;align-items:center;justify-content:center;padding:1rem;opacity:0;pointer-events:none;transition:opacity 0.3s;}
.modal-backdrop.active{opacity:1;pointer-events:auto;}
.modal{background:var(--bg-elevated);border:1px solid var(--border-light);border-radius:24px;width:100%;max-width:480px;padding:2rem;transform:scale(0.92) translateY(20px);transition:transform 0.35s cubic-bezier(0.16,1,0.3,1);box-shadow:0 30px 80px -20px rgba(0,0,0,0.8);max-height:90vh;overflow-y:auto;}
.modal-backdrop.active .modal{transform:scale(1) translateY(0);}
.toast{background:var(--bg-elevated);border:1px solid var(--border-light);border-radius:12px;padding:0.75rem 1.25rem;box-shadow:0 10px 40px -10px rgba(0,0,0,0.7);animation:slide-in 0.3s cubic-bezier(0.16,1,0.3,1) forwards;display:flex;align-items:center;gap:0.75rem;min-width:250px;}
@keyframes slide-in{from{transform:translateY(20px);opacity:0;}to{transform:translateY(0);opacity:1;}}@keyframes slide-out{to{transform:translateY(20px);opacity:0;}}
.data-table{width:100%;border-collapse:collapse;}
.data-table th{background:var(--surface);color:var(--text-muted);font-size:0.7rem;font-weight:700;text-transform:uppercase;letter-spacing:0.08em;padding:0.875rem 1rem;text-align:left;border-bottom:1px solid var(--border);white-space:nowrap;}
.data-table th.text-right,.data-table td.text-right{text-align:right !important;}
.data-table td{padding:0.875rem 1rem;border-bottom:1px solid var(--border);font-size:0.875rem;}
.data-table tr:last-child td{border-bottom:none;}.data-table tbody tr:active{background:var(--surface-hover);}
.data-table tfoot td{border-top:2px solid var(--border-light);background:var(--surface-hover);font-weight:800;}
.badge{padding:0.25rem 0.625rem;border-radius:6px;font-size:0.7rem;font-weight:700;display:inline-block;}
.badge-blue{background:rgba(14,165,233,0.15);color:#7dd3fc;}.badge-emerald{background:rgba(16,185,129,0.15);color:#34d399;}.badge-red{background:rgba(239,68,68,0.15);color:#f87171;}
.card{background:var(--surface);border:1px solid var(--border);border-radius:20px;box-shadow:0 8px 32px rgba(0,0,0,0.2);}
.btn-secondary{background:var(--surface);color:var(--text);border:1px solid var(--border-light);transition:background 0.2s;padding:0.5rem 0.75rem;border-radius:10px;font-size:0.875rem;font-weight:600;cursor:pointer;}
.btn-secondary:active{background:var(--surface-hover);border-color:var(--text-dim);}
::-webkit-scrollbar{width:8px;height:8px;}::-webkit-scrollbar-track{background:transparent;}::-webkit-scrollbar-thumb{background:var(--border-light);border-radius:4px;}
.password-mask{-webkit-text-security:disc;-moz-text-security:disc;text-security:disc;}
#filter-card{position:relative;z-index:50;}
.multi-select-panel{position:absolute;top:100%;left:0;min-width:100%;margin-top:0.5rem;background:var(--bg-elevated);border:1px solid var(--border-light);border-radius:12px;max-height:250px;overflow-y:auto;z-index:200;display:none;box-shadow:0 10px 30px rgba(0,0,0,0.5);padding:0.5rem;}
.multi-select-panel.active{display:block;}
.multi-select-option{display:flex;align-items:center;gap:0.75rem;padding:0.625rem 0.875rem;cursor:pointer;border-radius:8px;white-space:nowrap;}
.multi-select-option:active{background:var(--surface-hover);}
.multi-select-option input{accent-color:var(--primary);width:16px;height:16px;cursor:pointer;}
.msg-popup{position:fixed;bottom:50px;right:20px;left:20px;width:auto;max-width:340px;margin-left:auto;background:var(--bg-elevated);border:1px solid var(--primary);border-radius:16px;box-shadow:0 20px 50px -10px rgba(99,102,241,0.4);z-index:200;transform:translateX(400px);transition:transform 0.4s cubic-bezier(0.16,1,0.3,1); }
.msg-popup.active{transform:translateX(0);}
.app-footer{position:fixed;bottom:0;left:0;right:0;z-index:30;background:var(--bg);border-top:1px solid var(--border);padding:0.4rem 1rem;font-size:0.7rem;display:flex;justify-content:center;align-items:center;user-select:none;width:100%;max-width:100%;box-sizing:border-box;}
.app-footer .footer-bar{display:inline-flex;align-items:center;gap:0.5rem;width:100%;max-width:1200px;justify-content:center;flex-wrap:wrap;}
@media(max-width:480px){.app-footer{padding:0.35rem 0.5rem;font-size:0.6rem;}.app-footer .footer-bar{gap:0.3rem;}}
.app-footer span.dev-name{font-weight:700;}
.color-swatch{width:32px;height:32px;border-radius:50%;cursor:pointer;border:2px solid transparent;transition:all 0.2s;}
.color-swatch.active{border-color:white;box-shadow:0 0 10px rgba(255,255,255,0.5);}
.call-overlay{position:fixed;inset:0;background:rgba(0,0,0,0.95);z-index:500;display:none;flex-direction:column;align-items:center;justify-content:center;gap:1.5rem;}
.call-overlay.active{display:flex;}
.call-icon{width:100px;height:100px;border-radius:50%;background:linear-gradient(135deg,var(--primary),var(--accent));display:flex;align-items:center;justify-content:center;font-size:3rem;animation:neon-pulse 1.5s infinite;}
.tag-mini{font-size:0.6rem;font-weight:700;padding:0.1rem 0.4rem;border-radius:3px;display:inline-block;}
.tag-cmt{background:rgba(14,165,233,0.2);color:#7dd3fc;border:1px solid rgba(14,165,233,0.3);}
.tag-img{background:rgba(16,185,129,0.2);color:#34d399;border:1px solid rgba(16,185,129,0.3);}
.tag-mob{background:rgba(99,102,241,0.2);color:#818cf8;border:1px solid rgba(99,102,241,0.3);}
.others-section-box{background:var(--surface);border:1px solid #dc2626;border-radius:16px;overflow:hidden;margin-top:1.25rem;}
.others-section-heading{background:#dc2626;padding:1rem 1.25rem;border-bottom:2px solid #b91c1c;}
.others-section-heading h3{font-family:'Bricolage Grotesque',sans-serif;font-weight:800;font-size:1.125rem;color:#ffffff;}
.others-section-heading p{font-size:0.7rem;color:#fecaca;margin-top:0.25rem;}
.others-table th{background:#dc2626 !important;color:#ffffff !important;text-transform:uppercase;font-size:0.7rem;font-weight:700;letter-spacing:0.08em;padding:0.875rem 1rem;text-align:left;border-bottom:1px solid #b91c1c;white-space:nowrap;}
.others-table td{vertical-align:middle;}
.others-floor-cell{display:inline-block;background:#dc2626;color:#ffffff;padding:0.25rem 0.625rem;border-radius:6px;font-weight:800;font-size:0.75rem;white-space:nowrap;}
.others-reason-cell{color:#ffffff;font-weight:700;font-size:0.875rem;}
.others-comment-cell{color:#fca5a5;font-size:0.8rem;font-style:italic;}
.others-mobile-cell{color:#818cf8;font-weight:600;font-size:0.875rem;}
@media(max-width:380px){.login-card{padding:1.5rem;border-radius:18px;}.login-card h1{font-size:1.5rem;}.login-card p{font-size:0.7rem;}.input-field{padding:0.75rem;font-size:0.875rem;border-radius:10px;}.login-card button{padding:0.75rem;font-size:0.875rem;}.login-card .w-16{width:48px;height:48px;}.login-card .w-16 i{font-size:1.25rem;}}
/* === v3.2 MOBILE LOGIN AUTO FONT-SIZE ADJUST === */
@media(max-width:480px){.v3-login-wrap{max-width:100%;border-radius:18px;}.v3-login-card{padding:1.5rem 1.25rem;}.v3-login-header{margin-bottom:1.25rem;}.v3-login-logo{width:52px;height:52px;border-radius:14px;}.v3-login-header h2{font-size:1.35rem;}.v3-login-header p{font-size:0.75rem;}.v3-login-card .input-field{font-size:0.875rem;padding:0.75rem 0.875rem;}.v3-btn-primary{font-size:0.875rem;padding:0.85rem;}.v3-hero-title{font-size:1.65rem !important;}.v3-hero-sub{font-size:0.72rem !important;margin-bottom:1.25rem !important;}.v3-hero-badge{font-size:0.6rem;padding:0.25rem 0.7rem;margin-bottom:1rem;}.v3-feat{font-size:0.7rem;padding:0.4rem 0.7rem;}.v3-feat i{font-size:0.8rem;}}
@media(max-width:360px){.v3-login-card{padding:1.25rem 1rem;}.v3-login-header h2{font-size:1.2rem;}.v3-login-card .input-field{font-size:0.8rem;padding:0.65rem 0.75rem;}.v3-btn-primary{font-size:0.8rem;padding:0.75rem;}.v3-hero-title{font-size:1.4rem !important;}.v3-hero-sub{font-size:0.65rem !important;}.v3-feat{font-size:0.65rem;padding:0.35rem 0.6rem;}.login-container{padding:0.5rem;}}
/* Auto-fit using clamp for very small screens */
@media(max-height:600px) and (max-width:480px){.v3-login-wrap{min-height:auto;}.v3-login-hero{padding:1.5rem 1rem;}.v3-login-card{padding:1rem;}.v3-login-header{margin-bottom:0.75rem;}.v3-login-logo{width:44px;height:44px;margin-bottom:0.5rem;}}
html{font-size:16px;}
@media(max-width:480px){html{font-size:15px;}}
@media(max-width:360px){html{font-size:14px;}}
@media(max-width:320px){html{font-size:13px;}}

/* === SLIDER TOGGLE SWITCH (replaces checkboxes throughout the UI) === */
.toggle{position:relative;display:inline-block;width:42px;height:24px;flex-shrink:0;cursor:pointer;}
.toggle input{opacity:0;width:0;height:0;position:absolute;}
.toggle .slider-track{position:absolute;inset:0;background:var(--border);border-radius:24px;transition:background 0.25s ease, box-shadow 0.25s ease;}
.toggle .slider-track::before{content:"";position:absolute;height:18px;width:18px;left:3px;top:3px;background:#fff;border-radius:50%;transition:transform 0.25s cubic-bezier(0.4,0,0.2,1);box-shadow:0 1px 3px rgba(0,0,0,0.4);}
.toggle input:checked + .slider-track{background:linear-gradient(135deg,var(--primary),var(--primary-glow));box-shadow:0 0 10px rgba(99,102,241,0.4);}
.toggle input:checked + .slider-track::before{transform:translateX(18px);}
.toggle.toggle-cyan input:checked + .slider-track{background:linear-gradient(135deg,#06b6d4,#22d3ee);box-shadow:0 0 10px rgba(34,211,238,0.4);}
.toggle.toggle-sky input:checked + .slider-track{background:linear-gradient(135deg,#0ea5e9,#38bdf8);box-shadow:0 0 10px rgba(56,189,248,0.4);}
.toggle.toggle-emerald input:checked + .slider-track{background:linear-gradient(135deg,#10b981,#34d399);box-shadow:0 0 10px rgba(52,211,153,0.4);}
.toggle.toggle-pink input:checked + .slider-track{background:linear-gradient(135deg,#6366f1,#818cf8);box-shadow:0 0 10px rgba(129,140,248,0.4);}
.toggle.toggle-red input:checked + .slider-track{background:linear-gradient(135deg,#ef4444,#f87171);box-shadow:0 0 10px rgba(248,113,113,0.4);}
.toggle.toggle-amber input:checked + .slider-track{background:linear-gradient(135deg,#f59e0b,#fbbf24);box-shadow:0 0 10px rgba(251,191,36,0.4);}
.toggle.toggle-purple input:checked + .slider-track{background:linear-gradient(135deg,#8b5cf6,#a78bfa);box-shadow:0 0 10px rgba(167,139,250,0.4);}

/* === NEW UI MODE — more polished, neat, beautiful, professional === */
body.new-ui{--bg:#0a0a0f;--bg-elevated:#13131a;--surface:#16161e;--surface-hover:#1f1f29;--border:#26262f;--border-light:#2f2f3a;}
body.new-ui .ambient-bg{background:radial-gradient(ellipse at top,rgba(99,102,241,0.10) 0%,transparent 55%),radial-gradient(ellipse at bottom right,rgba(245,158,11,0.08) 0%,transparent 55%),radial-gradient(ellipse at bottom left,rgba(6,182,212,0.06) 0%,transparent 55%);opacity:1;}
body.new-ui .card{border-radius:18px;border:1px solid var(--border-light);box-shadow:0 4px 24px -8px rgba(0,0,0,0.5),inset 0 1px 0 rgba(255,255,255,0.04);transition:transform 0.2s ease,box-shadow 0.2s ease;}
body.new-ui .card:hover{transform:translateY(-1px);box-shadow:0 8px 32px -10px rgba(0,0,0,0.6),inset 0 1px 0 rgba(255,255,255,0.06);}
body.new-ui .input-field{border-radius:12px;padding:0.75rem 1rem;font-size:0.9375rem;transition:border-color 0.2s,box-shadow 0.2s,background 0.2s;background:rgba(255,255,255,0.02);}
body.new-ui .input-field:focus{border-color:var(--primary);box-shadow:0 0 0 3px rgba(99,102,241,0.15),0 0 20px -5px rgba(99,102,241,0.25);background:rgba(255,255,255,0.04);}
body.new-ui .modal{border-radius:20px;box-shadow:0 40px 100px -20px rgba(0,0,0,0.9),inset 0 1px 0 rgba(255,255,255,0.06);background:linear-gradient(180deg,rgba(255,255,255,0.02) 0%,transparent 100%),var(--bg-elevated);}
body.new-ui .btn-secondary{border-radius:12px;padding:0.625rem 1rem;transition:all 0.2s;border:1px solid var(--border-light);background:rgba(255,255,255,0.02);}
body.new-ui .btn-secondary:hover{background:rgba(255,255,255,0.06);transform:translateY(-1px);}
body.new-ui .nav-item{border-radius:12px;margin:2px 4px;transition:all 0.2s;}
body.new-ui .nav-item.active{background:linear-gradient(135deg,rgba(99,102,241,0.18),rgba(99,102,241,0.08));box-shadow:inset 0 0 0 1px rgba(99,102,241,0.3);}
body.new-ui .data-table{border-radius:14px;overflow:hidden;}
body.new-ui .data-table thead{background:linear-gradient(180deg,rgba(99,102,241,0.10),rgba(99,102,241,0.04));}
body.new-ui .data-table th{font-weight:700;letter-spacing:0.02em;font-size:0.75rem;text-transform:uppercase;padding:0.875rem 1rem;}
body.new-ui .data-table td{padding:0.75rem 1rem;font-size:0.875rem;}
body.new-ui .data-table tbody tr{transition:background 0.15s;}
body.new-ui .data-table tbody tr:hover{background:rgba(255,255,255,0.025);}
body.new-ui .admin-main{background:transparent;}
body.new-ui .admin-sidebar{background:rgba(255,255,255,0.015);backdrop-filter:blur(20px);border-right:1px solid var(--border-light);}
body.new-ui .admin-header{background:rgba(255,255,255,0.015);backdrop-filter:blur(20px);border-bottom:1px solid var(--border-light);}
body.new-ui h1,body.new-ui h2,body.new-ui h3,body.new-ui h4{letter-spacing:-0.01em;}
body.new-ui .login-card{box-shadow:0 40px 100px -20px rgba(0,0,0,0.9),inset 0 1px 0 rgba(255,255,255,0.06);}
body.new-ui .toast{border-radius:14px;backdrop-filter:blur(12px);background:rgba(22,22,30,0.92);}
body.new-ui .tag-mini{font-size:0.625rem;font-weight:700;letter-spacing:0.04em;padding:0.125rem 0.375rem;border-radius:6px;}
body.new-ui .color-swatch{transition:transform 0.2s,box-shadow 0.2s;}
body.new-ui .color-swatch:hover{transform:scale(1.1);}
body.new-ui .color-swatch.active{transform:scale(1.15);box-shadow:0 0 14px currentColor,0 0 0 2px #fff;}

/* === MOBILE PERFORMANCE OPTIMIZATIONS === */
/* Mobile devices: reduce expensive backdrop-filter blur, simplify shadows, reduce animations.
   This dramatically improves scroll/refresh responsiveness on phones. */
@media (max-width: 768px), (hover: none) and (pointer: coarse){
  body.new-ui .admin-sidebar{backdrop-filter:none;background:rgba(20,20,28,0.96);}
  body.new-ui .admin-header{backdrop-filter:none;background:rgba(20,20,28,0.96);}
  body.new-ui .toast{backdrop-filter:none;background:rgba(22,22,30,1);}
  body.new-ui .card{box-shadow:0 2px 10px -4px rgba(0,0,0,0.5),inset 0 1px 0 rgba(255,255,255,0.03);transition:none;}
  body.new-ui .card:hover{transform:none;box-shadow:0 2px 10px -4px rgba(0,0,0,0.5);}
  body.new-ui .input-field{transition:border-color 0.2s;}
  body.new-ui .input-field:focus{box-shadow:0 0 0 2px rgba(99,102,241,0.15);}
  body.new-ui .btn-secondary:hover{transform:none;}
  body.new-ui .data-table tbody tr{transition:none;}
  .call-icon{animation:none;}
  #login-logo-cont{animation:none;}
  .sync-dot{animation:none;opacity:0.7;}
  .toggle .slider-track{transition:background 0.15s;}
  .toggle .slider-track::before{transition:transform 0.15s;}
  .modal{transition:transform 0.2s;}
  .modal-backdrop{transition:opacity 0.2s;}
  .msg-popup{transition:transform 0.25s;}
  .home-box{transition:none;}
  .nav-item{transition:none;}
}
/* Reduce motion for users who prefer it */
@media (prefers-reduced-motion: reduce){
  *{animation-duration:0.01ms !important;animation-iteration-count:1 !important;transition-duration:0.01ms !important;}
  .call-icon{animation:none;}
  #login-logo-cont{animation:none;}
  .sync-dot{animation:none;}
}
</style>
</head>
<body oncontextmenu="return false">
<div class="ambient-bg"></div>
<div class="call-overlay" id="call-overlay"><div class="call-icon"><i class="fas fa-phone text-white"></i></div><div class="text-center"><div class="font-display font-extrabold text-3xl text-white" id="call-status-text">Admin Calling...</div><div class="text-sm text-[var(--text-muted)] mt-2" id="call-timer">Connecting...</div></div><button onclick="endCallFromFloor()" class="px-8 py-3 rounded-xl bg-red-500 hover:bg-red-600 text-white font-bold transition-all">End Call</button></div>

<div id="screen-login" class="screen login-container">
<div class="absolute top-4 right-4 flex gap-2 z-30">
    <button onclick="openDashboardLogin()" class="admin-icon-btn" style="background:linear-gradient(135deg,#06b6d4,#0284c7);border-color:rgba(6,182,212,0.4);box-shadow:0 4px 12px -2px rgba(6,182,212,0.5);" title="Dashboard Access"><i class="fas fa-chart-line"></i></button>
    <button onclick="openAdminLogin()" class="admin-icon-btn" title="Admin Access"><i class="fas fa-shield-halved"></i></button>
</div>
<div class="v3-login-wrap">
    <div class="v3-login-hero">
        <div class="v3-hero-glow"></div>
        <div class="v3-hero-content">
            <h1 class="v3-hero-title font-display" id="login-brand-name">Customer-System</h1>
            <div class="v3-hero-tagline" id="login-tagline">A world of elegance where every piece tells a beautiful story.<br>At Saravana Stores Elite Thanga Nagai Maligai, quality meets timeless beauty.<br>Celebrate every special moment with jewellery that shines as brightly as you do.<br><strong>Come visit us and experience the sparkle, warmth, and elegance for yourself!</strong></div>
        </div>
    </div>
    <div class="v3-login-card">
        <div class="v3-login-header">
            <div class="v3-login-logo" id="login-logo-cont" style="background:linear-gradient(135deg,var(--primary),var(--accent));"><i class="fas fa-building text-white text-2xl"></i></div>
            <h2 class="font-display font-extrabold text-2xl">Welcome Back</h2>
            <p class="text-sm text-[var(--text-muted)]">Select your floor to begin</p>
        </div>
        <div class="space-y-4">
            <div>
                <label class="text-xs font-bold text-[var(--text-muted)] uppercase tracking-wider mb-2 block">Floor Name</label>
                <div class="custom-select">
                    <input type="text" id="login-floor" class="input-field" placeholder="Type or select floor..." autocomplete="off" oninput="filterFloors()" onfocus="filterFloors()" onkeydown="handleFloorKeydown(event)" onblur="setTimeout(()=>document.getElementById('floor-options').classList.remove('active'),200)">
                    <div id="floor-options" class="select-options"></div>
                </div>
            </div>
            <div>
                <label class="text-xs font-bold text-[var(--text-muted)] uppercase tracking-wider mb-2 block">Access PIN</label>
                <input type="text" id="login-pin" class="input-field text-center tracking-[0.5em] password-mask" placeholder="&bull;&bull;&bull;&bull;" maxlength="4" inputmode="numeric" autocomplete="off" onkeydown="handleFloorEnter(event)" oninput="onPinInput(this)">
            </div>
            <div id="emp-name-field" class="hidden"><label class="text-xs font-bold text-[var(--text-muted)] uppercase tracking-wider mb-2 block">Your Name</label><input type="text" id="login-emp-name" class="input-field" placeholder="Enter your name" autocomplete="off"></div>
            <div id="emp-shift-field" class="hidden"><label class="text-xs font-bold text-[var(--text-muted)] uppercase tracking-wider mb-2 block">Shift</label><select id="login-emp-shift" class="input-field"><option value="Morning">Morning</option><option value="Afternoon">Afternoon</option><option value="Evening">Evening</option><option value="Night">Night</option></select></div>
            <div id="floor-login-error" class="text-red-400 text-sm text-center font-semibold h-5"></div>
            <button onclick="attemptLogin()" class="v3-btn-primary">Access Terminal <i class="fas fa-arrow-right ml-2"></i></button>
        </div>
    </div>
</div>
</div>

<div id="screen-home" class="screen hidden"><div class="minimal-top-bar"><div class="brand-mark"><div class="brand-icon" id="top-brand-icon"><i class="fas fa-people-group text-white text-sm"></i></div><div class="flex flex-col"><span class="brand-text" id="top-brand-name">Customer-System</span><span class="text-[10px] text-[var(--accent-glow)] font-bold uppercase tracking-wider" id="current-floor-display">FLOOR</span></div></div><div class="flex items-center gap-2"><div class="signal-strength-badge" id="signal-strength-home" title="Live Signal Strength"><svg xmlns="http://www.w3.org/2000/svg" class="signal-icon" viewBox="0 0 24 24" width="20" height="20"><path class="sig-bar sig-bar-1" d="M2 18h3v4H2z" fill="currentColor"/><path class="sig-bar sig-bar-2" d="M7 14h3v8H7z" fill="currentColor"/><path class="sig-bar sig-bar-3" d="M12 10h3v12h-3z" fill="currentColor"/><path class="sig-bar sig-bar-4" d="M17 6h3v16h-3z" fill="currentColor"/><path class="sig-bar sig-bar-5" d="M22 2h1v20h-1z" fill="currentColor"/></svg><span class="signal-text" id="signal-text-home">--</span></div><button onclick="openUpdateEmpInfo()" id="update-emp-btn" class="admin-access-btn hidden"><i class="fas fa-user"></i><span>Update Info</span></button><button onclick="logoutFloor()" class="admin-access-btn logout-btn" title="Logout"><i class="fas fa-right-from-bracket"></i><span>Logout</span></button></div></div><main class="home-main"><div class="top-dashboard-card"><div class="count-item entry-count"><span class="count-label">Today's Entries</span><span class="count-value" id="total-entry-count">0</span></div><div class="divider"></div><div class="count-item in-store-count"><span class="count-label">In Store Now</span><span class="count-value" id="in-store-count">0</span></div><div class="divider"></div><div class="count-item exit-count"><span class="count-label">Today's Exits</span><span class="count-value" id="total-exit-count">0</span></div></div><div class="home-grid"><div class="home-box entry" onclick="openEntryModal()"><div class="home-box-icon"><i class="fas fa-door-open"></i></div><div class="home-box-title">CUSTOMER ENTRY</div></div><div class="home-box exit" onclick="openExitModal()"><div class="home-box-icon"><i class="fas fa-door-closed"></i></div><div class="home-box-title">CUSTOMER EXIT</div></div></div></main></div>

<div id="screen-admin-login" class="screen hidden login-container"><div class="login-card"><div class="text-center mb-8"><div class="w-16 h-16 rounded-2xl bg-gradient-to-br from-indigo-500 to-indigo-700 mx-auto mb-4 flex items-center justify-center shadow-lg shadow-red-500/30"><i class="fas fa-shield-halved text-white text-2xl"></i></div><h1 class="font-display font-extrabold text-3xl mb-2">Admin Access</h1><p class="text-sm text-[var(--text-muted)]">Enter administrator password</p></div><div class="space-y-4"><input type="text" id="admin-pass" class="input-field text-center password-mask" placeholder="Password" autocomplete="off" onkeydown="handleAdminEnter(event)" oninput="onAdminPassInput(this)"><div id="admin-error" class="text-red-400 text-sm text-center font-semibold h-5"></div><button onclick="attemptAdminLogin()" class="w-full py-3 rounded-xl bg-gradient-to-r from-indigo-500 to-indigo-600 text-white font-bold text-base transition-all">Login</button><button onclick="showScreen('screen-login')" class="w-full py-3 rounded-xl bg-[var(--surface-hover)] text-[var(--text-muted)] font-bold text-sm transition-all">Back to Floor Login</button></div></div></div>

<div id="screen-dashboard-login" class="screen hidden login-container"><div class="login-card"><div class="text-center mb-8"><div class="w-16 h-16 rounded-2xl bg-gradient-to-br from-cyan-500 to-indigo-700 mx-auto mb-4 flex items-center justify-center shadow-lg shadow-sky-500/30"><i class="fas fa-chart-line text-white text-2xl"></i></div><h1 class="font-display font-extrabold text-3xl mb-2">Dashboard Access</h1><p class="text-sm text-[var(--text-muted)]">Enter password to view dashboard</p></div><div class="space-y-4"><input type="text" id="dash-pass" class="input-field text-center password-mask" placeholder="Password" autocomplete="off" onkeydown="handleDashEnter(event)" oninput="onDashPassInput(this)"><div id="dash-error" class="text-red-400 text-sm text-center font-semibold h-5"></div><button onclick="attemptDashboardLogin()" class="w-full py-3 rounded-xl bg-gradient-to-r from-cyan-500 to-indigo-600 text-white font-bold text-base transition-all">Login</button><button onclick="showScreen('screen-login')" class="w-full py-3 rounded-xl bg-[var(--surface-hover)] text-[var(--text-muted)] font-bold text-sm transition-all">Back to Floor Login</button></div></div></div>

<div id="screen-admin" class="screen hidden"><div class="admin-layout"><aside class="admin-sidebar"><div class="sidebar-brand"><div class="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 to-indigo-700 flex items-center justify-center shadow-lg shadow-indigo-500/30 overflow-hidden" id="sidebar-logo-cont"><i class="fas fa-shield-halved text-white"></i></div><div><div class="font-display font-extrabold text-base leading-none">Admin Panel</div><div class="text-[10px] text-[var(--text-muted)] mt-0.5 uppercase tracking-wider" id="sidebar-brand-name">Customer-System</div></div></div><nav class="sidebar-nav"><div class="nav-label">Menu</div><div id="sidebar-nav-items"></div></nav><div class="sidebar-footer"><button onclick="logoutAdmin()" class="exit-admin-btn"><i class="fas fa-right-from-bracket"></i> Exit Admin</button></div></aside><main class="admin-main"><header class="admin-header"><div><h1 id="report-detail-title">Dashboard</h1><p class="text-sm text-[var(--text-muted)] mt-1" id="report-subtitle">View, print, and export report data</p></div><div class="flex items-center gap-2 flex-wrap"><button onclick="openCallFloorModal()" class="btn-secondary flex items-center gap-2 text-emerald-400 border-emerald-500/30"><i class="fas fa-phone"></i><span class="hidden sm:inline">Call Floor</span></button><button onclick="openPassManager()" class="btn-secondary flex items-center gap-2 text-amber-400 border-amber-500/30"><i class="fas fa-key"></i><span class="hidden sm:inline">Passwords</span></button><button onclick="openFloorMgmt()" class="btn-secondary flex items-center gap-2 text-amber-400 border-amber-500/30"><i class="fas fa-building-shield"></i><span class="hidden sm:inline">Floors</span></button><button onclick="openBackupRestore()" class="btn-secondary flex items-center gap-2 text-cyan-400 border-cyan-500/30"><i class="fas fa-database"></i><span class="hidden sm:inline">Backup</span></button><button onclick="openImportData()" class="btn-secondary flex items-center gap-2 text-amber-400 border-amber-500/40" style="background:rgba(245,158,11,0.08);"><i class="fas fa-file-import"></i><span class="hidden sm:inline">JSON→DB</span></button><button onclick="openClearAuth()" class="btn-secondary flex items-center gap-2 text-red-400 border-red-500/30"><i class="fas fa-trash"></i><span class="hidden sm:inline">Clear</span></button><button onclick="exportCurrentReport('pdf')" class="btn-secondary flex items-center gap-2"><i class="fas fa-file-pdf text-red-400"></i><span class="hidden sm:inline">PDF</span></button><button onclick="exportCurrentReport('excel')" class="btn-secondary flex items-center gap-2"><i class="fas fa-file-excel text-emerald-400"></i><span class="hidden sm:inline">Excel</span></button></div></header><div class="card p-4 mb-5" id="admin-status-card"><div class="flex items-center gap-3 mb-2"><div class="w-10 h-10 rounded-xl flex items-center justify-center" id="admin-status-icon-bg"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" id="admin-signal-svg"><path class="sig-bar sig-bar-1" d="M2 18h3v4H2z" fill="currentColor"/><path class="sig-bar sig-bar-2" d="M7 14h3v8H7z" fill="currentColor"/><path class="sig-bar sig-bar-3" d="M12 10h3v12h-3z" fill="currentColor"/><path class="sig-bar sig-bar-4" d="M17 6h3v16h-3z" fill="currentColor"/><path class="sig-bar sig-bar-5" d="M22 2h1v20h-1z" fill="currentColor"/></svg></div><div class="flex-1"><div class="font-display font-bold text-base">Connection Status <span class="signal-strength-badge" id="signal-strength-admin" style="display:inline-flex;margin-left:0.5rem;"><span class="signal-text" id="signal-text-admin">--</span></span></div><div class="text-xs text-[var(--text-muted)]">Last checked: <span id="status-time">Never</span></div></div><div class="font-bold text-sm" id="admin-status-text">Checking...</div></div></div><div class="card p-4 mb-5 flex flex-wrap items-center gap-3" id="filter-card"><div class="flex items-center gap-2 text-sm font-bold text-[var(--text-muted)]"><i class="fas fa-filter"></i> Filters:</div><div class="relative" id="floor-filter-container" style="min-width:220px;max-width:300px;flex:1;"><button type="button" class="input-field text-left flex items-center justify-between w-full" style="cursor:pointer;padding-right:1rem;" onclick="toggleFloorDropdown(event)"><span id="floor-filter-label" class="truncate">All Floors</span><i class="fas fa-chevron-down text-xs"></i></button><div id="floor-checkbox-panel" class="multi-select-panel"></div></div><select id="filter-mode" class="input-field" style="max-width:150px;" onchange="toggleDateFilters();renderCurrentReport()"><option value="today">Today</option><option value="yesterday">Yesterday</option><option value="custom">Custom Date</option><option value="range">Date Range</option><option value="month">Monthly</option><option value="all">All Time</option></select><input type="date" id="filter-date" class="input-field" style="max-width:180px;display:none;" onchange="renderCurrentReport()"><input type="date" id="filter-date-from" class="input-field" style="max-width:180px;display:none;" onchange="renderCurrentReport()"><input type="date" id="filter-date-to" class="input-field" style="max-width:180px;display:none;" onchange="renderCurrentReport()"><input type="month" id="filter-month" class="input-field" style="max-width:180px;display:none;" onchange="renderCurrentReport()"><select id="filter-type" class="input-field" style="max-width:150px;display:none;" onchange="renderCurrentReport()"><option value="">All Types</option><option value="Purchase">Purchase</option><option value="Return">Return</option></select><select id="filter-reason" class="input-field" style="max-width:200px;" onchange="renderCurrentReport()"><option value="">All Reasons</option></select></div><div id="report-content"></div></main></div></div>

<div id="screen-dashboard" class="screen hidden"><div class="admin-layout"><aside class="admin-sidebar"><div class="sidebar-brand"><div class="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-500 to-indigo-700 flex items-center justify-center shadow-lg shadow-cyan-500/30 overflow-hidden"><i class="fas fa-chart-line text-white"></i></div><div><div class="font-display font-extrabold text-base leading-none">Dashboard Panel</div><div class="text-[10px] text-[var(--text-muted)] mt-0.5 uppercase tracking-wider" id="sidebar-brand-name-dash">Customer-System</div></div></div><nav class="sidebar-nav"><div class="nav-label">Menu</div><div id="dash-sidebar-nav-items"></div></nav><div class="sidebar-footer"><button onclick="logoutDashboard()" class="exit-admin-btn"><i class="fas fa-right-from-bracket"></i> Exit Dashboard</button></div></aside><main class="admin-main"><header class="admin-header"><div><h1 id="dash-report-title">Dashboard</h1></div><div class="flex items-center gap-2 flex-wrap"><button onclick="exportCurrentDashReport('pdf')" class="btn-secondary flex items-center gap-2"><i class="fas fa-file-pdf text-red-400"></i><span class="hidden sm:inline">PDF</span></button><button onclick="exportCurrentDashReport('excel')" class="btn-secondary flex items-center gap-2"><i class="fas fa-file-excel text-emerald-400"></i><span class="hidden sm:inline">Excel</span></button></div></header><div class="card p-4 mb-5 flex flex-wrap items-center gap-3" id="dash-filter-card"><div class="flex items-center gap-2 text-sm font-bold text-[var(--text-muted)]"><i class="fas fa-filter"></i> Filters:</div><div class="relative" id="dash-floor-filter-container" style="min-width:220px;max-width:300px;flex:1;"><button type="button" class="input-field text-left flex items-center justify-between w-full" style="cursor:pointer;padding-right:1rem;" onclick="toggleDashFloorDropdown(event)"><span id="dash-floor-filter-label" class="truncate">All Floors</span><i class="fas fa-chevron-down text-xs"></i></button><div id="dash-floor-checkbox-panel" class="multi-select-panel"></div></div><select id="dash-filter-mode" class="input-field" style="max-width:150px;" onchange="toggleDashDateFilters();renderDashReport()"><option value="today">Today</option><option value="yesterday">Yesterday</option><option value="custom">Custom Date</option><option value="range">Date Range</option><option value="month">Monthly</option><option value="all">All Time</option></select><input type="date" id="dash-filter-date" class="input-field" style="max-width:180px;display:none;" onchange="renderDashReport()"><input type="date" id="dash-filter-date-from" class="input-field" style="max-width:180px;display:none;" onchange="renderDashReport()"><input type="date" id="dash-filter-date-to" class="input-field" style="max-width:180px;display:none;" onchange="renderDashReport()"><input type="month" id="dash-filter-month" class="input-field" style="max-width:180px;display:none;" onchange="renderDashReport()"><select id="dash-filter-type" class="input-field" style="max-width:150px;display:none;" onchange="renderDashReport()"><option value="">All Types</option><option value="Purchase">Purchase</option><option value="Return">Return</option></select><select id="dash-filter-reason" class="input-field" style="max-width:200px;" onchange="renderDashReport()"><option value="">All Reasons</option></select></div><div id="dash-report-content"></div></main></div></div>

<div class="modal-backdrop" id="entry-modal-backdrop"><div class="modal"><div class="flex items-center justify-between mb-6"><div><div class="text-[10px] text-[var(--text-muted)] font-bold uppercase tracking-wider mb-1">Customer Entry</div><h3 class="font-display font-extrabold text-2xl">Select Category</h3></div><button onclick="closeModal('entry-modal-backdrop')" class="w-9 h-9 rounded-lg bg-[var(--surface-hover)] flex items-center justify-center text-[var(--text-muted)] hover:text-white"><i class="fas fa-xmark"></i></button></div><div class="space-y-2.5"><button class="w-full p-4 rounded-2xl bg-[var(--bg)] border border-[var(--border)] hover:border-pink-500/50 transition-all flex items-center gap-4 text-left" onclick="handleEntry('Single')"><div class="w-12 h-12 rounded-xl bg-pink-500/15 flex items-center justify-center"><i class="fas fa-person text-pink-400 text-xl"></i></div><div class="flex-1"><div class="font-bold text-base">Single</div><div class="text-xs text-[var(--text-muted)]">One customer entering</div></div><i class="fas fa-arrow-right text-[var(--text-muted)]"></i></button><button class="w-full p-4 rounded-2xl bg-[var(--bg)] border border-[var(--border)] hover:border-pink-500/50 transition-all flex items-center gap-4 text-left" onclick="handleEntry('Couple')"><div class="w-12 h-12 rounded-xl bg-pink-500/15 flex items-center justify-center"><i class="fas fa-people-arrows text-pink-400 text-xl"></i></div><div class="flex-1"><div class="font-bold text-base">Couple</div><div class="text-xs text-[var(--text-muted)]">Two customers entering</div></div><i class="fas fa-arrow-right text-[var(--text-muted)]"></i></button><button class="w-full p-4 rounded-2xl bg-[var(--bg)] border border-[var(--border)] hover:border-pink-500/50 transition-all flex items-center gap-4 text-left" onclick="handleEntry('Family')"><div class="w-12 h-12 rounded-xl bg-pink-500/15 flex items-center justify-center"><i class="fas fa-people-roof text-pink-400 text-xl"></i></div><div class="flex-1"><div class="font-bold text-base">Family</div><div class="text-xs text-[var(--text-muted)]">Three or more customers</div></div><i class="fas fa-arrow-right text-[var(--text-muted)]"></i></button></div></div></div>

<div class="modal-backdrop" id="entry-source-backdrop"><div class="modal"><div class="flex items-center justify-between mb-6"><div><div class="text-[10px] text-sky-400 font-bold uppercase tracking-wider mb-1">Way of Source</div><h3 class="font-display font-extrabold text-2xl" id="entry-source-heading">How did they find us?</h3></div><button onclick="closeModal('entry-source-backdrop')" class="w-9 h-9 rounded-lg bg-[var(--surface-hover)] flex items-center justify-center text-[var(--text-muted)] hover:text-white"><i class="fas fa-xmark"></i></button></div><div id="entry-source-list" class="space-y-2"></div><div id="entry-source-other-box" class="hidden mt-4 p-4 rounded-xl bg-[var(--bg)] border border-sky-500/30"><label class="text-xs font-bold text-sky-400 uppercase tracking-wider mb-2 block" id="entry-source-other-label">Custom Source</label><input type="text" id="entry-source-custom" class="input-field mb-3" placeholder="Type custom source here..."><button onclick="submitEntryWithCustomSource()" class="w-full py-2.5 rounded-lg bg-sky-500 hover:bg-sky-600 text-white font-bold text-sm transition-all">Submit Source</button></div></div></div>

<div class="modal-backdrop" id="exit-modal-backdrop"><div class="modal"><div class="flex items-center justify-between mb-6"><div><div class="text-[10px] text-[var(--text-muted)] font-bold uppercase tracking-wider mb-1">Customer Exit</div><h3 class="font-display font-extrabold text-2xl">Select Type</h3></div><button onclick="closeModal('exit-modal-backdrop')" class="w-9 h-9 rounded-lg bg-[var(--surface-hover)] flex items-center justify-center text-[var(--text-muted)] hover:text-white"><i class="fas fa-xmark"></i></button></div><div class="grid grid-cols-2 gap-3"><button class="p-6 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 hover:border-emerald-500 transition-all text-center" onclick="selectExitType('Purchase')"><div class="w-14 h-14 rounded-xl bg-emerald-500/20 mx-auto mb-3 flex items-center justify-center"><i class="fas fa-bag-shopping text-emerald-400 text-2xl"></i></div><div class="font-bold text-lg">Purchase</div></button><button class="p-6 rounded-2xl bg-red-500/10 border border-red-500/30 hover:border-red-500 transition-all text-center" onclick="showReturnReasons()"><div class="w-14 h-14 rounded-xl bg-red-500/20 mx-auto mb-3 flex items-center justify-center"><i class="fas fa-rotate-left text-red-400 text-2xl"></i></div><div class="font-bold text-lg">Return</div></button></div></div></div>

<div class="modal-backdrop" id="exit-reasons-backdrop"><div class="modal"><div class="flex items-center justify-between mb-6"><div><div class="text-[10px] text-red-400 font-bold uppercase tracking-wider mb-1">Return Reason</div><h3 class="font-display font-extrabold text-2xl">Why did they leave?</h3></div><button onclick="closeModal('exit-reasons-backdrop')" class="w-9 h-9 rounded-lg bg-[var(--surface-hover)] flex items-center justify-center text-[var(--text-muted)] hover:text-white"><i class="fas fa-xmark"></i></button></div><div id="reasons-list" class="space-y-2"></div><div id="other-reason-box" class="hidden mt-4 p-4 rounded-xl bg-[var(--bg)] border border-red-500/30"><label class="text-xs font-bold text-red-400 uppercase tracking-wider mb-2 block" id="other-heading">Other</label><input type="text" id="other-reason-input" class="input-field mb-3" placeholder="Type custom reason here..."><div id="other-comment-upload" class="hidden mb-3"><textarea id="other-reason-comment" class="input-field" rows="2" placeholder="Add a comment..."></textarea></div><div id="other-mobile-upload" class="hidden mb-3"><label class="text-xs font-bold text-[var(--text-muted)] uppercase tracking-wider mb-2 block">Mobile Number <span id="other-mobile-req" class="text-red-400 hidden">*</span></label><input type="tel" id="other-reason-mobile-input" class="input-field" placeholder="Enter mobile number" inputmode="numeric" pattern="[0-9]*" maxlength="10"></div><div id="other-image-upload" class="hidden mb-3"><label class="text-xs font-bold text-[var(--text-muted)] uppercase tracking-wider mb-2 block">Attach Image</label><input type="file" accept="image/*" id="other-reason-image" class="input-field" style="padding:0.5rem;"><div id="other-image-preview" class="hidden mt-2"><img class="w-20 h-20 rounded-lg object-cover" id="other-image-preview-img"></div></div><button onclick="handleOtherExit()" class="w-full py-2.5 rounded-lg bg-red-500 hover:bg-red-600 text-white font-bold text-sm transition-all">Submit Reason</button></div><div id="comment-box" class="hidden mt-4 p-4 rounded-xl bg-[var(--bg)] border border-[var(--border-light)]"><label class="text-xs font-bold text-red-400 uppercase tracking-wider mb-2 block" id="comment-box-heading">Reason</label><textarea id="reason-comment" class="input-field" rows="2" placeholder="Type here..."></textarea><div id="comment-mobile-upload" class="hidden mt-3"><label class="text-xs font-bold text-[var(--text-muted)] uppercase tracking-wider mb-2 block">Mobile Number <span id="comment-mobile-req" class="text-red-400 hidden">*</span></label><input type="tel" id="reason-mobile-input" class="input-field" placeholder="Enter mobile number" inputmode="numeric" pattern="[0-9]*" maxlength="10"></div><div id="comment-image-upload" class="hidden mt-3"><label class="text-xs font-bold text-[var(--text-muted)] uppercase tracking-wider mb-2 block">Attach Image</label><input type="file" accept="image/*" id="reason-image" class="input-field" style="padding:0.5rem;"><div id="reason-image-preview" class="hidden mt-2"><img class="w-20 h-20 rounded-lg object-cover" id="reason-image-preview-img"></div></div><button onclick="submitReasonWithComment()" class="w-full mt-3 py-2.5 rounded-lg bg-red-500 hover:bg-red-600 text-white font-bold text-sm transition-all">Submit</button></div></div></div>

<div class="modal-backdrop" id="exit-purchase-source-backdrop"><div class="modal" style="max-width:520px;"><div class="flex items-center justify-between mb-5"><div><div class="text-[10px] text-amber-400 font-bold uppercase tracking-wider mb-1">Step 4</div><h3 class="font-display font-extrabold text-2xl">Purchase Source</h3><p class="text-sm text-[var(--text-muted)] mt-1">How did this purchase happen?</p></div><button onclick="closeModal('exit-purchase-source-backdrop')" class="w-9 h-9 rounded-lg bg-[var(--surface-hover)] flex items-center justify-center text-[var(--text-muted)] hover:text-white"><i class="fas fa-xmark"></i></button></div><div id="purchase-source-list" class="grid grid-cols-2 gap-3 max-h-[50vh] overflow-y-auto pr-1"></div><div id="purchase-source-custom-field" class="hidden mt-4"><label class="text-xs font-bold text-[var(--text-muted)] uppercase tracking-wider mb-2 block">Specify Other Source</label><input type="text" id="purchase-source-custom-input" class="input-field" placeholder="Type custom source..."></div><button onclick="submitPurchaseWithSource()" class="v3-btn-primary mt-5 w-full">Confirm Purchase <i class="fas fa-check ml-2"></i></button></div></div>
<div class="modal-backdrop" id="exit-return-way-backdrop"><div class="modal" style="max-width:520px;"><div class="flex items-center justify-between mb-5"><div><div class="text-[10px] text-amber-400 font-bold uppercase tracking-wider mb-1">Return Way of Entry</div><h3 class="font-display font-extrabold text-2xl">When did they visit?</h3><p class="text-sm text-[var(--text-muted)] mt-1">Select when the customer originally visited</p></div><button onclick="closeModal('exit-return-way-backdrop')" class="w-9 h-9 rounded-lg bg-[var(--surface-hover)] flex items-center justify-center text-[var(--text-muted)] hover:text-white"><i class="fas fa-xmark"></i></button></div><div id="return-way-list" class="grid grid-cols-2 gap-3 max-h-[50vh] overflow-y-auto pr-1"></div><div id="return-way-custom-field" class="hidden mt-4"><label class="text-xs font-bold text-[var(--text-muted)] uppercase tracking-wider mb-2 block">Specify Other</label><input type="text" id="return-way-custom-input" class="input-field" placeholder="Type custom..."></div><button onclick="submitReturnWithWay()" class="v3-btn-primary mt-5 w-full">Confirm Return <i class="fas fa-check ml-2"></i></button></div></div>

<div class="modal-backdrop" id="call-floor-modal"><div class="modal" style="max-width:400px;"><div class="flex items-center justify-between mb-6"><div><div class="text-[10px] text-emerald-400 font-bold uppercase tracking-wider mb-1">Voice Call</div><h3 class="font-display font-extrabold text-2xl">Call a Floor</h3></div><button onclick="closeModal('call-floor-modal')" class="w-9 h-9 rounded-lg bg-[var(--surface-hover)] flex items-center justify-center text-[var(--text-muted)] hover:text-white"><i class="fas fa-xmark"></i></button></div><div class="space-y-2"><p class="text-sm text-[var(--text-muted)] mb-4">Select a floor to call. Auto-connect.</p><div id="call-floor-list" class="space-y-2 max-h-[300px] overflow-y-auto"></div></div></div></div>

<div class="modal-backdrop" id="active-call-modal"><div class="modal" style="max-width:380px;"><div class="text-center"><div class="w-20 h-20 rounded-full mx-auto mb-4 flex items-center justify-center" style="background:linear-gradient(135deg,var(--primary),var(--accent));animation:neon-pulse 1.5s infinite;"><i class="fas fa-microphone text-white text-2xl"></i></div><h3 class="font-display font-extrabold text-2xl mb-2">Connected</h3><p class="text-sm text-[var(--text-muted)] mb-4">Speaking with <span id="active-call-floor" class="font-bold text-white"></span></p><p class="text-xs text-[var(--text-muted)] mb-6" id="active-call-timer">00:00</p><button onclick="endCallFromAdmin()" class="w-full py-3 rounded-xl bg-red-500 hover:bg-red-600 text-white font-bold transition-all">End Call</button></div></div></div>

<div class="modal-backdrop" id="update-emp-modal"><div class="modal" style="max-width:380px;"><div class="flex items-center justify-between mb-6"><div><div class="text-[10px] text-cyan-400 font-bold uppercase tracking-wider mb-1">Profile</div><h3 class="font-display font-extrabold text-2xl">Update Info</h3></div><button onclick="closeModal('update-emp-modal')" class="w-9 h-9 rounded-lg bg-[var(--surface-hover)] flex items-center justify-center text-[var(--text-muted)] hover:text-white"><i class="fas fa-xmark"></i></button></div><div class="space-y-4"><div><label class="text-xs font-bold text-[var(--text-muted)] uppercase tracking-wider mb-2 block">Your Name</label><input type="text" id="update-emp-name" class="input-field" placeholder="Enter new name"></div><div><label class="text-xs font-bold text-[var(--text-muted)] uppercase tracking-wider mb-2 block">Shift</label><select id="update-emp-shift" class="input-field"><option value="Morning">Morning</option><option value="Afternoon">Afternoon</option><option value="Evening">Evening</option><option value="Night">Night</option></select></div><button onclick="saveUpdatedEmpInfo()" class="w-full py-3 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-bold transition-all">Update Info</button></div></div></div>

<div class="modal-backdrop" id="floor-mgmt-modal"><div class="modal" style="max-width:550px;"><div class="flex items-center justify-between mb-6"><div><div class="text-[10px] text-pink-400 font-bold uppercase tracking-wider mb-1">System Management</div><h3 class="font-display font-extrabold text-2xl">Floor Management</h3></div><button onclick="closeModal('floor-mgmt-modal')" class="w-9 h-9 rounded-lg bg-[var(--surface-hover)] flex items-center justify-center text-[var(--text-muted)] hover:text-white"><i class="fas fa-xmark"></i></button></div><div id="floor-auth-section"><input type="text" id="floor-auth-pass" class="input-field mb-3 password-mask" placeholder="Authorization Password" autocomplete="off" onkeydown="handleFloorAuthEnter(event)"><div id="floor-auth-error" class="text-red-400 text-sm text-center font-semibold h-5 mb-3"></div><button onclick="checkFloorAuth()" class="w-full py-3 rounded-xl bg-pink-500 hover:bg-pink-600 text-white font-bold transition-all">Authorize</button></div><div id="floor-mgmt-content" class="hidden"><div id="floor-list-container" class="space-y-2 mb-4 max-h-[50vh] overflow-y-auto pr-2"></div><div class="p-4 rounded-xl bg-[var(--bg)] border border-[var(--border)]"><h4 class="font-bold text-sm mb-3 text-pink-400">Add New Floor</h4><input type="text" id="new-floor-name" class="input-field mb-2" placeholder="Floor Name"><input type="text" id="new-floor-pin" class="input-field mb-3 password-mask" placeholder="4-Digit PIN" maxlength="4" autocomplete="off"><button onclick="addFloor()" class="w-full py-2.5 rounded-lg bg-emerald-500 hover:bg-emerald-600 text-white font-bold text-sm transition-all">Add Floor</button></div></div></div></div>

<div class="modal-backdrop" id="backup-modal"><div class="modal"><div class="flex items-center justify-between mb-6"><div><div class="text-[10px] text-purple-400 font-bold uppercase tracking-wider mb-1">System Data</div><h3 class="font-display font-extrabold text-2xl">Backup &amp; Restore</h3></div><button onclick="closeModal('backup-modal')" class="w-9 h-9 rounded-lg bg-[var(--surface-hover)] flex items-center justify-center text-[var(--text-muted)] hover:text-white"><i class="fas fa-xmark"></i></button></div><div id="backup-auth-section"><input type="text" id="backup-auth-pass" class="input-field mb-3 password-mask" placeholder="Authorization Password" autocomplete="off" onkeydown="handleBackupAuthEnter(event)"><div id="backup-auth-error" class="text-red-400 text-sm text-center font-semibold h-5 mb-3"></div><button onclick="checkBackupAuth()" class="w-full py-3 rounded-xl bg-purple-500 hover:bg-purple-600 text-white font-bold transition-all">Authorize</button></div><div id="backup-content" class="hidden"><div class="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-4"><button onclick="downloadBackup('full')" class="p-4 rounded-xl bg-indigo-500/10 border border-indigo-500/30 hover:bg-indigo-500/20 transition-all text-center"><i class="fas fa-database text-indigo-400 text-xl mb-2"></i><div class="font-bold text-sm">Full System</div></button><button onclick="downloadBackup('daily')" class="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/30 hover:bg-emerald-500/20 transition-all text-center"><i class="fas fa-download text-emerald-400 text-xl mb-2"></i><div class="font-bold text-sm">Daily Backup</div></button><button onclick="downloadBackup('monthly')" class="p-4 rounded-xl bg-violet-500/10 border border-violet-500/30 hover:bg-violet-500/20 transition-all text-center"><i class="fas fa-download text-violet-400 text-xl mb-2"></i><div class="font-bold text-sm">Monthly Backup</div></button></div><div class="p-4 rounded-xl bg-[var(--bg)] border border-[var(--border)]"><label class="text-sm font-bold mb-2 block">Import Backup</label><input type="file" id="import-file" accept=".json" class="input-field mb-3" style="padding:0.5rem;"><button onclick="importBackup()" class="w-full py-2.5 rounded-lg bg-purple-500 hover:bg-purple-600 text-white font-bold text-sm transition-all">Restore Data</button></div></div></div></div>

<div class="modal-backdrop" id="clear-auth-modal"><div class="modal" style="max-width:380px;"><div class="flex items-center justify-between mb-6"><div><div class="text-[10px] text-red-400 font-bold uppercase tracking-wider mb-1">Danger Zone</div><h3 class="font-display font-extrabold text-2xl">Clear All Data</h3></div><button onclick="closeModal('clear-auth-modal')" class="w-9 h-9 rounded-lg bg-[var(--surface-hover)] flex items-center justify-center text-[var(--text-muted)] hover:text-white"><i class="fas fa-xmark"></i></button></div><div class="space-y-4"><p class="text-sm text-[var(--text-muted)]">Safety backup is taken before clearing.</p><input type="text" id="clear-auth-pass" class="input-field text-center password-mask" placeholder="Authorization Password" autocomplete="off" onkeydown="handleClearAuthEnter(event)"><div id="clear-auth-error" class="text-red-400 text-sm text-center font-semibold h-5"></div><button onclick="checkClearAuth()" class="w-full py-3 rounded-xl bg-red-500 hover:bg-red-600 text-white font-bold transition-all">Wipe All Data</button></div></div></div>

<div class="modal-backdrop" id="import-data-modal"><div class="modal" style="max-width:560px;"><div class="flex items-center justify-between mb-5"><div><div class="flex items-center gap-2 mb-1"><div class="w-8 h-8 rounded-lg bg-amber-500/20 flex items-center justify-center"><i class="fas fa-file-import text-amber-400"></i></div><h3 class="font-display font-extrabold text-2xl">JSON → DB Converter</h3></div><p class="text-sm text-[var(--text-muted)] mt-1">Upload your old <code style="background:var(--surface);padding:2px 6px;border-radius:4px;color:var(--accent-glow);">flowdata.json</code> — auto-converts all data to SQLite database</p></div><button onclick="closeModal('import-data-modal')" class="w-9 h-9 rounded-lg bg-[var(--surface-hover)] flex items-center justify-center text-[var(--text-muted)] hover:text-white"><i class="fas fa-xmark"></i></button></div><div class="mb-4 p-4 bg-amber-500/10 border border-amber-500/30 rounded-xl"><div class="flex items-start gap-2"><i class="fas fa-triangle-exclamation text-amber-400 mt-1"></i><div class="text-xs text-amber-200"><strong>Warning:</strong> This will REPLACE all current data (entries, exits, settings, floors, passwords, employees). A safety backup is taken first. Make sure you have a backup.</div></div></div><div class="mb-4 p-3 bg-emerald-500/10 border border-emerald-500/30 rounded-xl"><div class="flex items-center gap-2 text-xs text-emerald-300"><i class="fas fa-circle-check text-emerald-400"></i><span><strong>Auto-converts:</strong> entries, exits, settings, passwords, floors, employees — all migrated to SQLite with latest v3.9 schema</span></div></div><input type="file" id="import-file-input" accept=".json,.db" class="input-field mb-4" style="padding:0.5rem;"><div id="import-status" class="text-sm text-[var(--text-muted)] mb-4"></div><button onclick="performImport()" class="v3-btn-primary w-full"><i class="fas fa-database mr-2"></i> Convert & Import to Database</button></div></div>

<div class="modal-backdrop" id="pass-modal"><div class="modal"><div class="flex items-center justify-between mb-6"><div><div class="text-[10px] text-amber-400 font-bold uppercase tracking-wider mb-1">Security</div><h3 class="font-display font-extrabold text-2xl">Password Manager</h3></div><button onclick="closeModal('pass-modal')" class="w-9 h-9 rounded-lg bg-[var(--surface-hover)] flex items-center justify-center text-[var(--text-muted)] hover:text-white"><i class="fas fa-xmark"></i></button></div><div id="pass-auth-section"><input type="text" id="pass-auth-pass" class="input-field mb-3 text-center password-mask" placeholder="Enter Access Code" autocomplete="off" onkeydown="handlePassAuthEnter(event)"><div id="pass-auth-error" class="text-red-400 text-sm text-center font-semibold h-5 mb-3"></div><button onclick="checkPassAuth()" class="w-full py-3 rounded-xl bg-amber-500 hover:bg-amber-600 text-white font-bold transition-all">Unlock Manager</button></div><div id="pass-mgmt-content" class="hidden"><div class="space-y-4"><div><label class="text-xs font-bold text-[var(--text-muted)] uppercase tracking-wider mb-2 block">Admin Login Password</label><input type="text" id="new-admin-pass" class="input-field"></div><div><label class="text-xs font-bold text-[var(--text-muted)] uppercase tracking-witer mb-2 block">Dashboard User Password</label><input type="text" id="new-dashboard-pass" class="input-field"></div><div><label class="text-xs font-bold text-[var(--text-muted)] uppercase tracking-witer mb-2 block">Floor Management Password</label><input type="text" id="new-floor-mgmt-pass" class="input-field"></div><div><label class="text-xs font-bold text-[var(--text-muted)] uppercase tracking-wider mb-2 block">Backup Password</label><input type="text" id="new-backup-pass" class="input-field"></div><div><label class="text-xs font-bold text-[var(--text-muted)] uppercase tracking-wider mb-2 block">Clear Data Password</label><input type="text" id="new-clear-pass" class="input-field"></div><div><label class="text-xs font-bold text-[var(--text-muted)] uppercase tracking-wider mb-2 block">Password Manager Access Code</label><input type="text" id="new-passmgr-pass" class="input-field"></div><button onclick="savePasswords()" class="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 to-orange-600 text-white font-bold transition-all">Save Passwords</button></div></div></div></div>

<div class="modal-backdrop" id="dev-modal"><div class="modal" style="max-width:420px;"><div class="flex items-center justify-between mb-6"><div><div class="text-[10px] text-cyan-400 font-bold uppercase tracking-wider mb-1">Developer Settings</div><h3 class="font-display font-extrabold text-2xl">Footer Settings</h3><p class="text-xs text-[var(--text-muted)] mt-1">Alt+F10 to open · changes auto-save</p></div><button onclick="closeModal('dev-modal')" class="w-9 h-9 rounded-lg bg-[var(--surface-hover)] flex items-center justify-center text-[var(--text-muted)] hover:text-white"><i class="fas fa-xmark"></i></button></div><div class="space-y-5"><div class="flex items-center justify-between p-3 rounded-xl bg-[var(--bg)] border border-[var(--border)]"><div><div class="font-bold text-sm">Show Footer</div><div class="text-xs text-[var(--text-muted)]">Toggle developer + version bar on all screens</div></div><label class="toggle toggle-cyan"><input type="checkbox" id="footer-enabled-toggle" checked onchange="applyFooterSettings()"><span class="slider-track"></span></label></div><div><label class="text-xs font-bold text-[var(--text-muted)] uppercase tracking-wider mb-2 block">Developer Name</label><input type="text" id="dev-name" class="input-field" placeholder="Developer Name"></div><div><label class="text-xs font-bold text-[var(--text-muted)] uppercase tracking-wider mb-2 block">Version</label><input type="text" id="dev-version" class="input-field" placeholder="Version"></div><div><label class="text-xs font-bold text-[var(--text-muted)] uppercase tracking-wider mb-2 block">Footer Text Color</label><div class="flex items-center gap-2"><input type="color" id="footer-color" class="input-field h-10 cursor-pointer" style="padding:0.25rem;width:60px;" onchange="applyFooterSettings()"><input type="text" id="footer-color-text" class="input-field flex-1" placeholder="#color" onchange="document.getElementById('footer-color').value=this.value;applyFooterSettings()"></div></div><div><label class="text-xs font-bold text-[var(--text-muted)] uppercase tracking-wider mb-2 block">Footer Opacity: <span id="footer-opacity-val">1.0</span></label><input type="range" id="footer-opacity" min="0.2" max="1" step="0.1" value="1" class="w-full" oninput="document.getElementById('footer-opacity-val').textContent=this.value;applyFooterSettings()" style="accent-color:var(--primary);"></div><div><label class="text-xs font-bold text-[var(--text-muted)] uppercase tracking-wider mb-2 block">Footer Bar Width</label><select id="footer-width" class="input-field" onchange="applyFooterSettings()"><option value="100%">Full Width</option><option value="90%">90%</option><option value="80%">80%</option><option value="70%">70%</option><option value="60%">60%</option><option value="50%">50%</option><option value="auto">Auto (content-fit)</option></select></div><button onclick="saveDevInfo()" class="w-full py-3 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-bold transition-all">Save Settings</button></div></div></div>

<div class="msg-popup" id="live-msg-popup"><div class="p-4 border-b border-[var(--border-light)] flex items-center gap-3"><div class="w-10 h-10 rounded-xl bg-pink-500/20 flex items-center justify-center"><i class="fas fa-bell text-pink-400 animate-pulse"></i></div><div><h4 class="font-bold text-sm">Message from Admin</h4><p class="text-xs text-[var(--text-muted)]" id="msg-popup-time">Just now</p></div></div><div class="p-4"><p class="text-sm mb-4" id="msg-popup-body">...</p><textarea id="msg-popup-reply" class="input-field mb-3 text-sm" rows="2" placeholder="Type your reply..."></textarea><button id="msg-popup-close-btn" onclick="closeLiveMsgPopup()" class="w-full py-2 rounded-lg bg-[var(--surface-hover)] text-[var(--text-muted)] font-bold text-sm transition-all">Close</button><button id="msg-popup-reply-btn" class="hidden w-full mt-2 py-2 rounded-lg bg-pink-500 hover:bg-pink-600 text-white font-bold text-sm transition-all" onclick="sendLiveMsgReply()">Send Reply</button></div></div>

<div id="toast-container" class="fixed bottom-14 right-4 z-[600] space-y-2"></div>
<footer class="app-footer" id="app-footer"><div class="footer-bar"><span>Version <span id="footer-version">3.6.0</span></span><span>·</span><span>Developed by <span class="dev-name" id="footer-developer">Sathish</span></span></div></footer>

<script>
// === STORAGE OVERRIDE (MUST BE FIRST - before any other code) ===
// Override window.sessionStorage and window.localStorage with safe proxies.
// In cross-IP / sandboxed-iframe / third-party-cookie-blocking contexts, the browser
// throws "Failed to read the 'sessionStorage' property from 'Window': Access is denied
// for this document." even when you just TRY to read the property. By overriding the
// property descriptor, we replace the throwing getter with our own that returns a
// memory-backed Storage-like object. This makes ALL code (including third-party
// libraries that access window.sessionStorage directly) work without crashing.
(function(){
  // Memory-backed Storage proxy
  var memStoreSS = {};
  var memStoreLS = {};
  function makeProxy(store){
    return {
      getItem: function(k){ return Object.prototype.hasOwnProperty.call(store, k) ? store[k] : null; },
      setItem: function(k, v){ store[k] = String(v); },
      removeItem: function(k){ delete store[k]; },
      clear: function(){ for (var k in store){ if (Object.prototype.hasOwnProperty.call(store, k)) delete store[k]; } },
      key: function(i){ var keys = Object.keys(store); return i < keys.length ? keys[i] : null; },
      get length(){ return Object.keys(store).length; }
    };
  }
  var proxySS = makeProxy(memStoreSS);
  var proxyLS = makeProxy(memStoreLS);

  // Try to get the REAL sessionStorage. If it works, use it. If it throws, use proxy.
  var realSS = null, realLS = null;
  try { realSS = window.sessionStorage; var _k='__t__'; realSS.setItem(_k,'1'); realSS.removeItem(_k); } catch(e) { realSS = null; }
  try { realLS = window.localStorage;   var _k='__t__'; realLS.setItem(_k,'1');  realLS.removeItem(_k);  } catch(e) { realLS = null; }

  // Override the property descriptor so window.sessionStorage always returns a working object
  try {
    Object.defineProperty(window, 'sessionStorage', {
      get: function(){ return realSS || proxySS; },
      configurable: true
    });
    Object.defineProperty(window, 'localStorage', {
      get: function(){ return realLS || proxyLS; },
      configurable: true
    });
  } catch(e) {
    // If defineProperty fails (non-configurable), we can't override but SafeStorage below still works
  }
})();
const REPORTS_CONFIG=[{id:'dashboard',title:'Live Dashboard',icon:'fa-gauge'},{id:'floor-consolidated',title:'Floor Consolidated Summary',icon:'fa-file-lines'},{id:'floor-inout',title:'Floor-wise In/Out Summary',icon:'fa-chart-pie'},{id:'entry-detailed',title:'Customer Entry Detailed Log',icon:'fa-door-open'},{id:'entry-summary-report',title:'Customer Entry Summary',icon:'fa-chart-simple'},{id:'entry-breakdown',title:'Customer Entry Breakdown',icon:'fa-diagram-project'},{id:'exit-detailed',title:'Customer Exit Detailed Log',icon:'fa-door-closed'},{id:'exit-summary',title:'Customer Exit Summary Report',icon:'fa-clipboard-list'},{id:'exit-return',title:'Exit Reason Summary per Floor',icon:'fa-rotate-left'},{id:'exit-others-detailed',title:'Exit Others Detailed Report',icon:'fa-triangle-exclamation'},{id:'entry-source-summary',title:'Way of Source Summary',icon:'fa-route'},{id:'notifications',title:'Live Notifications',icon:'fa-bell'},{id:'company-settings',title:'Company Settings',icon:'fa-building'},{id:'system-settings',title:'System Settings',icon:'fa-gears'},{id:'feature-settings',title:'Feature Settings',icon:'fa-sliders'},{id:'access-control',title:'Access Control',icon:'fa-user-shield'},{id:'live-messages',title:'Live Messages',icon:'fa-paper-plane'},{id:'custom-log',title:'Custom Data Log',icon:'fa-list-check'}];
const state={entries:[],exits:[],floors:[],floorsWithPins:[],employees:[],settings:{companyName:"CustomerFlow",logo:"",primaryColor:"#ec4899",companyFont:"'Bricolage Grotesque', sans-serif",entryColor:"#0ea5e9",exitColor:"#10b981",version:"3.6.0",developer:"Sathish",footerSettings:{enabled:true,color:"#a1a1aa",opacity:1,width:"100%"},network:{mode:"HO",branchName:"",hoUrl:"",branchUrls:[]},autoBackup:{enabled:true,time:"02:00",retentionDays:10},backupLocation:"backups",enableEmployeeName:false,enableAdminCall:false,enableIcons:true,enableEntrySound:true,enableExitSound:true,enableWayOfSource:true,enableNewUI:true,dashboardAccess:["dashboard"],wayOfSources:[{name:"Direct Visit",icon:"fa-store",customEnabled:false,enabled:true},{name:"Social Media",icon:"fa-share-nodes",customEnabled:false,enabled:true},{name:"Advertisement / Newspaper",icon:"fa-newspaper",customEnabled:false,enabled:true},{name:"Referral",icon:"fa-user-group",customEnabled:false,enabled:true},{name:"Others",icon:"fa-ellipsis",customEnabled:true,enabled:true}],returnReasons:[{name:'High Wastage',commentEnabled:false,imageEnabled:false,mobileEnabled:false,mobileRequired:false,icon:'fa-money-bill-wave'},{name:'Design Not Satisfied',commentEnabled:false,imageEnabled:false,mobileEnabled:false,mobileRequired:false,icon:'fa-pen-ruler'},{name:'Just Visit',commentEnabled:false,imageEnabled:false,mobileEnabled:false,mobileRequired:false,icon:'fa-eye'},{name:'Other',commentEnabled:false,imageEnabled:false,mobileEnabled:false,mobileRequired:false,icon:'fa-ellipsis'}],enablePurchaseSource:false,purchaseSources:[{name:"In-Store Walk-in",icon:"fa-store",customEnabled:false,enabled:true},{name:"Online Order",icon:"fa-cart-shopping",customEnabled:false,enabled:true},{name:"Phone Order",icon:"fa-phone",customEnabled:false,enabled:true},{name:"WhatsApp",icon:"fa-whatsapp",customEnabled:false,enabled:true},{name:"Others",icon:"fa-ellipsis",customEnabled:true,enabled:true}],enableReturnWayOfEntry:false,returnWayOfEntries:[{name:"Same Day Return",icon:"fa-rotate-left",customEnabled:false,enabled:true},{name:"Next Day Return",icon:"fa-clock-rotate-left",customEnabled:false,enabled:true},{name:"Within Week",icon:"fa-calendar-week",customEnabled:false,enabled:true},{name:"Others",icon:"fa-ellipsis",customEnabled:true,enabled:true}]},messages:[],currentFloor:null,currentReport:'dashboard',lastEntryCount:0,lastExitCount:0,isAdmin:false,isDashboardUser:false,currentDashReport:'dashboard',selectedFloors:[],lastMessageCount:0,currentEmployee:null,callState:null,peerConnection:null,localStream:null,callTimer:null,callStartTime:null,selectedReason:null,pendingEntryCategory:null,pendingEntrySource:null};
const reportFilterStates={};const SERVER_API='api';let autoBackupIntervalId=null;let lastRenderedDataHash='';let callCheckInterval=null;let isSaving=false;
document.addEventListener('contextmenu',e=>e.preventDefault());
document.addEventListener('keydown',e=>{if(e.key==='F12'||(e.ctrlKey&&e.shiftKey&&(e.key==='I'||e.key==='J'||e.key==='C'))||(e.ctrlKey&&e.key==='U')||(e.ctrlKey&&e.key==='S')){e.preventDefault();return false;}});
document.addEventListener('keydown',function(e){if(e.altKey&&e.key==='F10'){e.preventDefault();openFooterSettings();}});
document.addEventListener('input',(e)=>{if(e.target.id==='other-reason-mobile-input'||e.target.id==='reason-mobile-input'){e.target.value=e.target.value.replace(/[^0-9]/g,'');}});

let audioCtx=null;function unlockAudio(){if(!audioCtx){try{audioCtx=new(window.AudioContext||window.webkitAudioContext)();}catch(e){}}if(audioCtx&&audioCtx.state==='suspended')audioCtx.resume();}
document.body.addEventListener('click',unlockAudio,{once:true});document.body.addEventListener('touchstart',unlockAudio,{once:true});
function playSound(t){if(!audioCtx)unlockAudio();if(!audioCtx)return;try{const o=audioCtx.createOscillator(),o2=audioCtx.createOscillator(),g=audioCtx.createGain();o.connect(g);o2.connect(g);g.connect(audioCtx.destination);let f=[],tw='square',v=0.6;if(t==='entry_single'){f=[523.25,659.25];tw='square';}else if(t==='entry_couple'){f=[587.33,739.99,880];tw='triangle';}else if(t==='entry_family'){f=[659.25,783.99,987.77,1174.66];tw='triangle';}else if(t==='entry_complete'){f=[783.99,1046.50,1318.51];tw='sine';v=0.5;}else if(t==='exit_purchase'){f=[659.25,880,1046.50];tw='sine';v=0.55;}else if(t==='exit_return'){f=[440,392,349.23,293.66];tw='sawtooth';v=0.5;}else if(t==='exit_reason_submit'){f=[523.25,440,349.23];tw='triangle';v=0.5;}else if(t==='entry'){f=[523.25,659.25];}else if(t==='exit'){f=[659.25,523.25];tw='sawtooth';}else if(t==='admin_alert'){f=[659.25,880,659.25,880];tw='triangle';v=0.5;}else if(t==='floor_alert'){f=[440,523.25,659.25,783.99];tw='sine';}else if(t==='call_ring'){f=[800,1000,800,1000];tw='sine';v=0.7;}else{f=[523.25];}o.type=tw;o2.type='sine';o.frequency.setValueAtTime(f[0],audioCtx.currentTime);o2.frequency.setValueAtTime(f[0]/2,audioCtx.currentTime);f.forEach((fr,i)=>{if(i>0){o.frequency.setValueAtTime(fr,audioCtx.currentTime+(i*0.12));o2.frequency.setValueAtTime(fr/2,audioCtx.currentTime+(i*0.12));}});g.gain.setValueAtTime(v,audioCtx.currentTime);g.gain.exponentialRampToValueAtTime(0.001,audioCtx.currentTime+(f.length*0.12)+0.1);o.start();o2.start();o.stop(audioCtx.currentTime+(f.length*0.12)+0.1);o2.stop(audioCtx.currentTime+(f.length*0.12)+0.1);}catch(e){}}
// === Desktop Notifications ===
// Fires native OS notifications when the tab is minimized, in background, or unfocused.
// Works even when browser is minimized — the OS shows a native toast + plays the default sound.
// Combined with playSound() above, this ensures alerts are seen/heard even when the tab is hidden.
let _notifPermissionRequested=false;
function requestNotificationPermission(){
  if(_notifPermissionRequested)return;
  _notifPermissionRequested=true;
  try{
    if(!('Notification' in window))return;
    if(Notification.permission==='granted'||Notification.permission==='denied')return;
    // Request permission silently on first user interaction (browsers require a user gesture)
    const askOnce=()=>{Notification.requestPermission().then(()=>{});document.removeEventListener('click',askOnce);document.removeEventListener('keydown',askOnce);document.removeEventListener('touchstart',askOnce);};
    document.addEventListener('click',askOnce);
    document.addEventListener('keydown',askOnce);
    document.addEventListener('touchstart',askOnce);
  }catch(e){}
}
function fireDesktopNotification(title,body,tag){
  try{
    if(!('Notification' in window))return;
    if(Notification.permission!=='granted')return;
    // Only fire if the tab is hidden OR window is blurred (minimized or another app is focused)
    const isHidden=document.hidden||document.webkitHidden||!document.hasFocus();
    if(!isHidden)return;
    const opts={body:body,tag:tag||'cf-notif',icon:state.settings.logo||'',requireInteraction:false,silent:true};
    // requireInteraction:false = auto-dismiss; silent:true = we play our own sound via playSound()
    const n=new Notification(title,opts);
    // Auto-close after 8 seconds
    setTimeout(()=>{try{n.close();}catch(e){}},8000);
    // On click, focus the window
    n.onclick=()=>{try{window.focus();n.close();}catch(e){}};
  }catch(e){}
}

function extractValidJson(t){const fb=t.indexOf('{');if(fb===-1)return t;let d=0,is=false;for(let i=fb;i<t.length;i++){const c=t[i];if(c==='\\'&&i+1<t.length)i++;else if(c==='"')is=!is;else if(!is){if(c==='{')d++;else if(c==='}'){d--;if(d===0)return t.substring(fb,i+1);}}}return t;}
function shouldPausePolling(){if(document.hidden)return true;if(navigator.connection&&navigator.connection.saveData)return true;const a=document.activeElement;if(!a)return false;if(['INPUT','TEXTAREA','SELECT'].includes(a.tagName)){if(a.closest('#report-content')||a.closest('.modal-backdrop.active'))return true;}return false;}
function getPollInterval(){const isMobile=/Mobi|Android|iPhone|iPad|iPod/i.test(navigator.userAgent);if(document.hidden)return 15000;if(isMobile)return 5000;return 3000;}
async function fetchServerData(){if(isSaving){setTimeout(fetchServerData,2000);return;}if(shouldPausePolling()){setTimeout(fetchServerData,getPollInterval());return;}let so={status:'checking',reason:'Init...',location:'Frontend',troubleshooting:'Waiting...',timestamp:new Date().toLocaleTimeString()};const fetchStart=Date.now();try{const r=await fetch(SERVER_API+'?action=getData',{cache:'no-cache',credentials:'same-origin'});if(!r.ok){if(r.status===404)so={status:'disconnected',reason:'HTTP 404',location:'API',troubleshooting:'Check webapps.'};else if(r.status===500)so={status:'disconnected',reason:'HTTP 500',location:'Backend',troubleshooting:'Check catalina.log'};else so={status:'disconnected',reason:'HTTP '+r.status,location:'API',troubleshooting:'Review logs'};updateSyncStatus(so);return;}const td=await r.text();try{const js=extractValidJson(td);const data=JSON.parse(js);if(data.setupRequired){window.location.href='setup.jsp';return;}if(data.error){so={status:'disconnected',reason:data.error,location:'Backend',troubleshooting:'Check perms.'};updateSyncStatus(so);return;}if(data.floors&&Array.isArray(data.floors))state.floors=data.floors;state.entries=data.entries||[];state.exits=data.exits||[];const oldS=JSON.stringify(state.settings);
if(data.settings && Object.keys(data.settings).length > 0) { state.settings = data.settings; }
if(!state.settings.network)state.settings.network={mode:"HO",branchName:"",hoUrl:"",branchUrls:[]};if(!state.settings.network.branchUrls)state.settings.network.branchUrls=[];if(!state.settings.autoBackup)state.settings.autoBackup={enabled:true,time:"02:00",retentionDays:10};else{if(!state.settings.autoBackup.time||state.settings.autoBackup.time==="")state.settings.autoBackup.time="02:00";if(!state.settings.autoBackup.retentionDays)state.settings.autoBackup.retentionDays=10;delete state.settings.autoBackup.interval;}if(!state.settings.backupLocation)state.settings.backupLocation="backups";if(!state.settings.dashboardAccess)state.settings.dashboardAccess=["dashboard"];if(state.settings.enableEmployeeName===undefined)state.settings.enableEmployeeName=false;if(state.settings.enableAdminCall===undefined)state.settings.enableAdminCall=false;if(state.settings.enableIcons===undefined)state.settings.enableIcons=true;if(state.settings.enableEntrySound===undefined)state.settings.enableEntrySound=true;if(state.settings.enableExitSound===undefined)state.settings.enableExitSound=true;if(state.settings.enableNewUI===undefined)state.settings.enableNewUI=true;
if(!state.settings.wayOfSources||!Array.isArray(state.settings.wayOfSources)||state.settings.wayOfSources.length===0)state.settings.wayOfSources=[{name:"Direct Visit",icon:"fa-store",customEnabled:false,enabled:true},{name:"Social Media",icon:"fa-share-nodes",customEnabled:false,enabled:true},{name:"Advertisement / Newspaper",icon:"fa-newspaper",customEnabled:false,enabled:true},{name:"Referral",icon:"fa-user-group",customEnabled:false,enabled:true},{name:"Others",icon:"fa-ellipsis",customEnabled:true,enabled:true}];
else state.settings.wayOfSources=state.settings.wayOfSources.map(s=>{if(typeof s==='string')return{name:s,icon:'fa-tag',customEnabled:false,enabled:true};const o={icon:'fa-tag',customEnabled:false,...s};if(o.enabled===undefined)o.enabled=true;return o;});
if(!state.settings.returnReasons||!Array.isArray(state.settings.returnReasons)||state.settings.returnReasons.length===0)state.settings.returnReasons=[{name:'High Wastage',commentEnabled:false,imageEnabled:false,mobileEnabled:false,mobileRequired:false,icon:'fa-money-bill-wave'},{name:'Design Not Satisfied',commentEnabled:false,imageEnabled:false,mobileEnabled:false,mobileRequired:false,icon:'fa-pen-ruler'},{name:'Just Visit',commentEnabled:false,imageEnabled:false,mobileEnabled:false,mobileRequired:false,icon:'fa-eye'},{name:'Other',commentEnabled:false,imageEnabled:false,mobileEnabled:false,mobileRequired:false,icon:'fa-ellipsis'}];
else state.settings.returnReasons=state.settings.returnReasons.map(r=>typeof r==='string'?{name:r,commentEnabled:false,imageEnabled:false,mobileEnabled:false,mobileRequired:false,icon:'fa-triangle-exclamation'}:{icon:'fa-triangle-exclamation',commentEnabled:false,imageEnabled:false,mobileEnabled:false,mobileRequired:false,...r});
if(!state.settings.purchaseSources||!Array.isArray(state.settings.purchaseSources)||state.settings.purchaseSources.length===0)state.settings.purchaseSources=[{name:"In-Store Walk-in",icon:"fa-store",customEnabled:false,enabled:true},{name:"Online Order",icon:"fa-cart-shopping",customEnabled:false,enabled:true},{name:"Phone Order",icon:"fa-phone",customEnabled:false,enabled:true},{name:"WhatsApp",icon:"fa-whatsapp",customEnabled:false,enabled:true},{name:"Others",icon:"fa-ellipsis",customEnabled:true,enabled:true}];
else state.settings.purchaseSources=state.settings.purchaseSources.map(s=>{if(typeof s==='string')return{name:s,icon:'fa-tag',customEnabled:false,enabled:true};const o={icon:'fa-tag',customEnabled:false,...s};if(o.enabled===undefined)o.enabled=true;return o;});
if(state.settings.enablePurchaseSource===undefined)state.settings.enablePurchaseSource=false;
if(!state.settings.returnWayOfEntries||!Array.isArray(state.settings.returnWayOfEntries)||state.settings.returnWayOfEntries.length===0)state.settings.returnWayOfEntries=[{name:"Same Day Return",icon:"fa-rotate-left",customEnabled:false,enabled:true},{name:"Next Day Return",icon:"fa-clock-rotate-left",customEnabled:false,enabled:true},{name:"Within Week",icon:"fa-calendar-week",customEnabled:false,enabled:true},{name:"Others",icon:"fa-ellipsis",customEnabled:true,enabled:true}];
else state.settings.returnWayOfEntries=state.settings.returnWayOfEntries.map(w=>{if(typeof w==='string')return{name:w,icon:'fa-tag',customEnabled:false,enabled:true};const o={icon:'fa-tag',customEnabled:false,...w};if(o.enabled===undefined)o.enabled=true;return o;});
if(state.settings.enableReturnWayOfEntry===undefined)state.settings.enableReturnWayOfEntry=false;
if(!state.settings.footerSettings)state.settings.footerSettings={enabled:true,color:"#a1a1aa",opacity:1,width:"100%"};
if(!state.settings.tagline)state.settings.tagline="";
state.messages=data.messages||[];state.employees=data.employees||[];const sChanged=JSON.stringify(state.settings)!==oldS;try{applyBrandUI();applyTheme();setupAutoBackup();renderFloorCheckboxes();renderReasonFilter();renderDashFloorCheckboxes();renderDashReasonFilter();}catch(e){console.error('Settings apply error:',e);}if(sChanged||!document.getElementById('screen-login').classList.contains('hidden'))updateLoginFields();const ia=!document.getElementById('screen-admin').classList.contains('hidden');const idash=!document.getElementById('screen-dashboard').classList.contains('hidden');const ifl=!document.getElementById('screen-home').classList.contains('hidden');if(ia){try{renderSidebarNav();}catch(e){console.error('Sidebar render error:',e);}if(state.entries.length>state.lastEntryCount&&state.lastEntryCount!==0){const le=state.entries[state.entries.length-1];const entryText='Entry: '+le.floor+' - '+le.category+(le.wayOfSource?' ('+le.wayOfSource+')':'');if(state.settings.enableEntrySound){playSound('admin_alert');}fireDesktopNotification('Customer Entry',entryText,le.floor+' Entry');}if(state.exits.length>state.lastExitCount&&state.lastExitCount!==0){const lx=state.exits[state.exits.length-1];const exitText='Exit: '+lx.floor+' - '+(lx.type||'')+(lx.reason?' ('+lx.reason+')':'');if(state.settings.enableExitSound){playSound('admin_alert');}fireDesktopNotification('Customer Exit',exitText,lx.floor+' Exit');}}state.lastExitCount=state.exits.length;state.lastEntryCount=state.entries.length;if(ifl&&state.currentFloor){checkLiveMessages();}if(idash&&state.isDashboardUser){try{renderDashSidebar();renderDashReport();}catch(e){console.error('Dash render error:',e);}}try{updateUI();}catch(e){console.error('UI update error:',e);}so={status:'connected',reason:'Connected',location:'-',troubleshooting:'-',latency:(Date.now()-fetchStart)};updateSyncStatus(so);}catch(je){console.error('fetchServerData error:',je);so={status:'disconnected',reason:'JSON: '+je.message,location:'Data',troubleshooting:'JSON corrupted.'};updateSyncStatus(so);}}catch(ne){so={status:'disconnected',reason:'Network/CORS: '+ne.message,location:'Network/CORS',troubleshooting:'1. Tomcat running\n2. CORS headers\n3. Same WiFi\n4. Firewall\n5. Exact IP+port'};updateSyncStatus(so);}}
function setupAutoBackup(){/* v3.2: Auto-backup is now SERVER-SIDE only (daily at set time via BackupManager Timer). Frontend no longer triggers interval backups — only the daily time-based backup runs. */if(autoBackupIntervalId)clearInterval(autoBackupIntervalId);autoBackupIntervalId=null;}
function setupCallPolling(){if(callCheckInterval)clearInterval(callCheckInterval);if(state.settings.enableAdminCall&&state.currentFloor&&!document.getElementById('screen-home').classList.contains('hidden')){const isMobile=/Mobi|Android|iPhone|iPad|iPod/i.test(navigator.userAgent);callCheckInterval=setInterval(checkIncomingCall,isMobile?4000:2000);}}
// === SafeStorage wrapper ===
// Browsers throw "Failed to read the 'sessionStorage' property from 'Window': Access is denied for this document"
// when the page is loaded from a different IP/host than the service is bound to (cross-origin, sandboxed iframe,
// or third-party cookie/storage blocking). This wrapper detects that case and falls back to an in-memory Map,
// so the app keeps working instead of crashing on initSystem / login / logout.
//
// USAGE: All persistent state (cf_floor, cf_admin, cf_dash) MUST go through SafeStorage, NEVER direct
// sessionStorage/localStorage. SafeStorage auto-detects availability and degrades gracefully.
//
// Helper: try to access the sessionStorage property without throwing. In some browsers (sandboxed iframes,
// strict third-party storage blocking, file:// protocol, private mode in older browsers), even READING
// window.sessionStorage throws a SecurityError. This helper isolates that throw.
function __cf_tryGetSessionStorage(){
  try {
    // Some browsers expose sessionStorage but accessing it throws. We probe carefully.
    var ss = window.sessionStorage;
    if (!ss) return null;
    // Verify it actually works (some browsers return a broken object)
    var k = '__cf_probe_' + Math.random();
    ss.setItem(k, '1');
    ss.removeItem(k);
    return ss;
  } catch (e) {
    // Storage blocked - return null, fall back to memory
    return null;
  }
}
function __cf_tryGetLocalStorage(){
  try {
    var ls = window.localStorage;
    if (!ls) return null;
    var k = '__cf_probe_' + Math.random();
    ls.setItem(k, '1');
    ls.removeItem(k);
    return ls;
  } catch (e) {
    return null;
  }
}
const SafeStorage = (function(){
  let backend = null;
  let backendName = 'memory';
  const memStore = new Map();
  // Probe sessionStorage first, then localStorage, then fall back to in-memory
  try {
    const ss = __cf_tryGetSessionStorage();
    if (ss) {
      backend = ss;
      backendName = 'sessionStorage';
    } else {
      const ls = __cf_tryGetLocalStorage();
      if (ls) {
        backend = ls;
        backendName = 'localStorage';
      }
    }
  } catch (e) {
    backend = null;
    backendName = 'memory';
  }
  if (backendName === 'memory') {
    console.warn('[SafeStorage] sessionStorage AND localStorage are blocked. Using in-memory storage. Logins will not persist across page reloads. Reason: cross-origin iframe, third-party storage blocking, or sandboxed iframe without allow-same-origin.');
  } else {
    console.info('[SafeStorage] Using backend:', backendName);
  }
  return {
    name: function(){ return backendName; },
    isPersistent: function(){ return backend !== null; },
    getItem: function(key){
      if (backend) {
        try { return backend.getItem(key); } catch (e) { /* fall through */ }
      }
      return memStore.has(key) ? memStore.get(key) : null;
    },
    setItem: function(key, value){
      if (backend) {
        try { backend.setItem(key, value); return; } catch (e) { /* fall through */ }
      }
      memStore.set(key, value);
    },
    removeItem: function(key){
      if (backend) {
        try { backend.removeItem(key); return; } catch (e) { /* fall through */ }
      }
      memStore.delete(key);
    }
  };
})();
// Global error/rejection handlers - suppress any storage-access errors that escape SafeStorage
// (e.g., browser console errors that don't actually break the app, but clutter the UI).
window.addEventListener('error', function(e){
  if (e && e.message && (
    e.message.indexOf('sessionStorage') !== -1 ||
    e.message.indexOf('localStorage') !== -1 ||
    e.message.indexOf('Access is denied for this document') !== -1 ||
    e.message.indexOf("Failed to read the 'sessionStorage'") !== -1 ||
    e.message.indexOf("Failed to read the 'localStorage'") !== -1
  )) {
    console.warn('[Suppressed] Storage access error:', e.message);
    e.preventDefault();
    e.stopPropagation();
    return true;
  }
});
window.addEventListener('unhandledrejection', function(e){
  if (e && e.reason && e.reason.message && (
    e.reason.message.indexOf('sessionStorage') !== -1 ||
    e.reason.message.indexOf('localStorage') !== -1 ||
    e.reason.message.indexOf('Access is denied') !== -1
  )) {
    console.warn('[Suppressed] Unhandled storage rejection:', e.reason.message);
    e.preventDefault();
    return true;
  }
});
// Show a one-time storage-status banner so the user knows whether their login will persist
// across page reloads. Hidden automatically after 6 seconds. Skipped if storage works.
function __cf_showStorageBanner(){
  try {
    const backend = SafeStorage.name();
    if (backend === 'memory') {
      const existing = document.getElementById('cf-storage-banner');
      if (existing) existing.remove();
      const banner = document.createElement('div');
      banner.id = 'cf-storage-banner';
      banner.style.cssText = 'position:fixed;top:8px;left:50%;transform:translateX(-50%);z-index:99999;background:#7c2d12;color:#fef3c7;border:1px solid #b45309;padding:8px 16px;border-radius:8px;font-family:system-ui,sans-serif;font-size:12px;font-weight:600;box-shadow:0 4px 12px rgba(0,0,0,0.3);max-width:90vw;text-align:center;';
      banner.innerHTML = '⚠ Storage access blocked by browser (cross-IP / iframe / privacy mode). Using in-memory session — logins will persist on F5 via window.name backup.';
      document.body.appendChild(banner);
      setTimeout(()=>{if(banner&&banner.parentNode)banner.parentNode.removeChild(banner);}, 8000);
    }
  } catch(e) {}
}
// === PersistentSession ===
// Survives F5 refresh using window.name as backup when sessionStorage/localStorage are blocked.
// window.name persists across same-tab page reloads, so the user stays logged in on F5.
// Only the explicit Logout buttons call PersistentSession.clear().
const PersistentSession = (function(){
  const KEY = 'cf_session_v1';
  // Try to read from SafeStorage first, then fall back to window.name
  function readRaw(){
    try {
      const v = SafeStorage.getItem(KEY);
      if (v) return v;
    } catch(e){}
    try {
      const wn = window.name || '';
      // window.name may contain our JSON-encoded session
      if (wn.indexOf('__cf_session__:') === 0) {
        return wn.substring('__cf_session__:'.length);
      }
    } catch(e){}
    return null;
  }
  function writeRaw(v){
    try { SafeStorage.setItem(KEY, v); } catch(e){}
    try {
      // Also mirror to window.name so F5 in same tab restores it even if storage is blocked
      if (v === null || v === undefined || v === '') {
        // Only clear window.name if it currently holds our session marker
        if ((window.name||'').indexOf('__cf_session__:') === 0) window.name = '';
      } else {
        window.name = '__cf_session__:' + v;
      }
    } catch(e){}
  }
  return {
    save: function(sessionObj){
      try { writeRaw(JSON.stringify(sessionObj)); } catch(e){}
    },
    load: function(){
      try {
        const raw = readRaw();
        if (!raw) return null;
        const obj = JSON.parse(raw);
        if (obj && typeof obj === 'object') return obj;
        return null;
      } catch(e){ return null; }
    },
    clear: function(){
      try { SafeStorage.removeItem(KEY); } catch(e){}
      try {
        if ((window.name||'').indexOf('__cf_session__:') === 0) window.name = '';
      } catch(e){}
    }
  };
})();
// Save session state before F5/navigate-away so it can be restored on next load in same tab
window.addEventListener('beforeunload', function(){
  try {
    const session = {
      floor: state.currentFloor || null,
      admin: state.isAdmin ? 'true' : 'false',
      dash: state.isDashboardUser ? 'true' : 'false',
      dashReport: state.currentDashReport || 'dashboard'
    };
    PersistentSession.save(session);
  } catch(e){}
});
function initSystem(){fetchServerData();setInterval(()=>{if(!document.hidden)fetchServerData();},getPollInterval());setupAutoBackup();requestNotificationPermission();
  document.addEventListener('visibilitychange',()=>{if(!document.hidden)fetchServerData();});
  // Restore session: try SafeStorage first (cross-tab), then window.name backup (same-tab F5)
  const persisted = PersistentSession.load();
  const sf = persisted && persisted.floor ? persisted.floor : SafeStorage.getItem('cf_floor');
  if(sf){state.currentFloor=sf;document.getElementById('current-floor-display').textContent=sf;showScreen('screen-home');loadEmployeeForFloor(sf);}
  const sa = persisted && persisted.admin === 'true' ? 'true' : SafeStorage.getItem('cf_admin');
  if(sa==='true'){state.isAdmin=true;renderSidebarNav();showScreen('screen-admin');openReport('dashboard');}
  const sd = persisted && persisted.dash === 'true' ? 'true' : SafeStorage.getItem('cf_dash');
  if(sd==='true'){state.isDashboardUser=true;renderDashSidebar();showScreen('screen-dashboard');renderDashFloorCheckboxes();renderDashReasonFilter();updateDashFloorFilterLabel();const savedDashReport=(persisted&&persisted.dashReport)||SafeStorage.getItem('cf_dash_report');const allowed=state.settings.dashboardAccess||['dashboard'];const initialReport=(savedDashReport&&allowed.includes(savedDashReport))?savedDashReport:'dashboard';openDashReport(initialReport);}
  setTimeout(__cf_showStorageBanner, 1500);}

function updateLoginFields(){const ef=document.getElementById('emp-name-field'),sf=document.getElementById('emp-shift-field'),ub=document.getElementById('update-emp-btn');if(state.settings.enableEmployeeName){ef.classList.remove('hidden');sf.classList.remove('hidden');if(state.currentFloor)ub.classList.remove('hidden');}else{ef.classList.add('hidden');sf.classList.add('hidden');ub.classList.add('hidden');state.currentEmployee=null;document.getElementById('login-emp-name').value='';document.getElementById('update-emp-name').value='';}}

async function loadEmployeeForFloor(f){if(!state.settings.enableEmployeeName){state.currentEmployee=null;document.getElementById('login-emp-name').value='';return;}try{const r=await fetch(SERVER_API+'?action=getEmployee&floor='+encodeURIComponent(f));const d=await r.json();if(d.name){state.currentEmployee=d;document.getElementById('login-emp-name').value=d.name||'';document.getElementById('login-emp-shift').value=d.shift||'Morning';}else state.currentEmployee=null;}catch(e){state.currentEmployee=null;}}
function getGlowColor(h){let c=h.replace('#','');if(c.length===6){let r=parseInt(c.substring(0,2),16),g=parseInt(c.substring(2,4),16),b=parseInt(c.substring(4,6),16);r=Math.min(255,r+40);g=Math.min(255,g+40);b=Math.min(255,b+40);return`rgb(${r},${g},${b})`;}return h;}
function applyTheme(){document.documentElement.style.setProperty('--primary',state.settings.primaryColor);document.documentElement.style.setProperty('--primary-glow',getGlowColor(state.settings.primaryColor));document.documentElement.style.setProperty('--entry-neon',state.settings.entryColor);document.documentElement.style.setProperty('--entry-glow',getGlowColor(state.settings.entryColor));document.documentElement.style.setProperty('--exit-neon',state.settings.exitColor);document.documentElement.style.setProperty('--exit-glow',getGlowColor(state.settings.exitColor));applyNewUIClass();}
function applyNewUIClass(){if(state.settings.enableNewUI)document.body.classList.add('new-ui');else document.body.classList.remove('new-ui');}
function applyBrandUI(){const s=state.settings;if(s.companyName){document.getElementById('login-brand-name').innerText=s.companyName;document.getElementById('top-brand-name').innerText=s.companyName;document.getElementById('sidebar-brand-name').innerText=s.companyName;if(document.getElementById('sidebar-brand-name-dash'))document.getElementById('sidebar-brand-name-dash').innerText=s.companyName;}if(s.companyFont){document.getElementById('login-brand-name').style.fontFamily=s.companyFont;document.getElementById('top-brand-name').style.fontFamily=s.companyFont;document.getElementById('sidebar-brand-name').style.fontFamily=s.companyFont;}if(s.logo){const lh=`<img src="${s.logo}" alt="Logo">`;document.getElementById('login-logo-cont').innerHTML=lh;document.getElementById('top-brand-icon').innerHTML=lh;document.getElementById('sidebar-logo-cont').innerHTML=lh;/* Set company logo as browser favicon + apple touch icon */const fav=document.getElementById('favicon-link');if(fav){fav.href=s.logo;}const apple=document.getElementById('apple-touch-icon');if(apple){apple.href=s.logo;}}if(s.version)document.getElementById('footer-version').innerText=s.version;if(s.developer)document.getElementById('footer-developer').innerText=s.developer;if(s.tagline!==undefined){const t=document.getElementById('login-tagline');if(t){if(s.tagline&&s.tagline.trim()){const lines=s.tagline.split(/\n/);let html='';lines.forEach((line,i)=>{const isLast=(i===lines.length-1);if(isLast){html+='<strong>'+escapeHtml(line)+'</strong>';}else{html+=escapeHtml(line)+'<br>';}});t.innerHTML=html;t.style.display='block';}else{t.innerHTML='';t.style.display='none';}}}applyFooterVisibility();updateDocumentTitle();}
function updateDocumentTitle(){const c=state.settings.companyName||'CustomerFlow';let t=c;const ia=!document.getElementById('screen-admin').classList.contains('hidden'),idash=!document.getElementById('screen-dashboard').classList.contains('hidden'),ih=!document.getElementById('screen-home').classList.contains('hidden'),il=!document.getElementById('screen-login').classList.contains('hidden')||!document.getElementById('screen-admin-login').classList.contains('hidden')||!document.getElementById('screen-dashboard-login').classList.contains('hidden');if(ia){const rc=REPORTS_CONFIG.find(r=>r.id===state.currentReport);t=`${rc?rc.title:'Admin'} | ${c}`;}else if(idash){const rc=REPORTS_CONFIG.find(r=>r.id===state.currentDashReport);t=`${rc?rc.title:'Dashboard'} | ${c}`;}else if(ih&&state.currentFloor){const td=getTodayStr();const fe=state.entries.filter(e=>e.floor===state.currentFloor&&e.date===td).length;const fx=state.exits.filter(e=>e.floor===state.currentFloor&&e.date===td).length;t=`[${Math.max(0,fe-fx)} in] ${state.currentFloor} | ${c}`;}else if(il)t=`${c} - Login`;document.title=t;}
function checkLiveMessages(){if(state.messages.length>state.lastMessageCount){const lm=state.messages[state.messages.length-1];if(lm.target==='All'||lm.target===state.currentFloor){if(!lm.replies||!lm.replies.some(r=>r.floor===state.currentFloor))showLiveMessagePopup(lm);}}state.lastMessageCount=state.messages.length;}
function showLiveMessagePopup(m){document.getElementById('msg-popup-body').innerText=m.text;document.getElementById('msg-popup-time').innerText=new Date(m.timestamp).toLocaleTimeString();document.getElementById('live-msg-popup').classList.add('active');playSound('floor_alert');const rb=document.getElementById('msg-popup-reply-btn'),cb=document.getElementById('msg-popup-close-btn'),ri=document.getElementById('msg-popup-reply');if(m.replyRequired){rb.classList.remove('hidden');ri.classList.remove('hidden');cb.classList.add('hidden');ri.focus();}else{rb.classList.add('hidden');ri.classList.add('hidden');cb.classList.remove('hidden');setTimeout(()=>closeLiveMsgPopup(),2000);}ri.dataset.msgId=m.id;}
function closeLiveMsgPopup(){document.getElementById('live-msg-popup').classList.remove('active');document.getElementById('msg-popup-reply').value='';}
async function sendLiveMsgReply(){const i=document.getElementById('msg-popup-reply');const t=i.value.trim();if(!t)return showToast('Type a reply','error');const id=i.dataset.msgId;try{await fetch(SERVER_API+'?action=addReply&msgId='+id+'&text='+encodeURIComponent(t)+'&floor='+encodeURIComponent(state.currentFloor||'')+(_floorPin?'&pin='+encodeURIComponent(_floorPin):''));showToast('Reply sent','success');closeLiveMsgPopup();}catch(e){showToast('Failed','error');}}
function updateSyncStatus(s){let ip='?';try{ip=new URL(SERVER_API,window.location.origin).hostname;}catch(e){}/* v3.12: Signal strength bars + live latency on both screens */let latency=s.latency||0;let bars=0;if(s.status==='connected'){bars=latency<50?5:latency<100?4:latency<200?3:latency<500?2:1;}else if(s.status==='checking'){bars=1;}else{bars=0;}/* Update floor home signal badge */const sh=document.getElementById('signal-strength-home'),sth=document.getElementById('signal-text-home');if(sh){sh.className='signal-strength-badge '+(s.status==='connected'?(latency<200?'connected':'weak'):s.status==='checking'?'weak':'offline');const sigBars=sh.querySelectorAll('.sig-bar');sigBars.forEach((bar,i)=>{if(i<bars)bar.classList.add('active');else bar.classList.remove('active');});if(sth){if(s.status==='connected')sth.textContent=latency+'ms';else if(s.status==='checking')sth.textContent='...';else sth.textContent='OFF';}}/* Update admin signal badge */const sa=document.getElementById('signal-strength-admin'),sta=document.getElementById('signal-text-admin');if(sa){sa.className='signal-strength-badge '+(s.status==='connected'?(latency<200?'connected':'weak'):s.status==='checking'?'weak':'offline');if(sta){if(s.status==='connected')sta.textContent=latency+'ms · '+ip;else if(s.status==='checking')sta.textContent='Checking...';else sta.textContent='OFF';}}/* Update admin status card */const ab=document.getElementById('admin-status-icon-bg'),at=document.getElementById('admin-status-text'),atm=document.getElementById('status-time');if(at){if(s.status==='connected'){if(ab)ab.className='w-10 h-10 rounded-xl flex items-center justify-center bg-emerald-500/15';at.textContent='Connected · '+latency+'ms ('+ip+')';at.className='font-bold text-sm text-emerald-400';atm.textContent=s.timestamp;}else if(s.status==='checking'){if(ab)ab.className='w-10 h-10 rounded-xl flex items-center justify-center bg-amber-500/15';at.textContent='Checking...';at.className='font-bold text-sm text-amber-400';atm.textContent=s.timestamp;}else{if(ab)ab.className='w-10 h-10 rounded-xl flex items-center justify-center bg-red-500/15';at.textContent='Disconnected';at.className='font-bold text-sm text-red-400';atm.textContent=s.timestamp;}}}
function renderFloorCheckboxes(){const p=document.getElementById('floor-checkbox-panel');if(!p)return;const nh=state.floors.map(f=>`<label class="multi-select-option"><input type="checkbox" value="${f.name}" onchange="toggleFloorSelection('${f.name}',this.checked)" ${state.selectedFloors.includes(f.name)?'checked':''}><span>${f.name}</span></label>`).join('');if(p.innerHTML!==nh)p.innerHTML=nh;}
function toggleFloorDropdown(e){e.stopPropagation();document.getElementById('floor-checkbox-panel').classList.toggle('active');}
function toggleFloorSelection(fn,ic){if(ic){if(!state.selectedFloors.includes(fn))state.selectedFloors.push(fn);}else{state.selectedFloors=state.selectedFloors.filter(f=>f!==fn);}updateFloorFilterLabel();renderCurrentReport();}
function updateFloorFilterLabel(){const l=document.getElementById('floor-filter-label');if(state.selectedFloors.length===0)l.textContent='All Floors';else if(state.selectedFloors.length===1)l.textContent=state.selectedFloors[0];else l.textContent=state.selectedFloors.length+' Floors';}
document.addEventListener('click',(e)=>{const c=document.getElementById('floor-filter-container'),p=document.getElementById('floor-checkbox-panel');if(p&&p.classList.contains('active')&&c&&!c.contains(e.target))p.classList.remove('active');if(!e.target.closest('.icon-picker-container')){document.querySelectorAll('[id^="icon-picker-"]').forEach(picker=>picker.classList.add('hidden'));}});
function renderReasonFilter(){const sel=document.getElementById('filter-reason');if(!sel)return;const opts='<option value="">All Reasons</option>'+state.settings.returnReasons.map(r=>`<option value="${r.name}">${r.name}</option>`).join('');if(sel.innerHTML!==opts)sel.innerHTML=opts;}
function onPinInput(input){if(input.value.length===4){if(state.settings.enableEmployeeName){const en=document.getElementById('login-emp-name').value.trim();if(!en)return;}attemptLogin(true);}}
function handleFloorEnter(e){if(e.key==='Enter')attemptLogin();}

async function attemptLogin(auto=false){
  const floor=document.getElementById('login-floor').value.trim();
  const pin=document.getElementById('login-pin').value.trim();
  const errEl=document.getElementById('floor-login-error');
  if(!floor){errEl.textContent='Please enter floor name';return;}
  if(!pin){errEl.textContent='Please enter PIN';return;}
  if(state.settings.enableEmployeeName){const en=document.getElementById('login-emp-name').value.trim();if(!en){errEl.textContent='Please enter your name';return;}}
  try{
    const res=await fetch(SERVER_API+'?action=auth&type=loginFloor&floor='+encodeURIComponent(floor)+'&password='+encodeURIComponent(pin));
    if(!res.ok){const errText=await res.text();throw new Error('Server Error '+res.status+': '+errText.substring(0,50));}
    const data=await res.json();
    if(data.status==='success'){
      state.currentFloor=floor;_floorPin=pin;SafeStorage.setItem('cf_floor',floor);state.lastMessageCount=state.messages.length;
      document.getElementById('current-floor-display').textContent=floor;showScreen('screen-home');showToast('Welcome to '+floor,'success');
      if(state.settings.enableEmployeeName){const en=document.getElementById('login-emp-name').value.trim(),es=document.getElementById('login-emp-shift').value;if(en)fetch(SERVER_API+'?action=saveEmployee&floor='+encodeURIComponent(floor)+'&pin='+encodeURIComponent(pin)+'&name='+encodeURIComponent(en)+'&shift='+encodeURIComponent(es));}
    } else {errEl.textContent=data.message||'Login failed';document.getElementById('login-pin').value='';}
  } catch(e) {let errMsg='Connection Error: ';var em=e&&e.message?e.message:String(e);if(em.indexOf('Failed to fetch')!==-1){errMsg+='Server stopped or network blocked. Check Tomcat.';}else if(em.indexOf('sessionStorage')!==-1||em.indexOf('localStorage')!==-1||em.indexOf('Access is denied')!==-1){errMsg='Login OK but storage blocked - using in-memory session. Reload page to re-login.';}else if(em.indexOf('Unexpected token')!==-1||em.indexOf('JSON')!==-1){errMsg+='Invalid response from server. Check if JSP compiled correctly.';}else{errMsg+=em;}errEl.textContent=errMsg;}}
function logoutFloor(){if(state.callState)endCallFromFloor(true);state.currentFloor=null;_floorPin=null;SafeStorage.removeItem('cf_floor');PersistentSession.clear();showScreen('screen-login');document.getElementById('login-floor').value='';document.getElementById('login-pin').value='';document.getElementById('floor-login-error').textContent='';}
function openUpdateEmpInfo(){const e=state.currentEmployee||{};document.getElementById('update-emp-name').value=e.name||'';document.getElementById('update-emp-shift').value=e.shift||'Morning';openModal('update-emp-modal');}
async function saveUpdatedEmpInfo(){const n=document.getElementById('update-emp-name').value.trim(),s=document.getElementById('update-emp-shift').value;if(!n)return showToast('Name required','error');try{await fetch(SERVER_API+'?action=saveEmployee&floor='+encodeURIComponent(state.currentFloor)+(_floorPin?'&pin='+encodeURIComponent(_floorPin):'')+'&name='+encodeURIComponent(n)+'&shift='+encodeURIComponent(s));state.currentEmployee={name:n,shift:s,floor:state.currentFloor};showToast('Info updated','success');closeModal('update-emp-modal');}catch(e){showToast('Network error','error');}}
let adminLoginTimer=null;function onAdminPassInput(input){clearTimeout(adminLoginTimer);document.getElementById('admin-error').textContent='';adminLoginTimer=setTimeout(()=>{attemptAdminLogin(true);},300);}
function handleAdminEnter(e){if(e.key==='Enter')attemptAdminLogin();}
function openAdminLogin(){showScreen('screen-admin-login');document.getElementById('admin-pass').value='';document.getElementById('admin-error').textContent='';setTimeout(()=>document.getElementById('admin-pass').focus(),50);}
// Auth password storage — used as cross-IP session fallback (session cookie may not persist cross-IP)
let _adminPass=null;
let _dashPass=null;
let _floorPin=null;
let _passMgrPass=null;
async function attemptAdminLogin(auto=false){
  const pwd=document.getElementById('admin-pass').value;const errEl=document.getElementById('admin-error');
  if(!pwd){errEl.textContent='Please enter password';return;}
  try{
    const res=await fetch(SERVER_API+'?action=auth&type=admin&password='+encodeURIComponent(pwd));
    if(!res.ok){const errText=await res.text();throw new Error('Server Error '+res.status+': '+errText.substring(0,50));}
    const data=await res.json();
    if(data.status==='success'){state.isAdmin=true;_adminPass=pwd;SafeStorage.setItem('cf_admin','true');showScreen('screen-admin');renderSidebarNav();openReport('dashboard');}
    else{errEl.textContent='Wrong Password';if(!auto)document.getElementById('admin-pass').value='';}
  } catch(e) {let errMsg='Connection Error: ';var em=e&&e.message?e.message:String(e);if(em.indexOf('Failed to fetch')!==-1){errMsg+='Server stopped or network blocked. Check Tomcat.';}else if(em.indexOf('sessionStorage')!==-1||em.indexOf('localStorage')!==-1||em.indexOf('Access is denied')!==-1){errMsg='Login OK but storage blocked - using in-memory session.';}else if(em.indexOf('Unexpected token')!==-1||em.indexOf('JSON')!==-1){errMsg+='Invalid response from server. Check if JSP compiled correctly.';}else{errMsg+=em;}errEl.textContent=errMsg;}}
function logoutAdmin(){state.isAdmin=false;_adminPass=null;SafeStorage.removeItem('cf_admin');PersistentSession.clear();showScreen('screen-login');}

let dashLoginTimer=null;function onDashPassInput(input){clearTimeout(dashLoginTimer);document.getElementById('dash-error').textContent='';dashLoginTimer=setTimeout(()=>attemptDashboardLogin(true),300);}
function handleDashEnter(e){if(e.key==='Enter')attemptDashboardLogin();}
function openDashboardLogin(){showScreen('screen-dashboard-login');document.getElementById('dash-pass').value='';document.getElementById('dash-error').textContent='';setTimeout(()=>document.getElementById('dash-pass').focus(),50);}
async function attemptDashboardLogin(auto=false){
  const pwd=document.getElementById('dash-pass').value;const errEl=document.getElementById('dash-error');
  if(!pwd){errEl.textContent='Please enter password';return;}
  try{
    const res=await fetch(SERVER_API+'?action=auth&type=dashboard&password='+encodeURIComponent(pwd));
    const data=await res.json();
    if(data.status==='success'){state.isDashboardUser=true;_dashPass=pwd;SafeStorage.setItem('cf_dash','true');showScreen('screen-dashboard');renderDashSidebar();renderDashFloorCheckboxes();renderDashReasonFilter();updateDashFloorFilterLabel();const savedReport=SafeStorage.getItem('cf_dash_report');const allowed=state.settings.dashboardAccess||['dashboard'];const initialReport=(savedReport&&allowed.includes(savedReport))?savedReport:'dashboard';openDashReport(initialReport);}
    else{errEl.textContent='Wrong Password';if(!auto)document.getElementById('dash-pass').value='';}
  } catch(e) {var em=e&&e.message?e.message:String(e);var errMsg='Connection Error';if(em.indexOf('sessionStorage')!==-1||em.indexOf('localStorage')!==-1||em.indexOf('Access is denied')!==-1){errMsg='Login OK but storage blocked - using in-memory session.';}else if(em.indexOf('Failed to fetch')!==-1){errMsg='Server stopped or network blocked.';}else{errMsg+=': '+em;}errEl.textContent=errMsg;}}
function logoutDashboard(){state.isDashboardUser=false;_dashPass=null;SafeStorage.removeItem('cf_dash');SafeStorage.removeItem('cf_dash_report');state.currentDashReport='dashboard';PersistentSession.clear();showScreen('screen-login');}
function renderDashSidebar(){const allowed=state.settings.dashboardAccess||['dashboard'];const items=REPORTS_CONFIG.filter(r=>allowed.includes(r.id));document.getElementById('dash-sidebar-nav-items').innerHTML=items.map(r=>`<div class="nav-item ${state.currentDashReport===r.id?'active':''}" data-id="${r.id}" onclick="openDashReport('${r.id}')"><i class="fas ${state.settings.enableIcons?r.icon:''}"></i><span>${r.title}</span></div>`).join('');}
function openDashReport(id){state.currentDashReport=id;SafeStorage.setItem('cf_dash_report',id);document.getElementById('dash-report-title').textContent=REPORTS_CONFIG.find(r=>r.id===id).title;document.querySelectorAll('#dash-sidebar-nav-items .nav-item').forEach(i=>i.classList.toggle('active',i.dataset.id===id));toggleDashDateFilters(id);renderDashReport();updateDocumentTitle();}
// === Dashboard filters (mirror of admin filters, using dash- prefixed IDs) ===
function renderDashFloorCheckboxes(){const p=document.getElementById('dash-floor-checkbox-panel');if(!p)return;const nh=state.floors.map(f=>`<label class="multi-select-option"><input type="checkbox" value="${f.name}" onchange="toggleDashFloorSelection('${f.name}',this.checked)" ${state.selectedFloors.includes(f.name)?'checked':''}><span>${f.name}</span></label>`).join('');if(p.innerHTML!==nh)p.innerHTML=nh;}
function toggleDashFloorDropdown(e){e.stopPropagation();document.getElementById('dash-floor-checkbox-panel').classList.toggle('active');}
function toggleDashFloorSelection(fn,ic){if(ic){if(!state.selectedFloors.includes(fn))state.selectedFloors.push(fn);}else{state.selectedFloors=state.selectedFloors.filter(f=>f!==fn);}updateDashFloorFilterLabel();renderDashReport();}
function updateDashFloorFilterLabel(){const l=document.getElementById('dash-floor-filter-label');if(!l)return;if(state.selectedFloors.length===0)l.textContent='All Floors';else if(state.selectedFloors.length===1)l.textContent=state.selectedFloors[0];else l.textContent=state.selectedFloors.length+' Floors';}
function renderDashReasonFilter(){const sel=document.getElementById('dash-filter-reason');if(!sel)return;const opts='<option value="">All Reasons</option>'+state.settings.returnReasons.map(r=>`<option value="${r.name}">${r.name}</option>`).join('');if(sel.innerHTML!==opts)sel.innerHTML=opts;}
function toggleDashDateFilters(id){if(!id)id=state.currentDashReport;const m=document.getElementById('dash-filter-mode').value;document.getElementById('dash-filter-date').style.display=m==='custom'?'block':'none';document.getElementById('dash-filter-date-from').style.display=m==='range'?'block':'none';document.getElementById('dash-filter-date-to').style.display=m==='range'?'block':'none';document.getElementById('dash-filter-month').style.display=m==='month'?'block':'none';const st=id==='exit-detailed'||id==='floor-consolidated';document.getElementById('dash-filter-type').style.display=st?'block':'none';const sr=id==='exit-detailed'||id==='exit-summary'||id==='exit-return'||id==='exit-others-detailed'||id==='floor-consolidated';document.getElementById('dash-filter-reason').style.display=sr?'block':'none';document.getElementById('dash-filter-card').style.display=id==='notifications'||id==='live-messages'?'none':'flex';}
function getDashFilteredData(){const f=state.selectedFloors;const m=document.getElementById('dash-filter-mode')?document.getElementById('dash-filter-mode').value:'today';const r=document.getElementById('dash-filter-reason')?document.getElementById('dash-filter-reason').value:'';const t=document.getElementById('dash-filter-type')?document.getElementById('dash-filter-type').value:'';let d='',df='',dt='',mo='';if(m==='today')d=getTodayStr();else if(m==='yesterday')d=getYesterdayStr();else if(m==='custom'){const dv=document.getElementById('dash-filter-date').value;if(dv)d=formatDate(new Date(dv));}else if(m==='range'){const dfv=document.getElementById('dash-filter-date-from').value;const dtv=document.getElementById('dash-filter-date-to').value;if(dfv)df=formatDate(new Date(dfv));if(dtv)dt=formatDate(new Date(dtv));}else if(m==='month')mo=document.getElementById('dash-filter-month').value;let e=state.entries.filter(i=>{let p=(f.length===0||f.includes(i.floor))&&(!d||i.date===d)&&(!df||i.date>=df)&&(!dt||i.date<=dt);if(mo){const dd=new Date(i.timestamp);p=p&&(`${dd.getFullYear()}-${String(dd.getMonth()+1).padStart(2,'0')}`===mo);}return p;});let x=state.exits.filter(i=>{let p=(f.length===0||f.includes(i.floor))&&(!d||i.date===d)&&(!df||i.date>=df)&&(!dt||i.date<=dt)&&(!r||(i.reason&&i.reason.includes(r)))&&(!t||i.type===t);if(mo){const dd=new Date(i.timestamp);p=p&&(`${dd.getFullYear()}-${String(dd.getMonth()+1).padStart(2,'0')}`===mo);}return p;});return{entries:e,exits:x};}
function renderDashReport(){const c=document.getElementById('dash-report-content');const{entries,exits}=getDashFilteredData();switch(state.currentDashReport){case'dashboard':c.innerHTML=rDashboard(entries,exits);break;case'entry-breakdown':c.innerHTML=rEntryBreakdown(entries);break;case'floor-consolidated':c.innerHTML=rFloorConsolidated(entries,exits);break;case'floor-inout':c.innerHTML=rFloorInOut(entries,exits);break;case'entry-detailed':c.innerHTML=rEntryDetailed(entries);break;case'entry-summary-report':c.innerHTML=rEntrySummaryReport(entries);break;case'exit-detailed':c.innerHTML=rExitDetailed(exits);break;case'exit-summary':c.innerHTML=rExitSummary(exits);break;case'exit-return':c.innerHTML=rExitReturn(exits);break;case'exit-others-detailed':c.innerHTML=rExitOthersDetailed(exits);break;case'entry-source-summary':c.innerHTML=rEntrySourceSummary(entries,exits);break;case'notifications':c.innerHTML=rNotifications(entries,exits);break;case'live-messages':c.innerHTML=rLiveMessages();break;case'custom-log':c.innerHTML=rCustomLog(exits);break;default:c.innerHTML='<div class="text-center p-8 text-[var(--text-muted)]">Access Denied or Report Not Found</div>';}}
function exportCurrentDashReport(f){const{entries,exits}=getDashFilteredData();const c=REPORTS_CONFIG.find(r=>r.id===state.currentDashReport);if(!c)return;const m=getReportMatrix(c.id,entries,exits);const fl=getReportFilterLabel('dash-');if(f==='pdf'){buildPDF(c.title,m,exits,fl);showToast('PDF exported','success');}else if(f==='excel'){buildExcel(c.title,m,fl);showToast('Excel exported','success');}}

async function saveDevInfo(){state.settings.version=document.getElementById('dev-version').value.trim()||'1.0.0';state.settings.developer=document.getElementById('dev-name').value.trim()||'Admin';const colorVal=document.getElementById('footer-color').value;const opVal=parseFloat(document.getElementById('footer-opacity').value);const widthVal=document.getElementById('footer-width').value;const enVal=document.getElementById('footer-enabled-toggle').checked;if(!state.settings.footerSettings)state.settings.footerSettings={};state.settings.footerSettings.enabled=enVal;state.settings.footerSettings.color=colorVal;state.settings.footerSettings.opacity=opVal;state.settings.footerSettings.width=widthVal;try{await saveSettingsBackend();applyBrandUI();applyFooterVisibility();closeModal('dev-modal');showToast('Footer Settings Saved!','success');}catch(e){}}
// === v3.7 FOOTER SETTINGS (Alt+F10) ===
function openFooterSettings(){const fs=state.settings.footerSettings||{enabled:true,color:'#a1a1aa',opacity:1,width:'100%'};document.getElementById('dev-version').value=state.settings.version||'';document.getElementById('dev-name').value=state.settings.developer||'';document.getElementById('footer-enabled-toggle').checked=fs.enabled!==false;document.getElementById('footer-color').value=fs.color||'#a1a1aa';document.getElementById('footer-color-text').value=fs.color||'#a1a1aa';document.getElementById('footer-opacity').value=fs.opacity!==undefined?fs.opacity:1;document.getElementById('footer-opacity-val').textContent=fs.opacity!==undefined?fs.opacity:1;document.getElementById('footer-width').value=fs.width||'100%';openModal('dev-modal');}
function applyFooterSettings(){const en=document.getElementById('footer-enabled-toggle').checked;const color=document.getElementById('footer-color').value;const op=parseFloat(document.getElementById('footer-opacity').value);const width=document.getElementById('footer-width').value;if(!state.settings.footerSettings)state.settings.footerSettings={};state.settings.footerSettings.enabled=en;state.settings.footerSettings.color=color;state.settings.footerSettings.opacity=op;state.settings.footerSettings.width=width;applyFooterVisibility();saveSettingsBackend().catch(()=>{});}
function applyFooterVisibility(){const footer=document.getElementById('app-footer');if(!footer)return;const fs=state.settings.footerSettings||{enabled:true,color:'#a1a1aa',opacity:1,width:'100%'};if(fs.enabled===false){footer.style.display='none';return;}footer.style.display='flex';footer.style.opacity=fs.opacity!==undefined?fs.opacity:1;footer.style.color=fs.color||'#a1a1aa';const bar=footer.querySelector('.footer-bar');if(bar){if(fs.width==='auto'){bar.style.maxWidth='none';bar.style.width='auto';}else{bar.style.width='100%';bar.style.maxWidth=fs.width||'100%';}}}
async function saveSettingsBackend(){isSaving=true;try{const body='settings='+encodeURIComponent(JSON.stringify(state.settings))+(state.isAdmin&&_adminPass?'&authPassword='+encodeURIComponent(_adminPass):'')+(state.isDashboardUser&&_dashPass?'&authPassword='+encodeURIComponent(_dashPass):'');const res=await fetch(SERVER_API+'?action=saveSettings',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:body});const data=await res.json();if(data.error)throw new Error(data.error);}catch(e){showToast('Save failed: '+e.message,'error');throw e;}finally{isSaving=false;}}

function openPassManager(){document.getElementById('pass-auth-pass').value='';document.getElementById('pass-auth-error').textContent='';document.getElementById('pass-auth-section').classList.remove('hidden');document.getElementById('pass-mgmt-content').classList.add('hidden');openModal('pass-modal');setTimeout(()=>document.getElementById('pass-auth-pass').focus(),50);}
function handlePassAuthEnter(e){if(e.key==='Enter')checkPassAuth();}
async function checkPassAuth(){const p=document.getElementById('pass-auth-pass').value;try{const r=await fetch(SERVER_API+'?action=auth&type=passMgr&password='+encodeURIComponent(p));const d=await r.json();if(d.status==='success'){_passMgrPass=p;document.getElementById('pass-auth-section').classList.add('hidden');document.getElementById('pass-mgmt-content').classList.remove('hidden');const pr=await fetch(SERVER_API+'?action=getPasswords&password='+encodeURIComponent(p));const pd=await pr.json();if(pd.error){document.getElementById('pass-auth-error').textContent='Error: '+pd.error;return;}document.getElementById('new-admin-pass').value=pd.admin||'';document.getElementById('new-dashboard-pass').value=pd.dashboard||'Elive';document.getElementById('new-floor-mgmt-pass').value=pd.floorMgmt||'';document.getElementById('new-backup-pass').value=pd.backup||'';document.getElementById('new-clear-pass').value=pd.clear||'';document.getElementById('new-passmgr-pass').value=pd.passMgr||'';}else{document.getElementById('pass-auth-error').textContent='Wrong Code';document.getElementById('pass-auth-pass').value='';}}catch(e){document.getElementById('pass-auth-error').textContent='Network error';}}
async function savePasswords(){const a=document.getElementById('new-admin-pass').value.trim(),dp=document.getElementById('new-dashboard-pass').value.trim(),fm=document.getElementById('new-floor-mgmt-pass').value.trim(),bk=document.getElementById('new-backup-pass').value.trim(),cl=document.getElementById('new-clear-pass').value.trim(),pm=document.getElementById('new-passmgr-pass').value.trim();try{const r=await fetch(`${SERVER_API}?action=savePasswords&admin=${encodeURIComponent(a)}&dashboard=${encodeURIComponent(dp)}&floorMgmt=${encodeURIComponent(fm)}&backup=${encodeURIComponent(bk)}&clear=${encodeURIComponent(cl)}&passMgr=${encodeURIComponent(pm)}&ho=`+(_passMgrPass?'&password='+encodeURIComponent(_passMgrPass):''));const d=await r.json();if(d.status==='success'){showToast('Passwords Updated','success');closeModal('pass-modal');}else showToast('Failed: '+(d.error||''),'error');}catch(e){showToast('Network error','error');}}
// Floor management auth password — stored for cross-IP fallback (session cookie may not persist)
let _floorMgmtPass=null;
function openFloorMgmt(){document.getElementById('floor-auth-pass').value='';document.getElementById('floor-auth-error').textContent='';document.getElementById('floor-auth-section').classList.remove('hidden');document.getElementById('floor-mgmt-content').classList.add('hidden');openModal('floor-mgmt-modal');setTimeout(()=>document.getElementById('floor-auth-pass').focus(),50);}
function handleFloorAuthEnter(e){if(e.key==='Enter')checkFloorAuth();}
async function checkFloorAuth(){const p=document.getElementById('floor-auth-pass').value;try{const r=await fetch(SERVER_API+'?action=auth&type=floorMgmt&password='+encodeURIComponent(p));const d=await r.json();if(d.status==='success'){_floorMgmtPass=p;document.getElementById('floor-auth-section').classList.add('hidden');document.getElementById('floor-mgmt-content').classList.remove('hidden');// Use floors from auth response directly (cross-IP fix — no separate getFloorsWithPins call needed)
if(d.floors){state.floorsWithPins=d.floors;renderFloorMgmtList();}else{// Fallback: fetch separately with password param (for older backend versions)
const fr=await fetch(SERVER_API+'?action=getFloorsWithPins&password='+encodeURIComponent(p));const fd=await fr.json();if(fd.error){document.getElementById('floor-auth-error').textContent='Error: '+fd.error;document.getElementById('floor-auth-section').classList.remove('hidden');document.getElementById('floor-mgmt-content').classList.add('hidden');return;}state.floorsWithPins=fd.floors||[];renderFloorMgmtList();}}else{document.getElementById('floor-auth-error').textContent='Wrong Password';document.getElementById('floor-auth-pass').value='';}}catch(e){document.getElementById('floor-auth-error').textContent='Network error';}}
function renderFloorMgmtList(){const c=document.getElementById('floor-list-container');if(!state.floorsWithPins||state.floorsWithPins.length===0){c.innerHTML='<div class="text-center p-6 text-[var(--text-muted)] text-sm">No floors found. Add a new floor below.</div>';return;}c.innerHTML=state.floorsWithPins.map((f,i)=>`<div class="flex items-center gap-2 p-2 rounded-lg bg-[var(--bg)] border border-[var(--border)]"><input type="text" value="${(f.name||'').replace(/"/g,'&quot;')}" class="input-field flex-1" style="padding:0.5rem;" onchange="updateFloorName(${i},this.value)" placeholder="Floor Name"><input type="text" value="${f.pin||''}" class="input-field w-24 text-center password-mask" style="padding:0.5rem;" maxlength="4" onchange="updateFloorPin(${i},this.value)" placeholder="PIN"><button onclick="deleteFloor(${i})" class="text-red-400 hover:bg-red-500/10 p-2 rounded-lg" title="Delete Floor"><i class="fas fa-xmark"></i></button></div>`).join('');}
async function updateFloorName(i,n){state.floorsWithPins[i].name=n;await saveFloors();}
async function updateFloorPin(i,p){state.floorsWithPins[i].pin=p;await saveFloors();}
async function addFloor(){const n=document.getElementById('new-floor-name').value.trim(),p=document.getElementById('new-floor-pin').value.trim();if(!n||!p||p.length!==4)return showToast('Invalid','error');state.floorsWithPins.push({name:n,pin:p});await saveFloors();renderFloorMgmtList();document.getElementById('new-floor-name').value='';document.getElementById('new-floor-pin').value='';showToast('Floor added','success');}
async function deleteFloor(i){state.floorsWithPins.splice(i,1);await saveFloors();renderFloorMgmtList();showToast('Deleted','success');}
async function saveFloors(){try{// Include password as fallback for cross-IP (session cookie may not persist)
const url=SERVER_API+'?action=updateFloors&floors='+encodeURIComponent(JSON.stringify(state.floorsWithPins))+(_floorMgmtPass?'&password='+encodeURIComponent(_floorMgmtPass):'');const r=await fetch(url);const d=await r.json();if(d.error){showToast('Save failed: '+d.error,'error');}}catch(e){showToast('Failed','error');}}
function openBackupRestore(){document.getElementById('backup-auth-pass').value='';document.getElementById('backup-auth-error').textContent='';document.getElementById('backup-auth-section').classList.remove('hidden');document.getElementById('backup-content').classList.add('hidden');openModal('backup-modal');setTimeout(()=>document.getElementById('backup-auth-pass').focus(),50);}
function handleBackupAuthEnter(e){if(e.key==='Enter')checkBackupAuth();}
async function checkBackupAuth(){const p=document.getElementById('backup-auth-pass').value;try{const r=await fetch(SERVER_API+'?action=auth&type=backup&password='+encodeURIComponent(p));const d=await r.json();if(d.status==='success'){document.getElementById('backup-auth-section').classList.add('hidden');document.getElementById('backup-content').classList.remove('hidden');}else{document.getElementById('backup-auth-error').textContent='Wrong Password';document.getElementById('backup-auth-pass').value='';}}catch(e){document.getElementById('backup-auth-error').textContent='Network error';}}
function downloadBackup(t){let d={floors:state.floors,entries:[],exits:[],settings:state.settings,messages:state.messages};if(t==='full'){d.entries=state.entries;d.exits=state.exits;}else if(t==='daily'){const td=getTodayStr();d.entries=state.entries.filter(e=>e.date===td);d.exits=state.exits.filter(e=>e.date===td);}else if(t==='monthly'){const n=new Date();d.entries=state.entries.filter(e=>{const dd=new Date(e.timestamp);return dd.getMonth()===n.getMonth()&&dd.getFullYear()===n.getFullYear();});d.exits=state.exits.filter(e=>{const dd=new Date(e.timestamp);return dd.getMonth()===n.getMonth()&&dd.getFullYear()===n.getFullYear();});}const b=new Blob([JSON.stringify(d,null,2)],{type:'application/json'});const u=URL.createObjectURL(b);const a=document.createElement('a');a.href=u;a.download=`backup-${t}-${Date.now()}.json`;document.body.appendChild(a);a.click();document.body.removeChild(a);URL.revokeObjectURL(u);}
function importBackup(){const f=document.getElementById('import-file').files[0];if(!f)return showToast('Select file','error');const r=new FileReader();r.onload=async(e)=>{try{const d=JSON.parse(e.target.result);if(!d.entries||!d.exits||!d.floors)throw new Error('Invalid');showToast('Imported','success');closeModal('backup-modal');await fetchServerData();renderCurrentReport();}catch(err){showToast('Invalid file','error');}};r.readAsText(f);}
function openClearAuth(){document.getElementById('clear-auth-pass').value='';document.getElementById('clear-auth-error').textContent='';openModal('clear-auth-modal');setTimeout(()=>document.getElementById('clear-auth-pass').focus(),50);}
function handleClearAuthEnter(e){if(e.key==='Enter')checkClearAuth();}
async function checkClearAuth(){const p=document.getElementById('clear-auth-pass').value;try{const r=await fetch(SERVER_API+'?action=auth&type=clear&password='+encodeURIComponent(p));const d=await r.json();if(d.status==='success'){if(confirm('Delete ALL data? Safety backup taken.')){await fetch(SERVER_API+'?action=reset',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'password='+encodeURIComponent(p)});showToast('Cleared.','success');closeModal('clear-auth-modal');await fetchServerData();}}else{document.getElementById('clear-auth-error').textContent='Wrong Password';document.getElementById('clear-auth-pass').value='';}}catch(e){document.getElementById('clear-auth-error').textContent='Network error';}}

// === v3.1 IMPORT DATA (flowdata.json -> SQLite) ===
let pendingImportData = null;
function openImportData() {
  const fi = document.getElementById('import-file-input');
  if (fi) fi.value = '';
  const st = document.getElementById('import-status');
  if (st) st.textContent = '';
  pendingImportData = null;
  openModal('import-data-modal');
}
// Wire up file input change handler once DOM is ready
(function(){
  function wireImportInput(){
    const inp = document.getElementById('import-file-input');
    if (!inp || inp.dataset.wired === '1') return;
    inp.dataset.wired = '1';
    inp.addEventListener('change', function(e) {
      const file = e.target.files[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = function(ev) {
        try {
          pendingImportData = JSON.parse(ev.target.result);
          document.getElementById('import-status').innerHTML = '<span class="text-emerald-400"><i class="fas fa-check-circle"></i> File loaded: ' + (pendingImportData.entries?.length || 0) + ' entries, ' + (pendingImportData.exits?.length || 0) + ' exits</span>';
        } catch (err) {
          document.getElementById('import-status').innerHTML = '<span class="text-red-400"><i class="fas fa-xmark-circle"></i> Invalid JSON file</span>';
          pendingImportData = null;
        }
      };
      reader.readAsText(file);
    });
  }
  document.addEventListener('DOMContentLoaded', wireImportInput);
  setTimeout(wireImportInput, 500);
})();
async function performImport() {
  if (!pendingImportData) { showToast('Select a file first', 'error'); return; }
  if (!confirm('This will REPLACE all current data. Continue?')) return;
  // Take a safety backup first
  try { await fetch(SERVER_API + '?action=backup', {method:'POST'}); } catch (e) {}
  const entryCount = pendingImportData.entries?.length || 0;
  const exitCount = pendingImportData.exits?.length || 0;
  document.getElementById('import-status').innerHTML = '<span class="text-amber-400"><i class="fas fa-spinner fa-spin"></i> Converting ' + entryCount + ' entries, ' + exitCount + ' exits to SQLite... (may take a moment for large datasets)</span>';
  try {
    // v3.10: Send data as raw POST body (text/plain) — no multipart parsing, no size limits
    // authPassword goes in query string, data goes in body
    const authParam = (state.isAdmin && _adminPass) ? '&authPassword=' + encodeURIComponent(_adminPass) : '';
    const r = await fetch(SERVER_API + '?action=importData' + authParam, {
      method: 'POST',
      headers: { 'Content-Type': 'text/plain;charset=UTF-8' },
      body: JSON.stringify(pendingImportData)
    });
    const text = await r.text();
    let d;
    try { d = JSON.parse(text); } catch (parseErr) {
      document.getElementById('import-status').innerHTML = '<span class="text-red-400"><i class="fas fa-xmark-circle"></i> Server returned HTML error (not JSON). Check Tomcat logs. Response: ' + text.substring(0, 200) + '</span>';
      return;
    }
    if (d.status === 'success') {
      const s = d.summary || {};
      showToast('Converted: ' + (s.entries||0) + ' entries, ' + (s.exits||0) + ' exits to SQLite!', 'success');
      closeModal('import-data-modal');
      await fetchServerData();
    } else {
      document.getElementById('import-status').innerHTML = '<span class="text-red-400"><i class="fas fa-xmark-circle"></i> ' + (d.error || 'Import failed') + '</span>';
    }
  } catch (e) {
    document.getElementById('import-status').innerHTML = '<span class="text-red-400"><i class="fas fa-xmark-circle"></i> Network error: ' + e.message + '</span>';
  }
}

function openEntryModal(){openModal('entry-modal-backdrop');}
function openExitModal(){openModal('exit-modal-backdrop');}
function handleEntry(cat){playSound('entry_'+cat.toLowerCase());state.pendingEntryCategory=cat;closeModal('entry-modal-backdrop');if(state.settings.enableWayOfSource===false){completeEntry(cat,'');return;}const activeSources=(state.settings.wayOfSources||[]).filter(s=>s.enabled!==false);if(activeSources.length===0){completeEntry(cat,'');return;}setTimeout(()=>{openModal('entry-source-backdrop');document.getElementById('entry-source-heading').textContent='Source: '+cat+' - How did they find us?';renderEntrySources();},250);}
function renderEntrySources(){const list=document.getElementById('entry-source-list');const sources=(state.settings.wayOfSources||[]).filter(s=>s.enabled!==false);list.innerHTML=sources.map((s)=>{const i=state.settings.wayOfSources.indexOf(s);return `<button class="w-full p-4 rounded-xl bg-[var(--bg)] border border-[var(--border)] hover:border-sky-500/50 transition-all flex items-center gap-3 text-left" onclick="selectEntrySource(${i})"><div class="w-10 h-10 rounded-lg bg-sky-500/15 flex items-center justify-center"><i class="fas ${s.icon||'fa-ellipsis'} text-sky-400"></i></div><span class="font-semibold flex-1">${s.name}</span>${s.customEnabled?'<span class="tag-mini tag-cmt">CUSTOM</span>':''}<i class="fas fa-chevron-right text-[var(--text-muted)]"></i></button>`;}).join('');document.getElementById('entry-source-other-box').classList.add('hidden');}
function selectEntrySource(i){const src=state.settings.wayOfSources[i];state.pendingEntrySource=src;const isOther=src.customEnabled||src.name.toLowerCase().startsWith('other');if(isOther){document.getElementById('entry-source-other-box').classList.remove('hidden');document.getElementById('entry-source-other-label').innerText=src.name+' - Custom';document.getElementById('entry-source-custom').value='';setTimeout(()=>document.getElementById('entry-source-custom').focus(),100);}else{completeEntry(state.pendingEntryCategory,src.name);}}
function submitEntryWithCustomSource(){const custom=document.getElementById('entry-source-custom').value.trim();if(!custom)return showToast('Type a source','error');completeEntry(state.pendingEntryCategory,'Other: '+custom);}
async function completeEntry(category,wayOfSource){closeModal('entry-source-backdrop');const n=new Date();const emp=state.settings.enableEmployeeName?(state.currentEmployee||{}):{};const en={id:Date.now(),floor:state.currentFloor,category:category,wayOfSource:wayOfSource,timestamp:n.getTime(),date:formatDate(n),time:formatTime(n),hour:n.getHours(),branch:state.settings.network.branchName||"HO",employee:emp.name||'',shift:emp.shift||''};state.entries.push(en);updateUI();playSound('entry_complete');state.pendingEntryCategory=null;state.pendingEntrySource=null;try{await fetch(SERVER_API+'?action=entry&floor='+encodeURIComponent(state.currentFloor)+(_floorPin?'&pin='+encodeURIComponent(_floorPin):'')+'&data='+encodeURIComponent(JSON.stringify(en)));}catch(e){showToast('Save failed','error');state.entries=state.entries.filter(x=>x.id!==en.id);updateUI();}}

function showReturnReasons(){playSound('exit_return');closeModal('exit-modal-backdrop');setTimeout(()=>{openModal('exit-reasons-backdrop');renderReturnReasons();},250);}
function renderReturnReasons(){const list=document.getElementById('reasons-list');list.innerHTML=state.settings.returnReasons.map((r,i)=>{const isOther=r.name.toLowerCase().startsWith('other');const tags=[];if(r.commentEnabled)tags.push('<span class="tag-mini tag-cmt">CMT</span>');if(r.imageEnabled)tags.push('<span class="tag-mini tag-img">IMG</span>');if(r.mobileEnabled)tags.push('<span class="tag-mini tag-mob">MOB</span>');return `<button class="w-full p-4 rounded-xl bg-[var(--bg)] border border-[var(--border)] hover:border-red-500/50 transition-all flex items-center gap-3 text-left" onclick="selectReason(${i})"><div class="w-10 h-10 rounded-lg bg-red-500/15 flex items-center justify-center"><i class="fas ${r.icon||'fa-ellipsis'} text-red-400"></i></div><span class="font-semibold flex-1">${r.name}</span>${tags.join('')}<i class="fas fa-chevron-right text-[var(--text-muted)]"></i></button>`;}).join('');document.getElementById('other-reason-box').classList.add('hidden');document.getElementById('comment-box').classList.add('hidden');state.selectedReason=null;}
function selectReason(i){const r=state.settings.returnReasons[i];state.selectedReason=r;const isOther=r.name.toLowerCase().startsWith('other');document.getElementById('other-reason-input').value='';document.getElementById('other-reason-comment').value='';document.getElementById('reason-comment').value='';document.getElementById('other-reason-image').value='';document.getElementById('other-image-preview').classList.add('hidden');document.getElementById('reason-image').value='';document.getElementById('reason-image-preview').classList.add('hidden');document.getElementById('other-reason-mobile-input').value='';document.getElementById('reason-mobile-input').value='';const otherMobileReq=document.getElementById('other-mobile-req');if(otherMobileReq)otherMobileReq.classList.toggle('hidden',!r.mobileRequired);const commentMobileReq=document.getElementById('comment-mobile-req');if(commentMobileReq)commentMobileReq.classList.toggle('hidden',!r.mobileRequired);if(isOther){document.getElementById('other-reason-box').classList.remove('hidden');document.getElementById('other-heading').innerText=r.name;document.getElementById('other-image-upload').classList.toggle('hidden',!r.imageEnabled);document.getElementById('other-comment-upload').classList.toggle('hidden',!r.commentEnabled);document.getElementById('other-mobile-upload').classList.toggle('hidden',!r.mobileEnabled);document.getElementById('comment-box').classList.add('hidden');document.getElementById('other-reason-input').focus();}else{document.getElementById('other-reason-box').classList.add('hidden');if(r.commentEnabled||r.imageEnabled||r.mobileEnabled){document.getElementById('comment-box').classList.remove('hidden');document.getElementById('comment-box-heading').innerText=r.name;document.getElementById('comment-image-upload').classList.toggle('hidden',!r.imageEnabled);document.getElementById('comment-mobile-upload').classList.toggle('hidden',!r.mobileEnabled);if(r.commentEnabled)document.getElementById('reason-comment').focus();}else{document.getElementById('comment-box').classList.add('hidden');if(state.settings.enableReturnWayOfEntry){openReturnWayModal(r.name,'','','');}else{handleExit('Return',r.name,'','','');}}}}
function submitReasonWithComment(){const comment=document.getElementById('reason-comment').value.trim();const mobile=document.getElementById('reason-mobile-input').value.trim();if(state.selectedReason.mobileRequired&&!mobile)return showToast('Mobile number is required','error');const fi=document.getElementById('reason-image');const hasImg=state.selectedReason.imageEnabled&&fi.files&&fi.files[0];if(hasImg){const file=fi.files[0];const reader=new FileReader();reader.onload=(e)=>{const img=new Image();img.onload=()=>{const c=document.createElement('canvas'),ctx=c.getContext('2d');let w=img.width,h=img.height;if(w>600){h*=600/w;w=600;}c.width=w;c.height=h;ctx.drawImage(img,0,0,w,h);if(state.settings.enableReturnWayOfEntry){openReturnWayModal(state.selectedReason.name,comment,c.toDataURL('image/jpeg',0.7),mobile);}else{handleExit('Return',state.selectedReason.name,comment,c.toDataURL('image/jpeg',0.7),mobile);}};img.src=e.target.result;};reader.readAsDataURL(file);}else{if(state.settings.enableReturnWayOfEntry){openReturnWayModal(state.selectedReason.name,comment,null,mobile);}else{handleExit('Return',state.selectedReason.name,comment,null,mobile);}}document.getElementById('reason-comment').value='';document.getElementById('reason-mobile-input').value='';document.getElementById('reason-image').value='';document.getElementById('reason-image-preview').classList.add('hidden');document.getElementById('comment-box').classList.add('hidden');}
function handleOtherExit(){const cr=document.getElementById('other-reason-input').value.trim();if(!cr)return showToast('Type a reason','error');let comment='';if(!document.getElementById('other-comment-upload').classList.contains('hidden')){comment=document.getElementById('other-reason-comment').value.trim();}const mobile=document.getElementById('other-reason-mobile-input').value.trim();if(state.selectedReason.mobileRequired&&!mobile)return showToast('Mobile number is required','error');const fi=document.getElementById('other-reason-image');const hasImg=!document.getElementById('other-image-upload').classList.contains('hidden')&&fi.files&&fi.files[0];if(hasImg){const file=fi.files[0];const reader=new FileReader();reader.onload=(e)=>{const img=new Image();img.onload=()=>{const c=document.createElement('canvas'),ctx=c.getContext('2d');let w=img.width,h=img.height;if(w>600){h*=600/w;w=600;}c.width=w;c.height=h;ctx.drawImage(img,0,0,w,h);if(state.settings.enableReturnWayOfEntry){openReturnWayModal(`Other: ${cr}${comment?' | Comment: '+comment:''}`,comment,c.toDataURL('image/jpeg',0.7),mobile);}else{handleExit('Return',`Other: ${cr}${comment?' | Comment: '+comment:''}`,comment,c.toDataURL('image/jpeg',0.7),mobile);}};img.src=e.target.result;};reader.readAsDataURL(file);}else{if(state.settings.enableReturnWayOfEntry){openReturnWayModal(`Other: ${cr}${comment?' | Comment: '+comment:''}`,comment,null,mobile);}else{handleExit('Return',`Other: ${cr}${comment?' | Comment: '+comment:''}`,comment,null,mobile);}}document.getElementById('other-reason-input').value='';document.getElementById('other-reason-comment').value='';document.getElementById('other-reason-mobile-input').value='';document.getElementById('other-reason-image').value='';document.getElementById('other-image-preview').classList.add('hidden');document.getElementById('other-reason-box').classList.add('hidden');}
document.addEventListener('change',(e)=>{if(e.target.id==='other-reason-image'&&e.target.files&&e.target.files[0]){const r=new FileReader();r.onload=(ev)=>{document.getElementById('other-image-preview-img').src=ev.target.result;document.getElementById('other-image-preview').classList.remove('hidden');};r.readAsDataURL(e.target.files[0]);}if(e.target.id==='reason-image'&&e.target.files&&e.target.files[0]){const r=new FileReader();r.onload=(ev)=>{document.getElementById('reason-image-preview-img').src=ev.target.result;document.getElementById('reason-image-preview').classList.remove('hidden');};r.readAsDataURL(e.target.files[0]);}});
// === v3.1 PURCHASE SOURCE FLOW ===
let pendingPurchaseSource = null;

function selectExitType(type) {
  if (type === 'Purchase' && state.settings.enablePurchaseSource) {
    closeModal('exit-modal-backdrop');
    setTimeout(()=>openPurchaseSourceModal(), 200);
  } else if (type === 'Purchase') {
    closeModal('exit-modal-backdrop');
    handleExit('Purchase', null, '', '', '');
  } else {
    showReturnReasons();
  }
}

function openPurchaseSourceModal() {
  // Build the purchase source buttons list from settings
  const list = document.getElementById('purchase-source-list');
  if (!list) return;
  list.innerHTML = '';
  const sources = (state.settings.purchaseSources || []).filter(s => s.enabled !== false);
  if (sources.length === 0) {
    // No sources configured — submit directly
    handleExit('Purchase', null, '', '', '');
    return;
  }
  sources.forEach(src => {
    const btn = document.createElement('div');
    btn.className = 'purchase-source-item';
    btn.style.cssText = 'cursor:pointer;padding:1rem;border-radius:12px;background:var(--surface);border:1px solid var(--border);display:flex;flex-direction:column;align-items:center;gap:0.5rem;transition:all 0.2s;';
    btn.onmouseenter = () => { btn.style.borderColor='var(--accent)'; btn.style.background='var(--surface-hover)'; };
    btn.onmouseleave = () => { if(btn.dataset.selected!=='true'){btn.style.borderColor='var(--border)'; btn.style.background='var(--surface)';} };
    const icon = document.createElement('i');
    icon.className = 'fas ' + (src.icon || 'fa-tag') + ' text-2xl';
    icon.style.color = 'var(--accent-glow)';
    const label = document.createElement('div');
    label.textContent = src.name;
    label.style.cssText = 'font-weight:700;font-size:0.875rem;text-align:center;';
    btn.appendChild(icon);
    btn.appendChild(label);
    btn.onclick = (ev) => selectPurchaseSource(ev, src.name, src.customEnabled);
    list.appendChild(btn);
  });
  pendingPurchaseSource = null;
  document.getElementById('purchase-source-custom-field').classList.add('hidden');
  document.getElementById('purchase-source-custom-input').value = '';
  openModal('exit-purchase-source-backdrop');
}

function selectPurchaseSource(ev, name, isCustom) {
  if (isCustom) {
    // Others — show custom text field, user types then clicks Submit
    document.querySelectorAll('.purchase-source-item').forEach(el => { el.dataset.selected='false'; el.style.borderColor='var(--border)'; el.style.background='var(--surface)'; });
    const target = ev.currentTarget;
    target.dataset.selected='true';
    target.style.borderColor='var(--accent)';
    target.style.background='rgba(245,158,11,0.1)';
    pendingPurchaseSource = name;
    document.getElementById('purchase-source-custom-field').classList.remove('hidden');
    document.getElementById('purchase-source-custom-input').focus();
  } else {
    // Non-Others — immediately close + record (no Confirm button needed)
    pendingPurchaseSource = name;
    closeModal('exit-purchase-source-backdrop');
    handleExitWithSource('Purchase', null, '', '', '', name);
  }
}

function submitPurchaseWithSource() {
  if (!pendingPurchaseSource) {
    showToast('Select a purchase source', 'error');
    return;
  }
  let finalSource = pendingPurchaseSource;
  const customField = document.getElementById('purchase-source-custom-field');
  if (!customField.classList.contains('hidden')) {
    const custom = document.getElementById('purchase-source-custom-input').value.trim();
    if (custom) finalSource = pendingPurchaseSource + ': ' + custom;
  }
  closeModal('exit-purchase-source-backdrop');
  // Submit the exit with purchase source
  handleExitWithSource('Purchase', null, '', '', '', finalSource);
}

async function handleExitWithSource(type, reason, comment, image, mobile, purchaseSource) {
  closeModal('exit-modal-backdrop');
  closeModal('exit-purchase-source-backdrop');
  playSound('exit_purchase');
  const n = new Date();
  const emp = state.settings.enableEmployeeName ? (state.currentEmployee || {}) : {};
  const ex = {
    id: Date.now(),
    floor: state.currentFloor,
    type: type,
    reason: reason || null,
    comment: comment || '',
    mobile: mobile || '',
    image: image || '',
    purchaseSource: purchaseSource || '',
    timestamp: n.getTime(),
    date: formatDate(n),
    time: formatTime(n),
    branch: state.settings.network.branchName || 'HO',
    employee: emp.name || '',
    shift: emp.shift || ''
  };
  state.exits.push(ex);
  updateUI();
  try {
    await fetch(SERVER_API + '?action=exit&floor=' + encodeURIComponent(state.currentFloor) + (_floorPin ? '&pin=' + encodeURIComponent(_floorPin) : '') + '&data=' + encodeURIComponent(JSON.stringify(ex)));
  } catch (e) {
    showToast('Save failed', 'error');
    state.exits = state.exits.filter(x => x.id !== ex.id);
    updateUI();
  }
}

let pendingReturnWay=null;let pendingReturnReason=null;let pendingReturnComment=null;let pendingReturnImage=null;let pendingReturnMobile=null;
function openReturnWayModal(reason,comment,image,mobile){pendingReturnReason=reason;pendingReturnComment=comment;pendingReturnImage=image;pendingReturnMobile=mobile;const list=document.getElementById('return-way-list');if(!list){handleExit('Return',reason,comment,image,mobile);return;}list.innerHTML='';const ways=(state.settings.returnWayOfEntries||[]).filter(w=>w.enabled!==false);if(ways.length===0){handleExit('Return',reason,comment,image,mobile);return;}ways.forEach(w=>{const btn=document.createElement('div');btn.className='return-way-item';btn.style.cssText='cursor:pointer;padding:1rem;border-radius:12px;background:var(--surface);border:1px solid var(--border);display:flex;flex-direction:column;align-items:center;gap:0.5rem;transition:all 0.2s;';btn.onmouseenter=()=>{btn.style.borderColor='var(--accent)';btn.style.background='var(--surface-hover)';};btn.onmouseleave=()=>{btn.style.borderColor='var(--border)';btn.style.background='var(--surface)';};btn.innerHTML='<i class="fas '+(w.icon||'fa-tag')+' text-2xl" style="color:var(--accent-glow);"></i><div style="font-weight:700;font-size:0.875rem;text-align:center;">'+escapeHtml(w.name)+'</div>';btn.onclick=()=>selectReturnWay(w.name,w.customEnabled);list.appendChild(btn);});pendingReturnWay=null;document.getElementById('return-way-custom-field').classList.add('hidden');document.getElementById('return-way-custom-input').value='';openModal('exit-return-way-backdrop');}
function selectReturnWay(name,isCustom){
  if(isCustom){
    // Others — show custom text field, user types then clicks Submit
    document.querySelectorAll('.return-way-item').forEach(el=>{el.style.borderColor='var(--border)';el.style.background='var(--surface)';});
    event.currentTarget.style.borderColor='var(--accent)';
    event.currentTarget.style.background='rgba(245,158,11,0.1)';
    pendingReturnWay=name;
    document.getElementById('return-way-custom-field').classList.remove('hidden');
    document.getElementById('return-way-custom-input').focus();
  } else {
    // Non-Others — immediately close + record (no Confirm button needed)
    pendingReturnWay=name;
    closeModal('exit-return-way-backdrop');
    handleExitWithReturnWay('Return',pendingReturnReason,pendingReturnComment,pendingReturnImage,pendingReturnMobile,name);
  }
}
function submitReturnWithWay(){if(!pendingReturnWay){showToast('Select a way of entry','error');return;}let finalWay=pendingReturnWay;const customField=document.getElementById('return-way-custom-field');if(!customField.classList.contains('hidden')){const custom=document.getElementById('return-way-custom-input').value.trim();if(custom)finalWay=pendingReturnWay+': '+custom;}closeModal('exit-return-way-backdrop');handleExitWithReturnWay('Return',pendingReturnReason,pendingReturnComment,pendingReturnImage,pendingReturnMobile,finalWay);}
async function handleExitWithReturnWay(type,reason,comment,image,mobile,returnWayOfEntry){closeModal('exit-modal-backdrop');closeModal('exit-reasons-backdrop');playSound('exit_reason_submit');const n=new Date();const emp=state.settings.enableEmployeeName?(state.currentEmployee||{}):{};const ex={id:Date.now(),floor:state.currentFloor,type,reason:reason||null,comment:comment||'',mobile:mobile||'',image:image||'',purchaseSource:'',returnWayOfEntry:returnWayOfEntry||'',timestamp:n.getTime(),date:formatDate(n),time:formatTime(n),branch:state.settings.network.branchName||'HO',employee:emp.name||'',shift:emp.shift||''};state.exits.push(ex);updateUI();try{await fetch(SERVER_API+'?action=exit&floor='+encodeURIComponent(state.currentFloor)+(_floorPin?'&pin='+encodeURIComponent(_floorPin):'')+'&data='+encodeURIComponent(JSON.stringify(ex)));}catch(e){showToast('Save failed','error');state.exits=state.exits.filter(x=>x.id!==ex.id);updateUI();}}
async function handleExit(type,reason,comment,image,mobile){if(type==='Purchase')playSound('exit_purchase');else playSound('exit_reason_submit');closeModal('exit-modal-backdrop');closeModal('exit-reasons-backdrop');const n=new Date();const emp=state.settings.enableEmployeeName?(state.currentEmployee||{}):{};const ex={id:Date.now(),floor:state.currentFloor,type,reason:reason||null,comment:comment||'',mobile:mobile||'',image:image||'',purchaseSource:'',returnWayOfEntry:'',timestamp:n.getTime(),date:formatDate(n),time:formatTime(n),branch:state.settings.network.branchName||"HO",employee:emp.name||'',shift:emp.shift||''};state.exits.push(ex);updateUI();try{await fetch(SERVER_API+'?action=exit&floor='+encodeURIComponent(state.currentFloor)+(_floorPin?'&pin='+encodeURIComponent(_floorPin):'')+'&data='+encodeURIComponent(JSON.stringify(ex)));}catch(e){showToast('Save failed','error');state.exits=state.exits.filter(x=>x.id!==ex.id);updateUI();}}

function openCallFloorModal(){const l=document.getElementById('call-floor-list');l.innerHTML=state.floors.map(f=>`<button onclick="startCallToFloor('${f.name.replace(/'/g,"\\'")}')" class="w-full p-3 rounded-xl bg-[var(--bg)] border border-[var(--border)] hover:border-emerald-500/50 transition-all flex items-center gap-3 text-left"><div class="w-10 h-10 rounded-lg bg-emerald-500/15 flex items-center justify-center"><i class="fas fa-phone text-emerald-400"></i></div><span class="font-bold flex-1">${f.name}</span><i class="fas fa-chevron-right text-[var(--text-muted)]"></i></button>`).join('');openModal('call-floor-modal');}
function waitForIceGathering(pc){return new Promise((resolve)=>{if(pc.iceGatheringState==='complete'){resolve();}else{const checkState=()=>{if(pc.iceGatheringState==='complete'){pc.removeEventListener('icegatheringstatechange',checkState);resolve();}};pc.addEventListener('icegatheringstatechange',checkState);setTimeout(resolve,3000);}});}
function getIceServers(){return{iceServers:[{urls:'stun:stun.l.google.com:19302'},{urls:'stun:stun1.l.google.com:19302'},{urls:'stun:stun2.l.google.com:19302'},{urls:'stun:stun3.l.google.com:19302'},{urls:'stun:stun4.l.google.com:19302'}],iceTransportPolicy:'all'};}
async function startCallToFloor(floor){closeModal('call-floor-modal');showToast('Calling '+floor+'...','info');await fetch(SERVER_API+'?action=adminCallFloor&floor='+encodeURIComponent(floor)+(state.isAdmin&&_adminPass?'&authPassword='+encodeURIComponent(_adminPass):''));try{state.localStream=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true,autoGainControl:true}});state.peerConnection=new RTCPeerConnection(getIceServers());state.localStream.getTracks().forEach(t=>state.peerConnection.addTrack(t,state.localStream));state.peerConnection.ontrack=(e)=>{const a=document.createElement('audio');a.autoplay=true;a.srcObject=e.streams[0];document.body.appendChild(a);};const offer=await state.peerConnection.createOffer();await state.peerConnection.setLocalDescription(offer);await waitForIceGathering(state.peerConnection);await fetch(SERVER_API+'?action=saveCallSignal&type=offer&data='+encodeURIComponent(JSON.stringify(state.peerConnection.localDescription)));state.callState={floor,status:'ringing'};state.callStartTime=Date.now();document.getElementById('active-call-floor').textContent=floor;openModal('active-call-modal');startCallTimer();pollForAnswer();}catch(e){showToast('Mic unavailable. Call will still connect without your audio.','error');state.callState={floor,status:'ringing'};state.callStartTime=Date.now();document.getElementById('active-call-floor').textContent=floor;openModal('active-call-modal');startCallTimer();pollForAnswer();}}
async function pollForAnswer(){if(!state.callState||state.callState.status!=='ringing')return;try{const r=await fetch(SERVER_API+'?action=getCallState');const d=await r.json();if(d.status==='none'){endCallFromAdmin();return;}if(d.status==='connected'&&d.answer&&state.peerConnection&&state.peerConnection.currentRemoteDescription===null){try{const a=d.answer;await state.peerConnection.setRemoteDescription(a);state.callState.status='connected';}catch(err){console.error('Set remote description failed:',err);}}}catch(e){}if(state.callState&&state.callState.status==='ringing')setTimeout(pollForAnswer,2000);}
function startCallTimer(){if(state.callTimer)clearInterval(state.callTimer);state.callTimer=setInterval(()=>{if(!state.callStartTime)return;const e=Math.floor((Date.now()-state.callStartTime)/1000);const m=String(Math.floor(e/60)).padStart(2,'0'),s=String(e%60).padStart(2,'0');const t=document.getElementById('active-call-timer');if(t)t.textContent=`${m}:${s}`;},1000);}
async function endCallFromAdmin(){await fetch(SERVER_API+'?action=endCall');if(state.peerConnection){state.peerConnection.close();state.peerConnection=null;}if(state.localStream){state.localStream.getTracks().forEach(t=>t.stop());state.localStream=null;}if(state.callTimer){clearInterval(state.callTimer);state.callTimer=null;}state.callState=null;state.callStartTime=null;closeModal('active-call-modal');showToast('Call ended','info');}
async function checkIncomingCall(){if(state.callState){try{const r=await fetch(SERVER_API+'?action=getCallState');const d=await r.json();if(d.status==='none'){endCallFromFloor(true);return;}}catch(e){}return;}try{const r=await fetch(SERVER_API+'?action=getCallState');const d=await r.json();if(d.status==='none')return;if(d.floor===state.currentFloor&&(d.status==='ringing'||d.status==='connected')){state.callState=d;acceptCallAsFloor();}}catch(e){}}
async function acceptCallAsFloor(){playSound('call_ring');document.getElementById('call-overlay').classList.add('active');document.getElementById('call-status-text').textContent='Admin Calling...';try{state.localStream=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true,autoGainControl:true}});state.peerConnection=new RTCPeerConnection(getIceServers());state.localStream.getTracks().forEach(t=>state.peerConnection.addTrack(t,state.localStream));state.peerConnection.ontrack=(e)=>{const a=document.createElement('audio');a.autoplay=true;a.srcObject=e.streams[0];document.body.appendChild(a);};const r=await fetch(SERVER_API+'?action=getCallState');const d=await r.json();if(d.offer){const o=d.offer;await state.peerConnection.setRemoteDescription(o);const a=await state.peerConnection.createAnswer();await state.peerConnection.setLocalDescription(a);await waitForIceGathering(state.peerConnection);await fetch(SERVER_API+'?action=saveCallSignal&type=answer&data='+encodeURIComponent(JSON.stringify(state.peerConnection.localDescription)));}state.callStartTime=Date.now();document.getElementById('call-status-text').textContent='Connected with Admin';startFloorCallTimer();}catch(e){console.error('Call error:',e);state.callStartTime=Date.now();document.getElementById('call-status-text').textContent='Connected (No Voice)';startFloorCallTimer();}}
function startFloorCallTimer(){if(state.callTimer)clearInterval(state.callTimer);state.callTimer=setInterval(()=>{if(!state.callStartTime)return;const e=Math.floor((Date.now()-state.callStartTime)/1000);const m=String(Math.floor(e/60)).padStart(2,'0'),s=String(e%60).padStart(2,'0');const t=document.getElementById('call-timer');if(t)t.textContent=`${m}:${s}`;},1000);}
async function endCallFromFloor(silent){if(!silent)await fetch(SERVER_API+'?action=endCall');if(state.peerConnection){state.peerConnection.close();state.peerConnection=null;}if(state.localStream){state.localStream.getTracks().forEach(t=>t.stop());state.localStream=null;}if(state.callTimer){clearInterval(state.callTimer);state.callTimer=null;}state.callState=null;state.callStartTime=null;document.getElementById('call-overlay').classList.remove('active');if(!silent)showToast('Call ended','info');}

function showScreen(id){['screen-login','screen-home','screen-admin-login','screen-admin','screen-dashboard-login','screen-dashboard'].forEach(s=>document.getElementById(s).classList.add('hidden'));document.getElementById(id).classList.remove('hidden');updateLoginFields();updateDocumentTitle();if(id==='screen-home')setupCallPolling();else if(callCheckInterval){clearInterval(callCheckInterval);callCheckInterval=null;}/* v3.7: footer (developer + version) shows on ALL screens — toggle via Alt+F10 */applyFooterVisibility();/* v3.3: refresh admin date/time + db status when admin screen shows */if(id==='screen-admin'){updateAdminDateTime();updateAdminDbStatus();}}
// === v3.1 HOME DASHBOARD VIEW SWITCHING + CHART + CHAT + CALL ===
function switchHomeView(view) {
  document.querySelectorAll('.home-nav-item').forEach(el => el.classList.remove('active'));
  const navEl = document.querySelector('.home-nav-item[data-view="' + view + '"]');
  if (navEl) navEl.classList.add('active');
  document.querySelectorAll('.home-view').forEach(el => el.classList.remove('active'));
  const viewEl = document.getElementById('home-view-' + view);
  if (viewEl) viewEl.classList.add('active');
  if (view === 'dashboard') {
    renderHourlyChart();
    renderHomeChatPanel();
    renderHomeCallPanel();
  } else if (view === 'messages') {
    renderHomeMessagesFull();
  } else if (view === 'settings') {
    const fn = document.getElementById('settings-floor-name');
    if (fn) fn.textContent = state.currentFloor || '-';
  }
}

function renderHourlyChart() {
  const container = document.getElementById('hourly-chart-bars');
  const labelsContainer = document.getElementById('hourly-chart-labels');
  if (!container || !labelsContainer) return;
  const now = new Date();
  const currentHour = now.getHours();
  const todayStr = getTodayStr();
  const hourCounts = [];
  for (let i = 11; i >= 0; i--) {
    const h = (currentHour - i + 24) % 24;
    const count = state.entries.filter(e => e.floor === state.currentFloor && e.date === todayStr && e.hour === h).length;
    hourCounts.push({ hour: h, count: count });
  }
  const maxCount = Math.max(1, ...hourCounts.map(h => h.count));
  container.innerHTML = '';
  labelsContainer.innerHTML = '';
  hourCounts.forEach(({ hour, count }) => {
    const bar = document.createElement('div');
    bar.className = 'home-chart-bar';
    const heightPct = (count / maxCount) * 100;
    bar.style.height = Math.max(4, heightPct) + '%';
    bar.setAttribute('data-tooltip', hour + ':00 — ' + count + ' entries');
    container.appendChild(bar);
    const label = document.createElement('div');
    label.className = 'home-chart-label';
    label.textContent = hour;
    labelsContainer.appendChild(label);
  });
}

function renderHomeChatPanel() {
  const container = document.getElementById('home-chat-messages');
  if (!container) return;
  const msgs = (state.messages || []).filter(m => {
    if (!m.target || m.target === 'All' || m.target === state.currentFloor) return true;
    return false;
  }).slice(-5);
  if (msgs.length === 0) {
    container.innerHTML = '<div class="home-empty-state">No messages</div>';
    return;
  }
  container.innerHTML = '';
  msgs.forEach(m => {
    const div = document.createElement('div');
    div.className = 'home-chat-msg msg-admin';
    const time = m.timestamp ? new Date(m.timestamp).toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'}) : '';
    div.innerHTML = '<div class="msg-sender">Admin</div><div class="msg-text">' + escapeHtml(m.text || '') + '</div><div class="msg-time">' + time + '</div>';
    container.appendChild(div);
    if (m.replies) {
      m.replies.filter(r => r.floor === state.currentFloor).forEach(r => {
        const rdiv = document.createElement('div');
        rdiv.className = 'home-chat-msg msg-floor';
        rdiv.innerHTML = '<div class="msg-sender">' + escapeHtml(r.floor) + '</div><div class="msg-text">' + escapeHtml(r.text) + '</div>';
        container.appendChild(rdiv);
      });
    }
  });
  container.scrollTop = container.scrollHeight;
}

function renderHomeMessagesFull() {
  const container = document.getElementById('home-messages-full');
  if (!container) return;
  const msgs = (state.messages || []).filter(m => {
    if (!m.target || m.target === 'All' || m.target === state.currentFloor) return true;
    return false;
  });
  if (msgs.length === 0) {
    container.innerHTML = '<div class="home-empty-state">No messages yet. Admin can send messages from the admin panel.</div>';
    return;
  }
  container.innerHTML = '';
  msgs.forEach(m => {
    const div = document.createElement('div');
    div.className = 'home-chat-msg msg-admin';
    const time = m.timestamp ? new Date(m.timestamp).toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'}) : '';
    div.innerHTML = '<div class="msg-sender">Admin</div><div class="msg-text">' + escapeHtml(m.text || '') + '</div><div class="msg-time">' + time + '</div>';
    container.appendChild(div);
    if (m.replies) {
      m.replies.forEach(r => {
        const rdiv = document.createElement('div');
        rdiv.className = 'home-chat-msg msg-floor';
        rdiv.innerHTML = '<div class="msg-sender">' + escapeHtml(r.floor) + '</div><div class="msg-text">' + escapeHtml(r.text) + '</div>';
        container.appendChild(rdiv);
      });
    }
  });
  container.scrollTop = container.scrollHeight;
}

function renderHomeCallPanel() {
  const container = document.getElementById('home-call-content');
  if (!container) return;
  if (!state.callState || !state.callState.floor || state.callState.floor !== state.currentFloor) {
    container.innerHTML = '<div class="home-empty-state">No active call</div>';
    return;
  }
  const cs = state.callState;
  const status = cs.status || 'ringing';
  let duration = '';
  if (state.callStartTime) {
    const secs = Math.floor((Date.now() - state.callStartTime) / 1000);
    const mm = String(Math.floor(secs / 60)).padStart(2, '0');
    const ss = String(secs % 60).padStart(2, '0');
    duration = ' · ' + mm + ':' + ss;
  }
  container.innerHTML = '<div class="home-call-active">' +
    '<div class="home-call-pulse"></div>' +
    '<div class="home-call-caller">Admin</div>' +
    '<div class="home-call-status">' + (status === 'connected' ? 'Connected' : 'Ringing') + duration + '</div>' +
    '<button class="home-call-end-btn" onclick="endCallFromFloor()"><i class="fas fa-phone-slash"></i></button>' +
    '</div>';
}

function getTodayStr(){return formatDate(new Date());}
function getYesterdayStr(){const d=new Date();d.setDate(d.getDate()-1);return formatDate(d);}
function saveFilterState(id){reportFilterStates[id]={selectedFloors:[...state.selectedFloors],mode:document.getElementById('filter-mode').value,date:document.getElementById('filter-date').value,dateFrom:document.getElementById('filter-date-from').value,dateTo:document.getElementById('filter-date-to').value,month:document.getElementById('filter-month').value,type:document.getElementById('filter-type').value,reason:document.getElementById('filter-reason').value};}
function loadFilterState(id){const fs=reportFilterStates[id]||{};state.selectedFloors=fs.selectedFloors||[];renderFloorCheckboxes();updateFloorFilterLabel();document.getElementById('filter-mode').value=fs.mode||'today';document.getElementById('filter-date').value=fs.date||'';document.getElementById('filter-date-from').value=fs.dateFrom||'';document.getElementById('filter-date-to').value=fs.dateTo||'';document.getElementById('filter-month').value=fs.month||'';document.getElementById('filter-type').value=fs.type||'';document.getElementById('filter-reason').value=fs.reason||'';toggleDateFilters(id);}
function toggleDateFilters(id){const m=document.getElementById('filter-mode').value;document.getElementById('filter-date').style.display=m==='custom'?'block':'none';document.getElementById('filter-date-from').style.display=m==='range'?'block':'none';document.getElementById('filter-date-to').style.display=m==='range'?'block':'none';document.getElementById('filter-month').style.display=m==='month'?'block':'none';const st=id==='exit-detailed'||id==='floor-consolidated';document.getElementById('filter-type').style.display=st?'block':'none';const sr=id==='exit-detailed'||id==='exit-summary'||id==='exit-return'||id==='exit-others-detailed'||id==='floor-consolidated';document.getElementById('filter-reason').style.display=sr?'block':'none';document.getElementById('filter-card').style.display=id==='notifications'||id==='company-settings'||id==='system-settings'||id==='feature-settings'||id==='access-control'||id==='live-messages'?'none':'flex';}
function getFilteredData(){const f=state.selectedFloors;const m=document.getElementById('filter-mode')?document.getElementById('filter-mode').value:'today';const r=document.getElementById('filter-reason')?document.getElementById('filter-reason').value:'';const t=document.getElementById('filter-type')?document.getElementById('filter-type').value:'';let d='',df='',dt='',mo='';if(m==='today')d=getTodayStr();else if(m==='yesterday')d=getYesterdayStr();else if(m==='custom')d=formatDate(new Date(document.getElementById('filter-date').value));else if(m==='range'){df=formatDate(new Date(document.getElementById('filter-date-from').value));dt=formatDate(new Date(document.getElementById('filter-date-to').value));}else if(m==='month')mo=document.getElementById('filter-month').value;let e=state.entries.filter(i=>{let p=(f.length===0||f.includes(i.floor))&&(!d||i.date===d)&&(!df||i.date>=df)&&(!dt||i.date<=dt);if(mo){const dd=new Date(i.timestamp);p=p&&(`${dd.getFullYear()}-${String(dd.getMonth()+1).padStart(2,'0')}`===mo);}return p;});let x=state.exits.filter(i=>{let p=(f.length===0||f.includes(i.floor))&&(!d||i.date===d)&&(!df||i.date>=df)&&(!dt||i.date<=dt)&&(!r||(i.reason&&i.reason.includes(r)))&&(!t||i.type===t);if(mo){const dd=new Date(i.timestamp);p=p&&(`${dd.getFullYear()}-${String(dd.getMonth()+1).padStart(2,'0')}`===mo);}return p;});return{entries:e,exits:x};}
function getActiveFloors(){if(state.selectedFloors.length===0)return state.floors;return state.floors.filter(f=>state.selectedFloors.includes(f.name));}
function updateUI(){const td=getTodayStr();const fe=state.entries.filter(e=>e.floor===state.currentFloor&&e.date===td).length;const fx=state.exits.filter(e=>e.floor===state.currentFloor&&e.date===td).length;const fi=Math.max(0,fe-fx);const ee=document.getElementById('total-entry-count'),xe=document.getElementById('total-exit-count'),ie=document.getElementById('in-store-count');if(ee){const ov=ee.textContent;ee.textContent=fe;if(ov!==String(fe)){ee.style.transform='scale(1.2)';setTimeout(()=>ee.style.transform='scale(1)',200);}}if(xe){const ov=xe.textContent;xe.textContent=fx;if(ov!==String(fx)){xe.style.transform='scale(1.2)';setTimeout(()=>xe.style.transform='scale(1)',200);}}if(ie){const ov=ie.textContent;ie.textContent=fi;if(ov!==String(fi)){ie.style.transform='scale(1.2)';setTimeout(()=>ie.style.transform='scale(1)',200);}}if(!document.getElementById('screen-admin').classList.contains('hidden')){const a=document.activeElement;const ti=a&&['INPUT','TEXTAREA','SELECT'].includes(a.tagName)&&a.closest('#report-content');if(!ti){const{entries,exits}=getFilteredData();const ch=JSON.stringify(entries)+JSON.stringify(exits);if(ch!==lastRenderedDataHash){lastRenderedDataHash=ch;renderCurrentReport();}}}if(!document.getElementById('screen-home').classList.contains('hidden')){renderHourlyChart();renderHomeChatPanel();renderHomeCallPanel();}updateDocumentTitle();}
function formatDate(d){return String(d.getDate()).padStart(2,'0')+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+d.getFullYear();}
function formatTime(d){let h=d.getHours();const m=String(d.getMinutes()).padStart(2,'0');const a=h>=12?'PM':'AM';h=h%12||12;return`${h}:${m} ${a}`;}
function openModal(id){document.getElementById(id).classList.add('active');}
function closeModal(id){document.getElementById(id).classList.remove('active');}
function filterFloors(){const i=document.getElementById('login-floor'),o=document.getElementById('floor-options');const v=i.value.toLowerCase().trim();let f=v.length===0?state.floors:state.floors.filter(f=>f.name.toLowerCase().startsWith(v));if(f.length>0)o.innerHTML=f.map(f=>`<div class="select-option" tabindex="0" onmousedown="event.preventDefault();selectFloor('${f.name.replace(/'/g,"\\'")}')" onkeydown="handleOptionKeydown(event,'${f.name.replace(/'/g,"\\'")}')">${f.name}</div>`).join('');else o.innerHTML='<div class="select-option" style="cursor:default;color:var(--text-muted);">No matching floors</div>';o.classList.add('active');}
function handleFloorKeydown(e){const o=document.getElementById('floor-options'),i=o.querySelectorAll('.select-option');if(e.key==='ArrowDown'&&i.length>0){e.preventDefault();i[0].focus();}else if(e.key==='Enter')attemptLogin();}
function handleOptionKeydown(e,f){if(e.key==='Enter'){e.preventDefault();selectFloor(f);}else if(e.key==='ArrowDown'){e.preventDefault();const n=e.target.nextElementSibling;if(n&&n.classList.contains('select-option'))n.focus();}else if(e.key==='ArrowUp'){e.preventDefault();const p=e.target.previousElementSibling;if(p&&p.classList.contains('select-option'))p.focus();else document.getElementById('login-floor').focus();}}
function selectFloor(f){document.getElementById('login-floor').value=f;document.getElementById('floor-options').classList.remove('active');document.getElementById('floor-options').innerHTML='';document.getElementById('login-pin').focus();}
function renderSidebarNav(){try{const el=document.getElementById('sidebar-nav-items');if(!el){console.error('sidebar-nav-items element not found!');return;}if(!REPORTS_CONFIG||!Array.isArray(REPORTS_CONFIG)||REPORTS_CONFIG.length===0){console.error('REPORTS_CONFIG is empty!');el.innerHTML='<div style="padding:1rem;color:red;">No menu items configured</div>';return;}el.innerHTML=REPORTS_CONFIG.map(r=>`<div class="nav-item ${state.currentReport===r.id?'active':''}" data-id="${r.id}" onclick="openReport('${r.id}')"><i class="fas ${state.settings.enableIcons!==false?r.icon:''}"></i><span>${r.title}</span></div>`).join('');}catch(e){console.error('renderSidebarNav error:',e);}}
function openReport(id){if(state.currentReport)saveFilterState(state.currentReport);state.currentReport=id;document.getElementById('report-detail-title').textContent=REPORTS_CONFIG.find(r=>r.id===id).title;document.querySelectorAll('.nav-item').forEach(i=>i.classList.toggle('active',i.dataset.id===id));document.getElementById('admin-status-card').style.display=id==='dashboard'?'block':'none';loadFilterState(id);renderCurrentReport();updateDocumentTitle();}
function renderCurrentReport(){const c=document.getElementById('report-content');const sp=c.scrollTop;const{entries,exits}=getFilteredData();switch(state.currentReport){case'dashboard':c.innerHTML=rDashboard(entries,exits);break;case'floor-consolidated':c.innerHTML=rFloorConsolidated(entries,exits);break;case'floor-inout':c.innerHTML=rFloorInOut(entries,exits);break;case'entry-detailed':c.innerHTML=rEntryDetailed(entries);break;case'entry-summary-report':c.innerHTML=rEntrySummaryReport(entries);break;case'entry-breakdown':c.innerHTML=rEntryBreakdown(entries);break;case'exit-detailed':c.innerHTML=rExitDetailed(exits);break;case'exit-summary':c.innerHTML=rExitSummary(exits);break;case'exit-return':c.innerHTML=rExitReturn(exits);break;case'exit-others-detailed':c.innerHTML=rExitOthersDetailed(exits);break;case'entry-source-summary':c.innerHTML=rEntrySourceSummary(entries,exits);break;case'notifications':c.innerHTML=rNotifications(entries,exits);break;case'company-settings':c.innerHTML=rCompanySettings();break;case'system-settings':c.innerHTML=rSystemSettings();break;case'feature-settings':c.innerHTML=rFeatureSettings();break;case'access-control':c.innerHTML=rAccessControl();break;case'live-messages':c.innerHTML=rLiveMessages();break;case'custom-log':c.innerHTML=rCustomLog(exits);break;}c.scrollTop=sp;}

function rDashboard(e,x){const tE=e.length,tX=x.length,iS=Math.max(0,tE-tX);const p=x.filter(d=>d.type==='Purchase').length,r=x.filter(d=>d.type==='Return').length;const f=getActiveFloors();let fd=f.map(f=>{const fe=e.filter(i=>i.floor===f.name).length,fx=x.filter(i=>i.floor===f.name).length;return{name:f.name,e:fe,x:fx,i:Math.max(0,fe-fx)};}).filter(f=>f.e>0||f.x>0);let fr=fd.map(f=>`<tr><td>${f.name}</td><td style="text-align:right">${f.e}</td><td style="text-align:right">${f.x}</td><td style="text-align:right;color:#10b981;font-weight:700;">${f.i}</td></tr>`).join('');return`<div class="grid sm:grid-cols-3 gap-4 mb-6"><div class="card p-6"><div class="text-sm text-[var(--text-muted)] font-bold uppercase">Total Entry</div><div class="font-display font-extrabold text-5xl text-sky-400">${tE}</div></div><div class="card p-6"><div class="text-sm text-[var(--text-muted)] font-bold uppercase">Total Exit</div><div class="font-display font-extrabold text-5xl text-emerald-400">${tX}</div></div><div class="card p-6"><div class="text-sm text-pink-400 font-bold uppercase">In Store</div><div class="font-display font-extrabold text-5xl text-pink-400">${iS}</div></div></div><div class="grid sm:grid-cols-2 gap-4 mb-6"><div class="card p-5 flex items-center justify-between"><div class="text-sm font-bold text-emerald-400">Purchases</div><div class="font-display font-extrabold text-3xl text-emerald-400">${p}</div></div><div class="card p-5 flex items-center justify-between"><div class="text-sm font-bold text-red-400">Returns</div><div class="font-display font-extrabold text-3xl text-red-400">${r}</div></div></div><div class="card overflow-hidden"><div class="p-4 border-b border-[var(--border)]"><h3 class="font-display font-bold text-lg">Active Floor Analytics</h3></div><table class="data-table"><thead><tr><th style="text-align:left">Floor</th><th style="text-align:right">Entries</th><th style="text-align:right">Exits</th><th style="text-align:right">In Store</th></tr></thead><tbody>${fr||'<tr><td colspan="4" style="text-align:center;padding:2rem;">No data</td></tr>'}</tbody></table></div>`;}

function rFloorConsolidated(e,x){
  const floors=getActiveFloors();
  const reasons=state.settings.returnReasons.map(r=>r.name);
  const nR=reasons.length;
  // DARK SOLID heading colors for clear print visibility
  const HDR_MAIN='#0c4a6e';      // sky-900 - main category headers (Floor Name, Total Entries, Purchase, Total Returns, Total Exits)
  const HDR_GROUP='#075985';    // sky-800 - group headers (Entries, Returns)
  const HDR_SUB='#0369a1';      // sky-700 - sub-headers (Single, Couple, Family, reason names)
  const HDR_RETURN_MAIN='#7f1d1d';   // red-900 - Total Returns standalone (kept red theme but solid)
  const HDR_RETURN_GROUP='#991b1b';  // red-800 - Returns group
  const HDR_RETURN_SUB='#b91c1c';    // red-700 - reason sub-headers
  const HDR_PURCHASE='#065f46';      // emerald-800 - Purchase
  const HDR_PURCHASE_TOT='#064e3b';  // emerald-900 - Total Exits
  const WHITE='#ffffff';
  // Total cells colors (darker for visibility)
  const TOT_ENTRY_BG='#0c4a6e';   // sky-900
  const TOT_PURCHASE_BG='#065f46'; // emerald-800
  const TOT_RETURN_BG='#7f1d1d';  // red-900
  const TOT_EXIT_BG='#064e3b';    // emerald-900
  let rows=floors.map((f,fi)=>{
    const s=e.filter(i=>i.floor===f.name&&i.category==='Single').length;
    const c=e.filter(i=>i.floor===f.name&&i.category==='Couple').length;
    const fm=e.filter(i=>i.floor===f.name&&i.category==='Family').length;
    const p=x.filter(i=>i.floor===f.name&&i.type==='Purchase').length;
    const rd=reasons.map(rs=>x.filter(i=>i.floor===f.name&&i.type==='Return'&&i.reason&&i.reason.includes(rs)).length);
    const totalEntry=s+c+fm;
    const totalReturn=rd.reduce((a,b)=>a+b,0);
    const totalExit=p+totalReturn;
    const dash = v => v>0 ? v : '-';
    const rowBg = fi%2===0 ? '' : 'background:rgba(255,255,255,0.02);';
    const entryCell = (v) => `<td class="text-center ${v>0?'text-sky-300':'text-[var(--text-dim)]'}" style="${rowBg}border:1px solid #1e293b;padding:6px 4px;">${dash(v)}</td>`;
    const totalEntryCell = `<td class="text-center font-extrabold" style="${rowBg}background:${TOT_ENTRY_BG};color:${WHITE};border:1px solid #1e293b;padding:6px 4px;">${totalEntry}</td>`;
    const purchaseCell = `<td class="text-center ${p>0?'text-emerald-300':'text-[var(--text-dim)]'}" style="${rowBg}border:1px solid #1e293b;padding:6px 4px;">${dash(p)}</td>`;
    const returnCells = rd.map(cc=>`<td class="text-center ${cc>0?'text-red-300':'text-[var(--text-dim)]'}" style="${rowBg}border:1px solid #1e293b;padding:6px 4px;">${dash(cc)}</td>`).join('');
    const totalReturnCell = `<td class="text-center font-extrabold" style="${rowBg}background:${TOT_RETURN_BG};color:${WHITE};border:1px solid #1e293b;padding:6px 4px;">${dash(totalReturn)}</td>`;
    const totalExitCell = `<td class="text-center font-extrabold" style="${rowBg}background:${TOT_EXIT_BG};color:${WHITE};border:1px solid #1e293b;padding:6px 4px;">${totalExit}</td>`;
    return `<tr><td class="font-bold" style="background:${HDR_MAIN};color:${WHITE};border:1px solid #1e293b;padding:8px 10px;white-space:nowrap;">${f.name}</td>${entryCell(s)}${entryCell(c)}${entryCell(fm)}${totalEntryCell}${purchaseCell}${returnCells}${totalReturnCell}${totalExitCell}</tr>`;
  }).join('');
  const totS=e.filter(i=>floors.some(f=>f.name===i.floor)&&i.category==='Single').length;
  const totC=e.filter(i=>floors.some(f=>f.name===i.floor)&&i.category==='Couple').length;
  const totFm=e.filter(i=>floors.some(f=>f.name===i.floor)&&i.category==='Family').length;
  const totP=x.filter(i=>floors.some(f=>f.name===i.floor)&&i.type==='Purchase').length;
  const totRd=reasons.map(rs=>x.filter(i=>floors.some(f=>f.name===i.floor)&&i.type==='Return'&&i.reason&&i.reason.includes(rs)).length);
  const totRdSum=totRd.reduce((a,b)=>a+b,0);
  const totEntryAll=totS+totC+totFm;
  const totExitAll=totP+totRdSum;
  const dash = v => v>0 ? v : '-';
  const totalRow=floors.length>0?`<tfoot><tr>
    <td class="font-extrabold" style="background:${HDR_MAIN};color:${WHITE};border:1px solid #1e293b;padding:8px 10px;">TOTAL</td>
    <td class="text-center font-extrabold" style="background:${HDR_GROUP};color:${WHITE};border:1px solid #1e293b;padding:8px 4px;">${dash(totS)}</td>
    <td class="text-center font-extrabold" style="background:${HDR_GROUP};color:${WHITE};border:1px solid #1e293b;padding:8px 4px;">${dash(totC)}</td>
    <td class="text-center font-extrabold" style="background:${HDR_GROUP};color:${WHITE};border:1px solid #1e293b;padding:8px 4px;">${dash(totFm)}</td>
    <td class="text-center font-extrabold" style="background:${TOT_ENTRY_BG};color:${WHITE};border:1px solid #1e293b;padding:8px 4px;">${totEntryAll}</td>
    <td class="text-center font-extrabold" style="background:${HDR_PURCHASE};color:${WHITE};border:1px solid #1e293b;padding:8px 4px;">${dash(totP)}</td>
    ${totRd.map(cc=>`<td class="text-center font-extrabold" style="background:${HDR_RETURN_GROUP};color:${WHITE};border:1px solid #1e293b;padding:8px 4px;">${dash(cc)}</td>`).join('')}
    <td class="text-center font-extrabold" style="background:${TOT_RETURN_BG};color:${WHITE};border:1px solid #1e293b;padding:8px 4px;">${dash(totRdSum)}</td>
    <td class="text-center font-extrabold" style="background:${TOT_EXIT_BG};color:${WHITE};border:1px solid #1e293b;padding:8px 4px;">${totExitAll}</td>
  </tr></tfoot>`:'';
  const rh=reasons.map(r=>`<th class="text-center" style="background:${HDR_RETURN_SUB};color:${WHITE};font-size:10px;font-weight:700;border:1px solid #1e293b;border-bottom:2px solid #1e293b;">${r}</th>`).join('');
  const others=x.filter(i=>i.type==='Return'&&i.reason&&i.reason.toLowerCase().startsWith('other')).slice().reverse();
  const othersRows=others.map((d,i)=>{let reasonText=d.reason||'';if(reasonText.toLowerCase().startsWith('other:'))reasonText=reasonText.substring(6).trim();const cIdx=reasonText.toLowerCase().indexOf('| comment:');if(cIdx!==-1)reasonText=reasonText.substring(0,cIdx).trim();return `<tr><td class="text-center text-white" style="font-weight:600;background:#dc2626;">${i+1}</td><td><span class="others-floor-cell">${d.floor||'-'}</span></td><td class="others-reason-cell">${reasonText||'-'}</td><td class="others-mobile-cell">${d.mobile||'-'}</td><td class="text-center">${d.image?`<img src="${d.image}" class="w-12 h-12 rounded-lg object-cover cursor-pointer" style="border:1px solid #dc2626;" onclick="window.open('${d.image}','_blank')">`:'<span class="text-[var(--text-dim)]">-</span>'}</td><td>${d.date}</td><td>${d.time}</td><td>${d.employee||'-'}</td></tr>`;}).join('');
  const othersSection=others.length>0?`<div class="others-section-box"><div class="others-section-heading"><h3>Other Reasons Detailed Report</h3><p>Floor-wise custom return reasons with attached report</p></div><div class="overflow-x-auto"><table class="data-table others-table"><thead><tr><th class="text-center" style="width:40px;">#</th><th style="min-width:110px;">Floor Name</th><th style="min-width:180px;">Reason</th><th style="min-width:100px;">Mobile</th><th class="text-center" style="min-width:70px;">Attached Report</th><th style="min-width:90px;">Date</th><th style="min-width:80px;">Time</th><th style="min-width:90px;">Employee</th></tr></thead><tbody>${othersRows}</tbody></table></div></div>`:'';
  const emptyBody = floors.length===0 ? `<tbody><tr><td colspan="${8+nR}" class="text-center p-8 text-[var(--text-muted)]">No data</td></tr></tbody>` : `<tbody>${rows}</tbody>`;
  return `<div class="card overflow-hidden mb-6">
    <div class="p-4 border-b border-[var(--border)]">
      <h3 class="font-display font-bold text-lg">Floor Consolidated Summary</h3>
      <p class="text-xs text-[var(--text-muted)] mt-1">Floor-wise entries (Single/Couple/Family) and exits (Purchase/Returns/Total Returns) breakdown</p>
    </div>
    <div class="overflow-x-auto">
      <table class="data-table" style="border-collapse:collapse;width:100%;">
        <thead>
          <tr>
            <th rowspan="2" style="background:${HDR_MAIN};color:${WHITE};border:1px solid #1e293b;padding:8px 10px;vertical-align:middle;font-weight:700;">FLOOR NAME</th>
            <th colspan="3" class="text-center" style="background:${HDR_GROUP};color:${WHITE};border:1px solid #1e293b;padding:8px 4px;font-weight:700;">Entries</th>
            <th rowspan="2" class="text-center" style="background:${HDR_MAIN};color:${WHITE};border:1px solid #1e293b;padding:8px 4px;vertical-align:middle;font-weight:700;">Total Entries</th>
            <th rowspan="2" class="text-center" style="background:${HDR_PURCHASE};color:${WHITE};border:1px solid #1e293b;padding:8px 4px;vertical-align:middle;font-weight:700;">Purchase</th>
            <th colspan="${nR}" class="text-center" style="background:${HDR_RETURN_GROUP};color:${WHITE};border:1px solid #1e293b;padding:8px 4px;font-weight:700;">Returns</th>
            <th rowspan="2" class="text-center" style="background:${HDR_RETURN_MAIN};color:${WHITE};border:1px solid #1e293b;padding:8px 4px;vertical-align:middle;font-weight:700;">Total Returns</th>
            <th rowspan="2" class="text-center" style="background:${HDR_PURCHASE_TOT};color:${WHITE};border:1px solid #1e293b;padding:8px 4px;vertical-align:middle;font-weight:700;">Total Exits</th>
          </tr>
          <tr>
            <th class="text-center" style="background:${HDR_SUB};color:${WHITE};font-size:10px;font-weight:700;border:1px solid #1e293b;border-bottom:2px solid #1e293b;">Single</th>
            <th class="text-center" style="background:${HDR_SUB};color:${WHITE};font-size:10px;font-weight:700;border:1px solid #1e293b;border-bottom:2px solid #1e293b;">Couple</th>
            <th class="text-center" style="background:${HDR_SUB};color:${WHITE};font-size:10px;font-weight:700;border:1px solid #1e293b;border-bottom:2px solid #1e293b;">Family</th>
            ${rh}
          </tr>
        </thead>
        ${emptyBody}
        ${totalRow}
      </table>
    </div>
  </div>
  <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mt-5 mb-6">
    <div class="card p-4 text-center"><div class="text-xs text-[var(--text-muted)] font-bold uppercase mb-1">Total Entries</div><div class="font-display font-extrabold text-2xl text-sky-400">${totEntryAll}</div></div>
    <div class="card p-4 text-center"><div class="text-xs text-[var(--text-muted)] font-bold uppercase mb-1">Total Exits</div><div class="font-display font-extrabold text-2xl text-emerald-400">${totExitAll}</div></div>
    <div class="card p-4 text-center"><div class="text-xs text-[var(--text-muted)] font-bold uppercase mb-1">Total Purchase</div><div class="font-display font-extrabold text-2xl text-emerald-400">${totP}</div></div>
    <div class="card p-4 text-center"><div class="text-xs text-[var(--text-muted)] font-bold uppercase mb-1">Total Return</div><div class="font-display font-extrabold text-2xl text-red-400">${totRdSum}</div></div>
  </div>${buildWayOfSourceSummary(e)}${othersSection}`;
}

// Way of Source Category-wise Summary - shows each source name + total count, plus custom text breakdown for Others
function buildWayOfSourceSummary(entries) {
  if (state.settings.enableWayOfSource === false) return '';
  const sources = state.settings.wayOfSources || [];
  if (sources.length === 0) return '';
  const cats = ['Single', 'Couple', 'Family'];
  const allEntries = entries.filter(i => floorsContain(i.floor));
  // DARK SOLID heading colors for clear print visibility
  const HDR_MAIN='#0c4a6e';   // sky-900 - Way of Source, Total Count
  const HDR_GROUP='#075985';  // sky-800 - Categories group
  const HDR_SUB='#0369a1';    // sky-700 - Single/Couple/Family sub-headers
  const WHITE='#ffffff';
  const TOT_BG='#0c4a6e';     // sky-900 - total cells
  // For each source, compute count per category + total
  // Also collect custom-text entries (wayOfSource starts with 'Other: ')
  let sourceRows = '';
  let grandTotal = 0;
  let customTextMap = {}; // { 'Others': [{text:'Twitter', count:2, byCat:{Single:1,Couple:0,Family:1}}] }
  sources.forEach((src, srcIdx) => {
    const srcName = src.name || '';
    const isCustom = src.customEnabled || srcName.toLowerCase().startsWith('other');
    // Match entries whose wayOfSource equals srcName, OR (for 'Other' sources) starts with 'Other: '
    let matching;
    if (isCustom) {
      matching = allEntries.filter(i => {
        if (!i.wayOfSource) return false;
        if (i.wayOfSource === srcName) return true;
        // 'Other: <custom>' entries that belong to this source if srcName starts with 'other'
        if (srcName.toLowerCase().startsWith('other') && i.wayOfSource.toLowerCase().startsWith('other:')) return true;
        // Or, for sources explicitly marked customEnabled, entries where wayOfSource === srcName
        return i.wayOfSource === srcName;
      });
    } else {
      matching = allEntries.filter(i => i.wayOfSource === srcName);
    }
    const perCat = cats.map(cat => matching.filter(i => i.category === cat).length);
    const total = matching.length;
    grandTotal += total;
    const dash = v => v > 0 ? v : '-';
    const rowBg = srcIdx % 2 === 0 ? '' : 'background:rgba(255,255,255,0.02);';
    const srcIcon = src.icon || 'fa-tag';
    sourceRows += `<tr>
      <td class="font-bold flex items-center gap-2" style="background:${HDR_MAIN};color:${WHITE};border:1px solid #1e293b;padding:8px 10px;white-space:nowrap;"><i class="fas ${srcIcon}" style="color:#7dd3fc;"></i><span>${escapeHtml(srcName)}</span>${isCustom?'<span class="tag-mini tag-cmt">CUSTOM</span>':''}</td>
      <td class="text-center ${perCat[0]>0?'text-sky-300':'text-[var(--text-dim)]'}" style="${rowBg}border:1px solid #1e293b;padding:6px 4px;">${dash(perCat[0])}</td>
      <td class="text-center ${perCat[1]>0?'text-sky-300':'text-[var(--text-dim)]'}" style="${rowBg}border:1px solid #1e293b;padding:6px 4px;">${dash(perCat[1])}</td>
      <td class="text-center ${perCat[2]>0?'text-sky-300':'text-[var(--text-dim)]'}" style="${rowBg}border:1px solid #1e293b;padding:6px 4px;">${dash(perCat[2])}</td>
      <td class="text-center font-extrabold" style="${rowBg}background:${TOT_BG};color:${WHITE};border:1px solid #1e293b;padding:6px 4px;">${total}</td>
    </tr>`;
    // For custom-enabled sources, also break down by custom text value
    if (isCustom) {
      const customEntries = allEntries.filter(i => {
        if (!i.wayOfSource) return false;
        // Entries with 'Other: <text>' format
        if (srcName.toLowerCase().startsWith('other') && i.wayOfSource.toLowerCase().startsWith('other:')) return true;
        // Or entries where wayOfSource is not exactly matching any other defined source name
        return false;
      });
      // Group by custom text
      const groups = {};
      customEntries.forEach(i => {
        let customText = i.wayOfSource;
        if (customText.toLowerCase().startsWith('other:')) customText = customText.substring(6).trim();
        if (customText.toLowerCase().indexOf('| comment:') !== -1) customText = customText.substring(0, customText.toLowerCase().indexOf('| comment:')).trim();
        if (!groups[customText]) groups[customText] = { count: 0, byCat: {Single:0, Couple:0, Family:0} };
        groups[customText].count++;
        if (groups[customText].byCat[i.category] !== undefined) groups[customText].byCat[i.category]++;
      });
      const customTexts = Object.keys(groups);
      if (customTexts.length > 0) {
        if (!customTextMap[srcName]) customTextMap[srcName] = [];
        customTexts.forEach(text => customTextMap[srcName].push({text, ...groups[text]}));
      }
    }
  });
  // Build custom text detail rows (nested under their parent source)
  let customDetailHtml = '';
  Object.keys(customTextMap).forEach(srcName => {
    const items = customTextMap[srcName].sort((a,b) => b.count - a.count);
    items.forEach((item, idx) => {
      const dash = v => v > 0 ? v : '-';
      const rowBg = idx % 2 === 0 ? '' : 'background:rgba(255,255,255,0.02);';
      customDetailHtml += `<tr>
        <td class="text-[var(--text-muted)] flex items-center gap-2" style="background:rgba(14,165,233,0.04);border:1px solid #1e293b;padding:6px 10px;padding-left:32px;white-space:nowrap;"><i class="fas fa-chevron-right text-[10px] text-[var(--text-muted)]"></i><span class="text-xs">${escapeHtml(item.text)}</span></td>
        <td class="text-center ${item.byCat.Single>0?'text-sky-300':'text-[var(--text-dim)]'}" style="${rowBg}border:1px solid #1e293b;padding:6px 4px;">${dash(item.byCat.Single)}</td>
        <td class="text-center ${item.byCat.Couple>0?'text-sky-300':'text-[var(--text-dim)]'}" style="${rowBg}border:1px solid #1e293b;padding:6px 4px;">${dash(item.byCat.Couple)}</td>
        <td class="text-center ${item.byCat.Family>0?'text-sky-300':'text-[var(--text-dim)]'}" style="${rowBg}border:1px solid #1e293b;padding:6px 4px;">${dash(item.byCat.Family)}</td>
        <td class="text-center font-bold text-sky-300" style="${rowBg}background:rgba(14,165,233,0.15);border:1px solid #1e293b;padding:6px 4px;">${item.count}</td>
      </tr>`;
    });
  });
  const totalRow = `<tfoot><tr>
    <td class="font-extrabold" style="background:${HDR_MAIN};color:${WHITE};border:1px solid #1e293b;padding:8px 10px;">GRAND TOTAL</td>
    <td class="text-center font-extrabold" style="background:${HDR_GROUP};color:${WHITE};border:1px solid #1e293b;padding:8px 4px;">${allEntries.filter(i=>i.category==='Single').length}</td>
    <td class="text-center font-extrabold" style="background:${HDR_GROUP};color:${WHITE};border:1px solid #1e293b;padding:8px 4px;">${allEntries.filter(i=>i.category==='Couple').length}</td>
    <td class="text-center font-extrabold" style="background:${HDR_GROUP};color:${WHITE};border:1px solid #1e293b;padding:8px 4px;">${allEntries.filter(i=>i.category==='Family').length}</td>
    <td class="text-center font-extrabold" style="background:${TOT_BG};color:${WHITE};border:1px solid #1e293b;padding:8px 4px;">${grandTotal}</td>
  </tr></tfoot>`;
  return `<div class="card overflow-hidden mb-6">
    <div class="p-4 border-b border-[var(--border)]">
      <h3 class="font-display font-bold text-lg">Way of Source Summary (Category-wise)</h3>
      <p class="text-xs text-[var(--text-muted)] mt-1">Entry count by way of source, broken down by Single/Couple/Family. Custom text entries for "Others" appear nested below their source.</p>
    </div>
    <div class="overflow-x-auto">
      <table class="data-table" style="border-collapse:collapse;width:100%;">
        <thead>
          <tr>
            <th rowspan="2" style="background:${HDR_MAIN};color:${WHITE};border:1px solid #1e293b;padding:8px 10px;vertical-align:middle;font-weight:700;">WAY OF SOURCE</th>
            <th colspan="3" class="text-center" style="background:${HDR_GROUP};color:${WHITE};border:1px solid #1e293b;padding:8px 4px;font-weight:700;">Categories</th>
            <th rowspan="2" class="text-center" style="background:${HDR_MAIN};color:${WHITE};border:1px solid #1e293b;padding:8px 4px;vertical-align:middle;font-weight:700;">Total Count</th>
          </tr>
          <tr>
            <th class="text-center" style="background:${HDR_SUB};color:${WHITE};font-size:10px;font-weight:700;border:1px solid #1e293b;border-bottom:2px solid #1e293b;">Single</th>
            <th class="text-center" style="background:${HDR_SUB};color:${WHITE};font-size:10px;font-weight:700;border:1px solid #1e293b;border-bottom:2px solid #1e293b;">Couple</th>
            <th class="text-center" style="background:${HDR_SUB};color:${WHITE};font-size:10px;font-weight:700;border:1px solid #1e293b;border-bottom:2px solid #1e293b;">Family</th>
          </tr>
        </thead>
        <tbody>${sourceRows}${customDetailHtml}</tbody>
        ${totalRow}
      </table>
    </div>
  </div>`;
}
function floorsContain(name){const fs=getActiveFloors();return fs.some(f=>f.name===name);}
function escapeHtml(s){if(s===null||s===undefined)return'';return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'})[c]);}

function rFloorInOut(e,x){const f=getActiveFloors();let r=f.map(f=>{const fe=e.filter(i=>i.floor===f.name).length,fx=x.filter(i=>i.floor===f.name).length;return`<tr><td>${f.name}</td><td class="text-right">${fe}</td><td class="text-right">${fx}</td><td class="text-right font-bold text-emerald-400">${Math.max(0,fe-fx)}</td></tr>`;}).join('');const totE=e.filter(i=>f.some(ff=>ff.name===i.floor)).length,totX=x.filter(i=>f.some(ff=>ff.name===i.floor)).length;const totalRow=f.length>0?`<tfoot><tr><td class="font-extrabold">TOTAL</td><td class="text-right font-extrabold">${totE}</td><td class="text-right font-extrabold">${totX}</td><td class="text-right font-extrabold text-emerald-400">${Math.max(0,totE-totX)}</td></tr></tfoot>`:'';return`<div class="card overflow-hidden"><table class="data-table"><thead><tr><th>Floor</th><th class="text-right">Entries</th><th class="text-right">Exits</th><th class="text-right">In Store</th></tr></thead><tbody>${r||'<tr><td colspan="4" class="text-center p-8">No data</td></tr>'}</tbody>${totalRow}</table></div>`;}

function rEntryDetailed(e){const s=e.slice().reverse();const totalRow=s.length>0?`<tfoot><tr><td colspan="6" class="text-right font-extrabold">TOTAL ENTRIES</td><td class="font-extrabold text-sky-400">${s.length}</td></tr></tfoot>`:'';return`<div class="card overflow-hidden"><table class="data-table"><thead><tr><th>#</th><th>Floor</th><th>Category</th><th>Way of Source</th><th>Date</th><th>Time</th><th>Employee</th></tr></thead><tbody>${s.map((d,i)=>`<tr><td>${i+1}</td><td>${d.floor||'-'}</td><td><span class="badge badge-blue">${d.category}</span></td><td><span class="badge" style="background:rgba(14,165,233,0.15);color:#7dd3fc;">${d.wayOfSource||'-'}</span></td><td>${d.date}</td><td>${d.time}</td><td>${d.employee||'-'}</td></tr>`).join('')||'<tr><td colspan="7" class="text-center p-8">No data</td></tr>'}</tbody>${totalRow}</table></div>`;}

function rEntrySummaryReport(e) {
    const floors = getActiveFloors();
    const sources = state.settings.wayOfSources.map(s => s.name);
    let rows = floors.map(f => {
        const sCount = e.filter(i => i.floor === f.name && i.category === 'Single').length;
        const cCount = e.filter(i => i.floor === f.name && i.category === 'Couple').length;
        const fCount = e.filter(i => i.floor === f.name && i.category === 'Family').length;
        const totalEntry = sCount + cCount + fCount;
        const sd = sources.map(src => e.filter(i => i.floor === f.name && (i.wayOfSource === src || (src.toLowerCase().startsWith('other') && i.wayOfSource && i.wayOfSource.toLowerCase().startsWith('other')))).length);
        return `<tr><td class="font-bold" style="white-space:nowrap;">${f.name}</td><td class="text-center text-sky-300 font-bold" style="background:rgba(14,165,233,0.08);">${totalEntry}</td><td class="text-center text-sky-400">${sCount}</td><td class="text-center text-sky-400">${cCount}</td><td class="text-center text-sky-400">${fCount}</td>${sd.map(c => `<td class="text-center text-cyan-400">${c}</td>`).join('')}</tr>`;
    }).join('');
    const totS = e.filter(i => floors.some(f => f.name === i.floor) && i.category === 'Single').length;
    const totC = e.filter(i => floors.some(f => f.name === i.floor) && i.category === 'Couple').length;
    const totFm = e.filter(i => floors.some(f => f.name === i.floor) && i.category === 'Family').length;
    const totE = totS + totC + totFm;
    const totSd = sources.map(src => e.filter(i => floors.some(f => f.name === i.floor) && (i.wayOfSource === src || (src.toLowerCase().startsWith('other') && i.wayOfSource && i.wayOfSource.toLowerCase().startsWith('other')))).length);
    const totalRow = floors.length > 0 ? `<tfoot><tr><td class="font-extrabold">TOTAL</td><td class="text-center text-sky-300 font-extrabold" style="background:rgba(14,165,233,0.15);">${totE}</td><td class="text-center text-sky-400 font-extrabold">${totS}</td><td class="text-center text-sky-400 font-extrabold">${totC}</td><td class="text-center text-sky-400 font-extrabold">${totFm}</td>${totSd.map(c => `<td class="text-center text-cyan-400 font-extrabold">${c}</td>`).join('')}</tr></tfoot>` : '';
    const sh = sources.map(s => `<th class="text-center" style="background:rgba(14,165,233,0.15);color:#7dd3fc;">${s}</th>`).join('');
    return `<div class="card overflow-hidden mb-6"><div class="p-4 border-b border-[var(--border)]"><h3 class="font-display font-bold text-lg">Customer Entry Summary (Floor-wise)</h3></div><div class="overflow-x-auto"><table class="data-table"><thead><tr><th rowspan="2">Floor</th><th rowspan="2" class="text-center" style="background:rgba(14,165,233,0.2);color:#38bdf8;">Total Entries</th><th colspan="3" class="text-center" style="background:rgba(14,165,233,0.1);color:#7dd3fc;">Categories</th><th colspan="${sources.length}" class="text-center" style="background:rgba(14,165,233,0.15);color:#7dd3fc;">Way of Source</th></tr><tr><th class="text-center" style="background:rgba(14,165,233,0.1);color:#7dd3fc;">Single</th><th class="text-center" style="background:rgba(14,165,233,0.1);color:#7dd3fc;">Couple</th><th class="text-center" style="background:rgba(14,165,233,0.1);color:#7dd3fc;">Family</th>${sh}</tr></thead><tbody>${rows || `<tr><td colspan="${6 + sources.length}" class="text-center p-8">No data</td></tr>`}</tbody>${totalRow}</table></div></div>`;
}

function rEntryBreakdown(e) {
    const floors = getActiveFloors();
    const sources = state.settings.wayOfSources.map(s => s.name);
    const cats = ['Single', 'Couple', 'Family'];
    const nSrc = sources.length;
    // DARK SOLID heading colors for clear print visibility
    const HDR_MAIN='#0c4a6e';   // sky-900 - Floor Name, Total Count
    const HDR_GROUP='#075985';  // sky-800 - category group headers (Single, Couple, Family)
    const HDR_SUB='#0369a1';    // sky-700 - source sub-headers
    const WHITE='#ffffff';
    const TOT_BG='#0c4a6e';     // sky-900 - total cells
    // Two-tier header: Floor Name (rowspan 2) | Single (colspan nSrc) | Couple (colspan nSrc) | Family (colspan nSrc)
    const catHeaderCells = cats.map(cat =>
        `<th colspan="${nSrc}" class="text-center" style="background:${HDR_GROUP};color:${WHITE};border-bottom:1px solid #1e293b;font-weight:700;">${cat}</th>`
    ).join('');
    const subHeaderCells = cats.map(() =>
        sources.map(s => `<th class="text-center" style="background:${HDR_SUB};color:${WHITE};font-size:10px;font-weight:700;border-bottom:2px solid #1e293b;">${s}</th>`).join('')
    ).join('');
    // Body rows - one per floor
    let bodyRows = '';
    let grandTotals = new Array(cats.length * nSrc).fill(0);
    let allTotal = 0;
    floors.forEach((f, fi) => {
        let cells = '';
        cats.forEach((cat, catIdx) => {
            sources.forEach((src, srcIdx) => {
                const count = e.filter(i => i.floor === f.name && i.category === cat && (i.wayOfSource === src || (src.toLowerCase().startsWith('other') && i.wayOfSource && i.wayOfSource.toLowerCase().startsWith('other')))).length;
                const cellColor = count > 0 ? 'text-sky-300' : 'text-[var(--text-dim)]';
                const cellBg = fi % 2 === 0 ? '' : 'background:rgba(255,255,255,0.02);';
                cells += `<td class="text-center ${cellColor}" style="${cellBg}border:1px solid #1e293b;padding:6px 4px;">${count > 0 ? count : '-'}</td>`;
                grandTotals[catIdx * nSrc + srcIdx] += count;
                allTotal += count;
            });
        });
        bodyRows += `<tr><td class="font-bold" style="background:${HDR_MAIN};color:${WHITE};border:1px solid #1e293b;padding:8px 10px;white-space:nowrap;">${f.name}</td>${cells}</tr>`;
    });
    // Grand total footer
    const totalCells = grandTotals.map(c =>
        `<td class="text-center font-extrabold" style="background:${TOT_BG};color:${WHITE};border:1px solid #1e293b;padding:8px 4px;">${c > 0 ? c : '-'}</td>`
    ).join('');
    const totalRow = floors.length > 0
        ? `<tfoot><tr><td class="font-extrabold" style="background:${HDR_MAIN};color:${WHITE};border:1px solid #1e293b;padding:8px 10px;">TOTAL</td>${totalCells}</tr></tfoot>`
        : '';
    const emptyBody = floors.length === 0
        ? `<tbody><tr><td colspan="${1 + cats.length * nSrc}" class="text-center p-8 text-[var(--text-muted)]">No data</td></tr></tbody>`
        : `<tbody>${bodyRows}</tbody>`;
    return `<div class="card overflow-hidden">
      <div class="p-4 border-b border-[var(--border)]">
        <h3 class="font-display font-bold text-lg">Customer Entry Breakdown</h3>
        <p class="text-xs text-[var(--text-muted)] mt-1">Floor-wise entry counts by category and way of source</p>
      </div>
      <div class="overflow-x-auto">
        <table class="data-table" style="border-collapse:collapse;width:100%;">
          <thead>
            <tr>
              <th rowspan="2" style="background:${HDR_MAIN};color:${WHITE};border:1px solid #1e293b;padding:8px 10px;vertical-align:middle;font-weight:700;">FLOOR NAME</th>
              ${catHeaderCells}
            </tr>
            <tr>${subHeaderCells}</tr>
          </thead>
          ${emptyBody}
          ${totalRow}
        </table>
      </div>
    </div>`;
}

function rExitDetailed(x){const s=x.slice().reverse();const totalRow=s.length>0?`<tfoot><tr><td colspan="8" class="text-right font-extrabold">TOTAL EXITS</td><td class="font-extrabold text-emerald-400">${s.length}</td></tr></tfoot>`:'';return`<div class="card overflow-hidden"><table class="data-table"><thead><tr><th>#</th><th>Floor</th><th>Type</th><th>Reason</th><th>Mobile</th><th>Image</th><th>Date</th><th>Time</th><th>Employee</th></tr></thead><tbody>${s.map((d,i)=>`<tr><td>${i+1}</td><td>${d.floor||'-'}</td><td>${d.type==='Purchase'?'<span class="badge badge-emerald">Purchase</span>':'<span class="badge badge-red">Return</span>'}</td><td>${d.reason||'-'}</td><td style="color:#f472b6;font-weight:600;">${d.mobile||'-'}</td><td>${d.image?`<img src="${d.image}" class="w-12 h-12 rounded object-cover cursor-pointer" onclick="window.open('${d.image}','_blank')">`:'-'}</td><td>${d.date}</td><td>${d.time}</td><td>${d.employee||'-'}</td></tr>`).join('')||'<tr><td colspan="9" class="text-center p-8">No data</td></tr>'}</tbody>${totalRow}</table></div>`;}
function rExitSummary(x){const f=getActiveFloors();let r=f.map(f=>{const p=x.filter(i=>i.floor===f.name&&i.type==='Purchase').length,r=x.filter(i=>i.floor===f.name&&i.type==='Return').length;return`<tr><td>${f.name}</td><td class="text-right text-emerald-400">${p}</td><td class="text-right text-red-400">${r}</td><td class="text-right font-bold">${p+r}</td></tr>`;}).join('');const totP=x.filter(i=>f.some(ff=>ff.name===i.floor)&&i.type==='Purchase').length,totR=x.filter(i=>f.some(ff=>ff.name===i.floor)&&i.type==='Return').length;const totalRow=f.length>0?`<tfoot><tr><td class="font-extrabold">TOTAL</td><td class="text-right text-emerald-400 font-extrabold">${totP}</td><td class="text-right text-red-400 font-extrabold">${totR}</td><td class="text-right font-extrabold">${totP+totR}</td></tr></tfoot>`:'';return`<div class="card overflow-hidden"><table class="data-table"><thead><tr><th>Floor</th><th class="text-right">Purchases</th><th class="text-right">Returns</th><th class="text-right">Total</th></tr></thead><tbody>${r||'<tr><td colspan="4" class="text-center p-8">No data</td></tr>'}</tbody>${totalRow}</table></div>`;}
function rExitReturn(x){const floors=getActiveFloors();const reasons=state.settings.returnReasons.map(r=>r.name);let rows=floors.map(f=>{const rd=reasons.map(rs=>x.filter(i=>i.floor===f.name&&i.reason&&i.reason.includes(rs)).length);const tot=x.filter(i=>i.floor===f.name&&i.type==='Return').length;return`<tr><td>${f.name}</td>${rd.map(c=>`<td class="text-center">${c}</td>`).join('')}<td class="text-right font-bold">${tot}</td></tr>`;}).join('');const totRd=reasons.map(rs=>x.filter(i=>floors.some(f=>f.name===i.floor)&&i.reason&&i.reason.includes(rs)).length);const grandTot=x.filter(i=>floors.some(f=>f.name===i.floor)&&i.type==='Return').length;const totalRow=floors.length>0?`<tfoot><tr><td class="font-extrabold">TOTAL</td>${totRd.map(c=>`<td class="text-center font-extrabold">${c}</td>`).join('')}<td class="text-right font-extrabold">${grandTot}</td></tr></tfoot>`:'';return`<div class="card overflow-hidden"><table class="data-table"><thead><tr><th>Floor</th>${reasons.map(r=>`<th class="text-center">${r}</th>`).join('')}<th class="text-right">Total</th></tr></thead><tbody>${rows||'<tr><td colspan="'+(reasons.length+2)+'" class="text-center p-8">No data</td></tr>'}</tbody>${totalRow}</table></div>`;}

function rExitOthersDetailed(x){
  const s=x.filter(i=>i.type==='Return'&&i.reason&&i.reason.toLowerCase().startsWith('other')).slice().reverse();
  const totalRow=s.length>0?`<tfoot><tr><td colspan="7" class="text-right font-extrabold">TOTAL OTHERS</td><td class="font-extrabold text-red-400">${s.length}</td></tr></tfoot>`:'';
  return`<div class="card overflow-hidden"><table class="data-table others-table"><thead><tr><th>#</th><th>Floor Name</th><th>Reason</th><th>Mobile</th><th>Attached Report</th><th>Date</th><th>Time</th><th>Employee</th></tr></thead><tbody>${s.map((d,i)=>{let reasonText=d.reason||'';if(reasonText.toLowerCase().startsWith('other:'))reasonText=reasonText.substring(6).trim();const cIdx=reasonText.toLowerCase().indexOf('| comment:');if(cIdx!==-1)reasonText=reasonText.substring(0,cIdx).trim();return `<tr><td class="text-center text-white" style="font-weight:600;background:#dc2626;">${i+1}</td><td><span class="others-floor-cell">${d.floor||'-'}</span></td><td class="others-reason-cell">${reasonText||'-'}</td><td class="others-mobile-cell">${d.mobile||'-'}</td><td class="text-center">${d.image?`<img src="${d.image}" class="w-12 h-12 rounded-lg object-cover cursor-pointer" style="border:1px solid #dc2626;" onclick="window.open('${d.image}','_blank')">`:'<span class="text-[var(--text-dim)]">-</span>'}</td><td>${d.date}</td><td>${d.time}</td><td>${d.employee||'-'}</td></tr>`;}).join('')||'<tr><td colspan="8" class="text-center p-8">No data</td></tr>'}</tbody>${totalRow}</table></div>`;
}

function rEntrySourceSummary(e, x){
  // v3.6: Combined Way of Source Summary — merges entry wayOfSource + exit purchaseSource + exit returnWayOfEntry
  // One count per source name, whether from entry or exit
  const counts = {};
  const addCount = (name) => { if (name && name.trim()) { counts[name] = (counts[name] || 0) + 1; } };
  // Entry wayOfSource
  e.forEach(i => addCount(i.wayOfSource));
  // Exit purchaseSource (Purchase type)
  x.filter(i => i.type === 'Purchase').forEach(i => addCount(i.purchaseSource));
  // Exit returnWayOfEntry (Return type)
  x.filter(i => i.type === 'Return').forEach(i => addCount(i.returnWayOfEntry));
  // Sort by count desc
  const sorted = Object.entries(counts).sort((a, b) => b[1] - a[1]);
  const total = sorted.reduce((s, [, c]) => s + c, 0);
  const rows = sorted.map(([name, c]) => `<tr><td class="font-semibold">${escapeHtml(name)}</td><td style="text-align:right;font-weight:700;color:#7dd3fc;">${c}</td></tr>`).join('');
  return `<div class="card overflow-hidden mb-6"><div class="p-4 border-b border-[var(--border)] flex items-center justify-between"><h3 class="font-display font-bold text-lg">Way of Source Summary</h3><span class="text-xs text-[var(--text-muted)]">Combined Entry + Exit sources</span></div><div class="overflow-x-auto"><table class="data-table"><thead><tr><th>Source</th><th style="text-align:right;background:rgba(14,165,233,0.15);color:#7dd3fc;">Count</th></tr></thead><tbody>${rows || '<tr><td colspan="2" style="text-align:center;padding:2rem;">No data</td></tr>'}</tbody>${sorted.length > 0 ? `<tfoot><tr><td class="font-extrabold">TOTAL</td><td style="text-align:right;font-weight:800;color:#38bdf8;background:rgba(14,165,233,0.1);">${total}</td></tr></tfoot>` : ''}</table></div></div>`;
}

function rNotifications(e,x){const all=[...e.map(d=>({...d,kind:'Entry'})),...x.map(d=>({...d,kind:'Exit'}))];all.sort((a,b)=>b.timestamp-a.timestamp);const pl=all.filter(l=>l.kind==='Exit'&&l.type==='Return'&&l.reason&&l.reason.toLowerCase().startsWith('other'));const nl=all.filter(l=>!(l.kind==='Exit'&&l.type==='Return'&&l.reason&&l.reason.toLowerCase().startsWith('other')));const gh=(l)=>{let ic='',bg='',tc='',lb='';if(l.kind==='Entry'){ic='fa-person';bg='bg-sky-500/15';tc='text-sky-400';lb=l.category+(l.wayOfSource?' - '+l.wayOfSource:'');}else{if(l.type==='Purchase'){ic='fa-bag-shopping';bg='bg-emerald-500/15';tc='text-emerald-400';lb='Purchase';}else{ic='fa-rotate-left';bg='bg-red-500/15';tc='text-red-400';lb=`Return - ${l.reason||'N/A'}`;}}return`<div class="p-3 rounded-xl bg-[var(--bg)] border border-[var(--border)] flex items-center gap-3"><div class="w-10 h-10 rounded-lg ${bg} flex items-center justify-center"><i class="fas ${ic} ${tc}"></i></div><div class="flex-1"><div class="font-bold text-sm">${l.floor||'-'}</div><div class="text-xs text-[var(--text-muted)]">${lb}</div></div><div class="text-xs text-[var(--text-muted)]">${l.date} ${l.time}</div></div>`;};return`<div class="grid lg:grid-cols-2 gap-6"><div><h3 class="font-display font-extrabold text-lg mb-4 text-red-400">Priority</h3><div class="card p-4 max-h-[60vh] overflow-y-auto space-y-2">${pl.map(gh).join('')||'<div class="text-center p-8">None</div>'}</div></div><div><h3 class="font-display font-extrabold text-lg mb-4 text-[var(--text-muted)]">All Activity</h3><div class="card p-4 max-h-[60vh] overflow-y-auto space-y-2">${nl.map(gh).join('')||'<div class="text-center p-8">None</div>'}</div></div></div>`;}

function rCompanySettings(){const s=state.settings;return`<div class="card p-6 max-w-xl mx-auto"><h3 class="font-display font-extrabold text-lg mb-4">Company Branding</h3><div class="space-y-4"><div><label class="text-xs font-bold text-[var(--text-muted)] uppercase mb-2 block">Company Name</label><input type="text" id="company-name-input" class="input-field" value="${s.companyName||''}"></div><div><label class="text-xs font-bold text-[var(--text-muted)] uppercase mb-2 block">Login Tagline <span class="text-amber-400 normal-case">(shown on login screen)</span></label><textarea id="company-tagline-input" class="input-field" rows="5" placeholder="Enter marketing tagline shown on login screen..." style="resize:vertical;font-family:inherit;">${(s.tagline||'').replace(/</g,'&lt;')}</textarea><p class="text-[10px] text-[var(--text-muted)] mt-1">Last line is shown bold. Use Enter for line breaks. Leave empty to hide tagline.</p></div><div><label class="text-xs font-bold text-[var(--text-muted)] uppercase mb-2 block">Font</label><select id="company-font-input" class="input-field"><option value="'Bricolage Grotesque', sans-serif" ${s.companyFont==="'Bricolage Grotesque', sans-serif"?'selected':''}>Bricolage</option><option value="'Poppins', sans-serif" ${s.companyFont==="'Poppins', sans-serif"?'selected':''}>Poppins</option><option value="'Montserrat', sans-serif" ${s.companyFont==="'Montserrat', sans-serif"?'selected':''}>Montserrat</option><option value="'Playfair Display', serif" ${s.companyFont==="'Playfair Display', serif"?'selected':''}>Playfair</option><option value="'Oswald', sans-serif" ${s.companyFont==="'Oswald', sans-serif"?'selected':''}>Oswald</option></select></div><div><label class="text-xs font-bold text-[var(--text-muted)] uppercase mb-2 block">Logo</label><div class="flex items-center gap-4"><div class="w-20 h-20 rounded-xl bg-[var(--bg)] border border-[var(--border)] flex items-center justify-center overflow-hidden">${s.logo?`<img src="${s.logo}" class="w-full h-full object-cover">`:`<i class="fas fa-image text-[var(--text-muted)] text-xl"></i>`}</div><input type="file" accept="image/*" id="company-logo-input" class="input-field" onchange="handleLogoUpload(this)"></div></div><button onclick="saveCompanySettings()" class="w-full py-3 rounded-xl bg-gradient-to-r from-pink-500 to-rose-600 text-white font-bold transition-all">Save Branding</button></div></div>`;}
function handleLogoUpload(input){const f=input.files[0];if(!f)return;const r=new FileReader();r.onload=(e)=>{const img=new Image();img.onload=async()=>{const c=document.createElement('canvas'),ctx=c.getContext('2d');let w=img.width,h=img.height;if(w>h&&w>400){h*=400/w;w=400;}else if(h>400){w*=400/h;h=400;}c.width=w;c.height=h;ctx.drawImage(img,0,0,w,h);state.settings.logo=c.toDataURL('image/jpeg',0.8);try{await saveSettingsBackend();applyBrandUI();renderCurrentReport();showToast('Logo saved','success');}catch(err){}};img.src=e.target.result;};r.readAsDataURL(f);}
async function saveCompanySettings(){state.settings.companyName=document.getElementById('company-name-input').value.trim()||'Customer-System';state.settings.companyFont=document.getElementById('company-font-input').value;const tagInput=document.getElementById('company-tagline-input');if(tagInput)state.settings.tagline=tagInput.value;try{await saveSettingsBackend();applyBrandUI();showToast('Saved! Company branding updated everywhere','success');}catch(e){showToast('Save failed: '+e.message,'error');}}

function rSystemSettings(){const s=state.settings;const nc=['#ec4899','#10b981','#0ea5e9','#f59e0b','#ef4444','#8b5cf6','#ffffff','#000000'];const ab=s.autoBackup||{enabled:true,time:"02:00",retentionDays:10};const bl=s.backupLocation||"backups";return`<div class="card p-6 max-w-xl mx-auto"><h3 class="font-display font-extrabold text-lg mb-4">System &amp; UI Settings</h3><div class="space-y-6"><div><label class="text-xs font-bold text-[var(--text-muted)] uppercase mb-2 block">Primary Color</label><div class="flex flex-wrap gap-3 mb-4">${nc.map(c=>`<div onclick="applyThemeColor('${c}')" class="color-swatch ${s.primaryColor===c?'active':''}" style="background:${c};box-shadow:0 0 10px ${c};"></div>`).join('')}</div><input type="color" id="sys-primary-color" value="${s.primaryColor}" class="input-field h-12 cursor-pointer w-full mb-2" onchange="applyThemeColor(this.value)"></div><div class="grid grid-cols-2 gap-4"><div><label class="text-xs font-bold text-[var(--text-muted)] uppercase mb-2 block">Entry Color</label><input type="color" id="sys-entry-color" value="${s.entryColor}" class="input-field h-12 cursor-pointer w-full" onchange="applyEntryExitColors()"></div><div><label class="text-xs font-bold text-[var(--text-muted)] uppercase mb-2 block">Exit Color</label><input type="color" id="sys-exit-color" value="${s.exitColor}" class="input-field h-12 cursor-pointer w-full" onchange="applyEntryExitColors()"></div></div><div class="p-4 rounded-xl bg-[var(--bg)] border border-[var(--border)]"><h4 class="font-bold text-sm mb-3 text-cyan-400">Interface Settings</h4><div class="space-y-3"><div class="flex items-center justify-between"><div><div class="font-bold text-sm">Enable Icons</div><div class="text-xs text-[var(--text-muted)]">Show icons in menus and buttons</div></div><label class="toggle toggle-cyan"><input type="checkbox" id="sys-enable-icons" ${s.enableIcons?'checked':''}><span class="slider-track"></span></label></div><div class="flex items-center justify-between"><div><div class="font-bold text-sm">New UI Mode</div><div class="text-xs text-[var(--text-muted)]">Modern, polished &amp; professional UI styling</div></div><label class="toggle toggle-pink"><input type="checkbox" id="sys-enable-new-ui" ${s.enableNewUI!==false?'checked':''}><span class="slider-track"></span></label></div></div></div><div class="p-4 rounded-xl bg-[var(--bg)] border border-[var(--border)]"><h4 class="font-bold text-sm mb-3 text-cyan-400">Sound Settings</h4><div class="space-y-3"><div class="flex items-center justify-between"><div><div class="font-bold text-sm">Entry Alert Sound (per option)</div><div class="text-xs text-[var(--text-muted)]">Unique sound per Single/Couple/Family</div></div><label class="toggle toggle-cyan"><input type="checkbox" id="sys-entry-sound" ${s.enableEntrySound?'checked':''}><span class="slider-track"></span></label></div><div class="flex items-center justify-between"><div><div class="font-bold text-sm">Exit Alert Sound (per option)</div><div class="text-xs text-[var(--text-muted)]">Unique sound per Purchase/Return</div></div><label class="toggle toggle-cyan"><input type="checkbox" id="sys-exit-sound" ${s.enableExitSound?'checked':''}><span class="slider-track"></span></label></div></div></div><div class="p-4 rounded-xl bg-[var(--bg)] border border-[var(--border)]"><h4 class="font-bold text-sm mb-3 text-purple-400">Auto Backup</h4><div class="flex items-center justify-between mb-3"><div><div class="font-bold text-sm">Enable Auto Backup</div><div class="text-xs text-[var(--text-muted)]">Automatically save backups on schedule</div></div><label class="toggle toggle-purple"><input type="checkbox" id="auto-backup-enabled" ${ab.enabled?'checked':''}><span class="slider-track"></span></label></div><div class="grid grid-cols-2 gap-4"><div><label class="text-xs font-bold text-[var(--text-muted)] uppercase mb-2 block">Daily Backup Time</label><input type="time" id="auto-backup-time" class="input-field w-full" value="${ab.time||"02:00"}"></div><div><label class="text-xs font-bold text-[var(--text-muted)] uppercase mb-2 block">Retention (days)</label><input type="number" id="auto-backup-retention" class="input-field w-full" value="${ab.retentionDays||10}" min="1"></div></div><label class="text-xs font-bold text-[var(--text-muted)] uppercase mb-2 block mt-4">Location</label><input type="text" id="auto-backup-location" class="input-field w-full" value="${bl}"><p class="text-[10px] text-[var(--text-muted)] mt-2">Path: ${bl}/autobackup/DD-MM-YYYY/backup_HHmmss.json</p><p class="text-[10px] text-cyan-400 mt-1">⏰ Runs daily at ${ab.time||"02:00"} (server-side timer)</p><p class="text-[10px] text-amber-400 mt-1">⚠ Backups older than ${ab.retentionDays||10} days are auto-deleted</p></div><button onclick="saveSystemSettings()" class="w-full py-3 rounded-xl bg-gradient-to-r from-pink-500 to-rose-600 text-white font-bold transition-all">Save System Settings</button></div></div>`;}

function rFeatureSettings(){const s=state.settings;return`<div class="card p-6 max-w-2xl mx-auto"><h3 class="font-display font-extrabold text-lg mb-4">Feature Settings</h3><div class="space-y-6"><div class="p-4 rounded-xl bg-[var(--bg)] border border-[var(--border)]"><h4 class="font-bold text-sm mb-3 text-cyan-400">Floor Features</h4><div class="space-y-3"><div class="flex items-center justify-between"><div><div class="font-bold text-sm">Employee Name + Shift</div><div class="text-xs text-[var(--text-muted)]">Show in floor login</div></div><label class="toggle toggle-cyan"><input type="checkbox" id="feat-emp-name" ${s.enableEmployeeName?'checked':''}><span class="slider-track"></span></label></div><div class="flex items-center justify-between"><div><div class="font-bold text-sm">Admin to Floor Voice Call</div><div class="text-xs text-[var(--text-muted)]">Auto-connect call popup</div></div><label class="toggle toggle-cyan"><input type="checkbox" id="feat-admin-call" ${s.enableAdminCall?'checked':''}><span class="slider-track"></span></label></div><div class="flex items-center justify-between"><div><div class="font-bold text-sm">Way of Source (Entry)</div><div class="text-xs text-[var(--text-muted)]">Ask "How did they find us?" during entry. Disable to skip source selection.</div></div><label class="toggle toggle-cyan"><input type="checkbox" id="feat-way-of-source" ${s.enableWayOfSource!==false?'checked':''} onchange="const sec=document.getElementById('way-of-source-editor-section');if(sec)sec.style.display=this.checked?'block':'none';if(this.checked)setTimeout(()=>renderSourcesEditor(),50);"><span class="slider-track"></span></label></div><div class="flex items-center justify-between"><div><div class="font-bold text-sm">Enable Purchase Source</div><div class="text-xs text-[var(--text-muted)]">Show a 4th step (source picker) when customer makes a purchase</div></div><label class="toggle toggle-amber"><input type="checkbox" id="feat-purchase-source" ${s.enablePurchaseSource?'checked':''} onchange="const sec=document.getElementById('purchase-source-editor-section');if(sec)sec.style.display=this.checked?'block':'none';if(this.checked)setTimeout(()=>renderPurchaseSourcesEditor(),50);"><span class="slider-track"></span></label></div><div class="flex items-center justify-between"><div><div class="font-bold text-sm">Enable Return Way of Entry</div><div class="text-xs text-[var(--text-muted)]">Ask "When did they visit?" after selecting a return reason</div></div><label class="toggle toggle-amber"><input type="checkbox" id="feat-return-way-of-entry" ${s.enableReturnWayOfEntry?'checked':''} onchange="const sec=document.getElementById('return-way-editor-section');if(sec)sec.style.display=this.checked?'block':'none';if(this.checked)setTimeout(()=>renderReturnWayEntriesEditor(),50);"><span class="slider-track"></span></label></div></div></div><div id="way-of-source-editor-section" class="p-4 rounded-xl bg-[var(--bg)] border border-[var(--border)]" style="display:${s.enableWayOfSource!==false?'block':'none'}"><h4 class="font-bold text-sm mb-3 text-sky-400">Way of Source Editor (Entry)</h4><p class="text-xs text-[var(--text-muted)] mb-3">Edit source names, set icon, enable custom text input per source, and toggle visibility. Disabled sources are hidden from the entry page. These appear after selecting Single/Couple/Family. <strong class="text-sky-400">Changes auto-save</strong> — add, edit, delete, or toggle and the report/dashboard update instantly.</p><div id="sources-editor" class="space-y-2 mb-3"></div><div class="flex gap-2"><input type="text" id="new-source-name" class="input-field flex-1" placeholder="New source name"><button onclick="addWayOfSource()" class="btn-secondary px-4"><i class="fas fa-plus"></i></button></div></div><div class="p-4 rounded-xl bg-[var(--bg)] border border-[var(--border)]"><h4 class="font-bold text-sm mb-3 text-red-400">Return Reasons Editor (Exit)</h4><p class="text-xs text-[var(--text-muted)] mb-3">Edit reason names, set icon, enable/disable Reason, Image, and Mobile per reason.</p><div id="reasons-editor" class="space-y-2 mb-3"></div><div class="flex gap-2"><input type="text" id="new-reason-name" class="input-field flex-1" placeholder="New reason name"><button onclick="addReturnReason()" class="btn-secondary px-4"><i class="fas fa-plus"></i></button></div></div><div id="purchase-source-editor-section" class="p-4 rounded-xl bg-[var(--bg)] border border-[var(--border)]" style="display:${s.enablePurchaseSource?'block':'none'}"><h4 class="font-bold text-sm mb-3 text-amber-400">Purchase Sources Editor (Exit)</h4><p class="text-xs text-[var(--text-muted)] mb-3">Edit purchase source names, set icon, enable custom text input per source, and toggle visibility. These appear as a 4th step when a customer makes a purchase. <strong class="text-amber-400">Changes auto-save</strong>.</p><div id="purchase-sources-editor" class="space-y-2 mb-3"></div><div class="flex gap-2"><input type="text" id="new-purchase-source-name" class="input-field flex-1" placeholder="New purchase source"><button onclick="addPurchaseSource()" class="btn-secondary px-4"><i class="fas fa-plus"></i></button></div></div><div id="return-way-editor-section" class="p-4 rounded-xl bg-[var(--bg)] border border-[var(--border)]" style="display:${s.enableReturnWayOfEntry?'block':'none'}"><h4 class="font-bold text-sm mb-3 text-amber-400">Return Way of Entry Editor (Exit)</h4><p class="text-xs text-[var(--text-muted)] mb-3">Edit "way of entry" options shown when a customer returns. Set icon, enable custom text input per entry, and toggle visibility. <strong class="text-amber-400">Changes auto-save</strong>.</p><div id="return-way-entries-editor" class="space-y-2 mb-3"></div><div class="flex gap-2"><input type="text" id="new-return-way-name" class="input-field flex-1" placeholder="New return way of entry"><button onclick="addReturnWayEntry()" class="btn-secondary px-4"><i class="fas fa-plus"></i></button></div></div><button onclick="saveFeatureSettings()" class="w-full py-3 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-bold transition-all">Save Feature Settings</button></div></div>`;}

function rAccessControl(){
  const excluded = ['access-control', 'company-settings', 'system-settings', 'feature-settings'];
  const items = REPORTS_CONFIG.filter(r => !excluded.includes(r.id));
  let checkboxes = items.map(r => `<label class="flex items-center gap-2 text-sm cursor-pointer p-2 rounded-lg hover:bg-[var(--surface-hover)]"><input type="checkbox" class="w-4 h-4 accent-sky-500" ${state.settings.dashboardAccess.includes(r.id)?'checked':''} onchange="toggleDashAccess('${r.id}', this.checked)"><span>${r.title}</span></label>`).join('');
  return `<div class="card p-6 max-w-2xl mx-auto"><h3 class="font-display font-extrabold text-lg mb-4">Dashboard User Access Control</h3><p class="text-xs text-[var(--text-muted)] mb-4">Select which reports the Dashboard User can access. Changes apply instantly.</p><div class="grid grid-cols-1 md:grid-cols-2 gap-2 p-4 rounded-xl bg-[var(--bg)] border border-[var(--border)]">${checkboxes}</div><button onclick="saveAccessControl()" class="w-full mt-4 py-3 rounded-xl bg-gradient-to-r from-sky-500 to-blue-600 text-white font-bold transition-all">Save Access Settings</button></div>`;
}
function toggleDashAccess(id, checked){if(!state.settings.dashboardAccess) state.settings.dashboardAccess = ['dashboard'];if(checked){if(!state.settings.dashboardAccess.includes(id)) state.settings.dashboardAccess.push(id);}else{state.settings.dashboardAccess = state.settings.dashboardAccess.filter(r => r !== id);if(state.settings.dashboardAccess.length === 0) state.settings.dashboardAccess = ['dashboard'];}}
async function saveAccessControl(){try{await saveSettingsBackend();showToast('Access Control Saved!', 'success');if(state.isDashboardUser) renderDashSidebar();}catch(e){}}

// --- ICON PICKER FUNCTIONS ---
// Categorized icon library - News, Person, System, Social, Web, Human, Warnings, Calculation, Other
const ICON_LIBRARY = [
  // News
  {c:'fa-newspaper',n:'Newspaper',cat:'News'},{c:'fa-bullhorn',n:'Bullhorn',cat:'News'},{c:'fa-tower-broadcast',n:'Broadcast',cat:'News'},{c:'fa-tower-cell',n:'Cell Tower',cat:'News'},
  {c:'fa-microphone',n:'Microphone',cat:'News'},{c:'fa-microphone-lines',n:'Mic Lines',cat:'News'},{c:'fa-podcast',n:'Podcast',cat:'News'},{c:'fa-rss',n:'RSS Feed',cat:'News'},
  {c:'fa-tv',n:'TV',cat:'News'},{c:'fa-photo-film',n:'Photo Film',cat:'News'},{c:'fa-camera',n:'Camera',cat:'News'},{c:'fa-camera-retro',n:'Camera Retro',cat:'News'},
  {c:'fa-video',n:'Video',cat:'News'},{c:'fa-film',n:'Film',cat:'News'},{c:'fa-clapperboard',n:'Clapperboard',cat:'News'},{c:'fa-megaphone',n:'Megaphone',cat:'News'},
  {c:'fa-magnet',n:'Magnet',cat:'News'},{c:'fa-eye',n:'Eye',cat:'News'},
  // Person
  {c:'fa-user',n:'User',cat:'Person'},{c:'fa-user-tie',n:'Businessman',cat:'Person'},{c:'fa-user-graduate',n:'Graduate',cat:'Person'},{c:'fa-user-secret',n:'Agent',cat:'Person'},
  {c:'fa-user-ninja',n:'Ninja',cat:'Person'},{c:'fa-user-astronaut',n:'Astronaut',cat:'Person'},{c:'fa-user-shield',n:'User Shield',cat:'Person'},{c:'fa-user-gear',n:'User Gear',cat:'Person'},
  {c:'fa-user-pen',n:'User Pen',cat:'Person'},{c:'fa-user-check',n:'User Check',cat:'Person'},{c:'fa-user-plus',n:'User Add',cat:'Person'},{c:'fa-user-minus',n:'User Remove',cat:'Person'},
  {c:'fa-user-xmark',n:'User X',cat:'Person'},{c:'fa-user-slash',n:'User Slash',cat:'Person'},{c:'fa-user-group',n:'User Group',cat:'Person'},{c:'fa-users',n:'Users',cat:'Person'},
  {c:'fa-users-line',n:'Users Line',cat:'Person'},{c:'fa-users-gear',n:'Users Gear',cat:'Person'},{c:'fa-people-group',n:'People Group',cat:'Person'},{c:'fa-people-line',n:'People Line',cat:'Person'},
  {c:'fa-people-arrows',n:'People Arrows',cat:'Person'},{c:'fa-person',n:'Person',cat:'Person'},{c:'fa-person-walking',n:'Walking',cat:'Person'},{c:'fa-person-running',n:'Running',cat:'Person'},
  {c:'fa-person-dress',n:'Woman',cat:'Person'},{c:'fa-person-cane',n:'Elder',cat:'Person'},{c:'fa-child',n:'Child',cat:'Person'},{c:'fa-baby',n:'Baby',cat:'Person'},
  {c:'fa-id-card',n:'ID Card',cat:'Person'},{c:'fa-id-badge',n:'ID Badge',cat:'Person'},{c:'fa-fingerprint',n:'Fingerprint',cat:'Person'},{c:'fa-handshake',n:'Handshake',cat:'Person'},
  // System
  {c:'fa-gear',n:'Gear',cat:'System'},{c:'fa-gears',n:'Gears',cat:'System'},{c:'fa-sliders',n:'Sliders',cat:'System'},{c:'fa-server',n:'Server',cat:'System'},
  {c:'fa-database',n:'Database',cat:'System'},{c:'fa-hard-drive',n:'Hard Drive',cat:'System'},{c:'fa-microchip',n:'Microchip',cat:'System'},{c:'fa-desktop',n:'Desktop',cat:'System'},
  {c:'fa-laptop',n:'Laptop',cat:'System'},{c:'fa-mobile',n:'Mobile',cat:'System'},{c:'fa-mobile-screen',n:'Phone Screen',cat:'System'},{c:'fa-keyboard',n:'Keyboard',cat:'System'},
  {c:'fa-mouse',n:'Mouse',cat:'System'},{c:'fa-print',n:'Printer',cat:'System'},{c:'fa-cube',n:'Cube',cat:'System'},{c:'fa-cubes',n:'Cubes',cat:'System'},
  {c:'fa-shield',n:'Shield',cat:'System'},{c:'fa-shield-halved',n:'Shield Half',cat:'System'},{c:'fa-lock',n:'Lock',cat:'System'},{c:'fa-lock-open',n:'Lock Open',cat:'System'},
  {c:'fa-key',n:'Key',cat:'System'},{c:'fa-cloud',n:'Cloud',cat:'System'},{c:'fa-cloud-arrow-up',n:'Cloud Up',cat:'System'},{c:'fa-cloud-arrow-down',n:'Cloud Down',cat:'System'},
  {c:'fa-plug',n:'Plug',cat:'System'},{c:'fa-power-off',n:'Power Off',cat:'System'},{c:'fa-toggle-on',n:'Toggle On',cat:'System'},{c:'fa-toggle-off',n:'Toggle Off',cat:'System'},
  {c:'fa-wrench',n:'Wrench',cat:'System'},{c:'fa-screwdriver-wrench',n:'Tools',cat:'System'},{c:'fa-hammer',n:'Hammer',cat:'System'},{c:'fa-sd-card',n:'SD Card',cat:'System'},
  {c:'fa-thumbtack',n:'Pin',cat:'System'},{c:'fa-cog',n:'Cog',cat:'System'},
  // Social
  {c:'fa-share-nodes',n:'Share',cat:'Social'},{c:'fa-share',n:'Share Alt',cat:'Social'},{c:'fa-share-from-square',n:'Share Square',cat:'Social'},{c:'fa-thumbs-up',n:'Like',cat:'Social'},
  {c:'fa-thumbs-down',n:'Dislike',cat:'Social'},{c:'fa-heart',n:'Heart',cat:'Social'},{c:'fa-comment',n:'Comment',cat:'Social'},{c:'fa-comments',n:'Comments',cat:'Social'},
  {c:'fa-message',n:'Message',cat:'Social'},{c:'fa-envelope',n:'Email',cat:'Social'},{c:'fa-paper-plane',n:'Send',cat:'Social'},{c:'fa-at',n:'@ At',cat:'Social'},
  {c:'fa-hashtag',n:'Hashtag',cat:'Social'},{c:'fa-link',n:'Link',cat:'Social'},{c:'fa-link-slash',n:'Link Off',cat:'Social'},{c:'fa-wifi',n:'WiFi',cat:'Social'},
  {c:'fa-signal',n:'Signal',cat:'Social'},{c:'fa-bell',n:'Bell',cat:'Social'},{c:'fa-bell-concierge',n:'Bell Concierge',cat:'Social'},{c:'fa-retweet',n:'Retweet',cat:'Social'},
  {c:'fa-reply',n:'Reply',cat:'Social'},{c:'fa-reply-all',n:'Reply All',cat:'Social'},{c:'fa-square-x-twitter',n:'X Twitter',cat:'Social'},{c:'fa-square-facebook',n:'Facebook',cat:'Social'},
  {c:'fa-square-instagram',n:'Instagram',cat:'Social'},{c:'fa-square-youtube',n:'YouTube',cat:'Social'},{c:'fa-square-whatsapp',n:'WhatsApp',cat:'Social'},{c:'fa-square-snapchat',n:'Snapchat',cat:'Social'},
  {c:'fa-linkedin',n:'LinkedIn',cat:'Social'},{c:'fa-square-linkedin',n:'LinkedIn Sq',cat:'Social'},{c:'fa-square-pinterest',n:'Pinterest',cat:'Social'},{c:'fa-square-reddit',n:'Reddit',cat:'Social'},
  {c:'fa-tiktok',n:'TikTok',cat:'Social'},{c:'fa-telegram',n:'Telegram',cat:'Social'},{c:'fa-discord',n:'Discord',cat:'Social'},{c:'fa-square-tumblr',n:'Tumblr',cat:'Social'},
  // Web
  {c:'fa-globe',n:'Globe',cat:'Web'},{c:'fa-network-wired',n:'Network',cat:'Web'},{c:'fa-sitemap',n:'Sitemap',cat:'Web'},{c:'fa-window-maximize',n:'Window Max',cat:'Web'},
  {c:'fa-window-minimize',n:'Window Min',cat:'Web'},{c:'fa-window-restore',n:'Window Restore',cat:'Web'},{c:'fa-folder',n:'Folder',cat:'Web'},{c:'fa-folder-open',n:'Folder Open',cat:'Web'},
  {c:'fa-folder-tree',n:'Folder Tree',cat:'Web'},{c:'fa-file',n:'File',cat:'Web'},{c:'fa-file-lines',n:'File Lines',cat:'Web'},{c:'fa-file-code',n:'File Code',cat:'Web'},
  {c:'fa-file-image',n:'File Image',cat:'Web'},{c:'fa-file-pdf',n:'File PDF',cat:'Web'},{c:'fa-file-zipper',n:'File Zip',cat:'Web'},{c:'fa-magnifying-glass',n:'Search',cat:'Web'},
  {c:'fa-magnifying-glass-chart',n:'Search Chart',cat:'Web'},{c:'fa-magnifying-glass-dollar',n:'Search Money',cat:'Web'},{c:'fa-magnifying-glass-location',n:'Search Location',cat:'Web'},{c:'fa-bookmark',n:'Bookmark',cat:'Web'},
  {c:'fa-history',n:'History',cat:'Web'},{c:'fa-compass',n:'Compass',cat:'Web'},{c:'fa-map',n:'Map',cat:'Web'},{c:'fa-map-location-dot',n:'Map Pin',cat:'Web'},
  {c:'fa-location-dot',n:'Pin',cat:'Web'},{c:'fa-location-crosshairs',n:'Crosshairs',cat:'Web'},{c:'fa-route',n:'Route',cat:'Web'},{c:'fa-anchor',n:'Anchor',cat:'Web'},
  {c:'fa-book',n:'Book',cat:'Web'},{c:'fa-book-open',n:'Book Open',cat:'Web'},{c:'fa-book-bookmark',n:'Book Mark',cat:'Web'},{c:'fa-satellite',n:'Satellite',cat:'Web'},
  {c:'fa-satellite-dish',n:'Satellite Dish',cat:'Web'},{c:'fa-broadcast-tower',n:'Broadcast Tower',cat:'Web'},{c:'fa-rss',n:'RSS',cat:'Web'},
  // Human / Body
  {c:'fa-hand',n:'Hand',cat:'Human'},{c:'fa-hand-back-fist',n:'Fist',cat:'Human'},{c:'fa-hand-fist',n:'Power',cat:'Human'},{c:'fa-hands',n:'Hands',cat:'Human'},
  {c:'fa-hands-bubbles',n:'Wash',cat:'Human'},{c:'fa-hands-clapping',n:'Clap',cat:'Human'},{c:'fa-hands-praying',n:'Pray',cat:'Human'},{c:'fa-hand-holding',n:'Hold',cat:'Human'},
  {c:'fa-hand-holding-heart',n:'Hold Heart',cat:'Human'},{c:'fa-hand-holding-medical',n:'Medical Hand',cat:'Human'},{c:'fa-hand-holding-dollar',n:'Hold Money',cat:'Human'},{c:'fa-hand-point-up',n:'Point Up',cat:'Human'},
  {c:'fa-hand-point-right',n:'Point Right',cat:'Human'},{c:'fa-head-side-cough',n:'Cough',cat:'Human'},{c:'fa-head-side-mask',n:'Masked',cat:'Human'},{c:'fa-brain',n:'Brain',cat:'Human'},
  {c:'fa-heart-pulse',n:'Heart Pulse',cat:'Human'},{c:'fa-eye-low-vision',n:'Low Vision',cat:'Human'},{c:'fa-ear',n:'Ear',cat:'Human'},{c:'fa-ear-listen',n:'Listen',cat:'Human'},
  {c:'fa-tooth',n:'Tooth',cat:'Human'},{c:'fa-bone',n:'Bone',cat:'Human'},{c:'fa-headset',n:'Headset',cat:'Human'},{c:'fa-mask-face',n:'Face Mask',cat:'Human'},
  // Warnings
  {c:'fa-triangle-exclamation',n:'Warning',cat:'Warnings'},{c:'fa-circle-exclamation',n:'Error',cat:'Warnings'},{c:'fa-bolt',n:'Bolt',cat:'Warnings'},{c:'fa-bolt-lightning',n:'Lightning',cat:'Warnings'},
  {c:'fa-fire',n:'Fire',cat:'Warnings'},{c:'fa-fire-flame-curved',n:'Flame',cat:'Warnings'},{c:'fa-fire-flame-simple',n:'Flame Simple',cat:'Warnings'},{c:'fa-radiation',n:'Radiation',cat:'Warnings'},
  {c:'fa-biohazard',n:'Biohazard',cat:'Warnings'},{c:'fa-skull',n:'Skull',cat:'Warnings'},{c:'fa-skull-crossbones',n:'Skull Cross',cat:'Warnings'},{c:'fa-virus',n:'Virus',cat:'Warnings'},
  {c:'fa-virus-covid',n:'COVID',cat:'Warnings'},{c:'fa-ban',n:'Ban',cat:'Warnings'},{c:'fa-stop',n:'Stop',cat:'Warnings'},{c:'fa-bomb',n:'Bomb',cat:'Warnings'},
  {c:'fa-explosion',n:'Explosion',cat:'Warnings'},{c:'fa-cloud-bolt',n:'Storm',cat:'Warnings'},{c:'fa-tornado',n:'Tornado',cat:'Warnings'},{c:'fa-volcano',n:'Volcano',cat:'Warnings'},
  {c:'fa-flood',n:'Flood',cat:'Warnings'},{c:'fa-snowflake',n:'Snowflake',cat:'Warnings'},{c:'fa-temperature-high',n:'Hot',cat:'Warnings'},{c:'fa-temperature-low',n:'Cold',cat:'Warnings'},
  {c:'fa-thermometer',n:'Thermometer',cat:'Warnings'},{c:'fa-mask',n:'Mask',cat:'Warnings'},{c:'fa-circle-radiation',n:'Radiation C',cat:'Warnings'},{c:'fa-do-not-enter',n:'No Entry',cat:'Warnings'},
  // Calculation
  {c:'fa-calculator',n:'Calculator',cat:'Calculation'},{c:'fa-square-root-variable',n:'Square Root',cat:'Calculation'},{c:'fa-percent',n:'Percent',cat:'Calculation'},{c:'fa-divide',n:'Divide',cat:'Calculation'},
  {c:'fa-equals',n:'Equals',cat:'Calculation'},{c:'fa-plus',n:'Plus',cat:'Calculation'},{c:'fa-minus',n:'Minus',cat:'Calculation'},{c:'fa-xmark',n:'X Mark',cat:'Calculation'},
  {c:'fa-infinity',n:'Infinity',cat:'Calculation'},{c:'fa-money-bill',n:'Money',cat:'Calculation'},{c:'fa-money-bill-wave',n:'Bill Wave',cat:'Calculation'},{c:'fa-money-bill-1',n:'Bill 1',cat:'Calculation'},
  {c:'fa-coins',n:'Coins',cat:'Calculation'},{c:'fa-sack-dollar',n:'Sack Dollar',cat:'Calculation'},{c:'fa-hand-holding-dollar',n:'Hold Money',cat:'Calculation'},{c:'fa-cash-register',n:'Cash Register',cat:'Calculation'},
  {c:'fa-receipt',n:'Receipt',cat:'Calculation'},{c:'fa-file-invoice',n:'Invoice',cat:'Calculation'},{c:'fa-file-invoice-dollar',n:'Invoice $',cat:'Calculation'},{c:'fa-scale-balanced',n:'Balance',cat:'Calculation'},
  {c:'fa-chart-line',n:'Line Chart',cat:'Calculation'},{c:'fa-chart-column',n:'Bar Chart',cat:'Calculation'},{c:'fa-chart-pie',n:'Pie Chart',cat:'Calculation'},{c:'fa-chart-area',n:'Area Chart',cat:'Calculation'},
  {c:'fa-chart-simple',n:'Simple Chart',cat:'Calculation'},{c:'fa-chart-gantt',n:'Gantt',cat:'Calculation'},{c:'fa-table',n:'Table',cat:'Calculation'},{c:'fa-list',n:'List',cat:'Calculation'},
  {c:'fa-list-ol',n:'Numbered',cat:'Calculation'},{c:'fa-list-ul',n:'Bullets',cat:'Calculation'},{c:'fa-abacus',n:'Abacus',cat:'Calculation'},{c:'fa-diagram-project',n:'Diagram',cat:'Calculation'},
  {c:'fa-piggy-bank',n:'Piggy Bank',cat:'Calculation'},{c:'fa-credit-card',n:'Card',cat:'Calculation'},{c:'fa-money-check',n:'Money Check',cat:'Calculation'},{c:'fa-stamp',n:'Stamp',cat:'Calculation'},
  // Other / General
  {c:'fa-tag',n:'Tag',cat:'Other'},{c:'fa-tags',n:'Tags',cat:'Other'},{c:'fa-ellipsis',n:'Ellipsis',cat:'Other'},{c:'fa-circle',n:'Circle',cat:'Other'},
  {c:'fa-square',n:'Square',cat:'Other'},{c:'fa-star',n:'Star',cat:'Other'},{c:'fa-check',n:'Check',cat:'Other'},{c:'fa-check-double',n:'Double Check',cat:'Other'},
  {c:'fa-circle-info',n:'Info',cat:'Other'},{c:'fa-circle-question',n:'Question',cat:'Other'},{c:'fa-circle-check',n:'Success',cat:'Other'},{c:'fa-circle-xmark',n:'Fail',cat:'Other'},
  {c:'fa-flag',n:'Flag',cat:'Other'},{c:'fa-flag-checkered',n:'Race Flag',cat:'Other'},{c:'fa-store',n:'Store',cat:'Other'},{c:'fa-shop',n:'Shop',cat:'Other'},
  {c:'fa-cart-shopping',n:'Cart',cat:'Other'},{c:'fa-bag-shopping',n:'Bag',cat:'Other'},{c:'fa-gift',n:'Gift',cat:'Other'},{c:'fa-clock',n:'Clock',cat:'Other'},
  {c:'fa-calendar',n:'Calendar',cat:'Other'},{c:'fa-pen-ruler',n:'Design',cat:'Other'},{c:'fa-pen',n:'Pen',cat:'Other'},{c:'fa-pencil',n:'Pencil',cat:'Other'},
  {c:'fa-trash',n:'Trash',cat:'Other'},{c:'fa-box',n:'Box',cat:'Other'},{c:'fa-box-open',n:'Box Open',cat:'Other'},{c:'fa-truck',n:'Truck',cat:'Other'}
];
function buildIconPickerHTML(pickerId, currentIcon, onSelectFn, itemIndex) {
  const cur = currentIcon || 'fa-tag';
  const curName = (ICON_LIBRARY.find(o => o.c === cur) || {n: cur}).n;
  const cats = ['all','News','Person','System','Social','Web','Human','Warnings','Calculation','Other'];
  const catBtns = cats.map(cat => `<button type="button" data-cat="${cat}" class="icon-cat-tab px-2 py-1 text-[10px] rounded-md font-semibold transition-colors ${cat==='all'?'bg-[var(--primary)] text-white':'bg-[var(--surface)] text-[var(--text-muted)] hover:bg-[var(--surface-hover)]'}" onclick="event.stopPropagation(); setIconPickerCategory('${pickerId}', '${cat}')">${cat==='all'?'All':cat}</button>`).join(' ');
  const iconBtns = ICON_LIBRARY.map(opt => `<button type="button" title="${opt.n}" data-cat="${opt.cat}" data-name="${opt.n.toLowerCase()}" data-class="${opt.c}" class="icon-btn flex items-center justify-center w-9 h-9 rounded-md hover:bg-[var(--surface-hover)] text-base ${cur===opt.c?'bg-[var(--surface-hover)] text-[var(--primary)] ring-1 ring-[var(--primary)]':'text-[var(--text-muted)]'}" onclick="event.stopPropagation(); ${onSelectFn}(${itemIndex}, '${opt.c}')"><i class="fas ${opt.c}"></i></button>`).join('');
  return `<div id="${pickerId}" class="absolute z-50 mt-2 hidden p-3 bg-[var(--bg-elevated)] border border-[var(--border-light)] rounded-xl shadow-2xl w-80" data-active-cat="all">
    <div class="flex items-center gap-2 mb-2">
      <input type="text" placeholder="Search icons..." class="flex-1 bg-[var(--bg)] border border-[var(--border-light)] rounded-lg px-2.5 py-1.5 text-xs text-white placeholder:text-[var(--text-muted)] focus:outline-none focus:border-[var(--primary)]" oninput="filterIconPicker('${pickerId}', this.value)" onclick="event.stopPropagation()" value="">
      <span class="icon-count text-[10px] text-[var(--text-muted)] whitespace-nowrap">${ICON_LIBRARY.length} icons</span>
    </div>
    <div class="flex flex-wrap gap-1 mb-2">${catBtns}</div>
    <div class="icon-grid grid grid-cols-8 gap-1 max-h-64 overflow-y-auto p-1 bg-[var(--bg)] rounded-lg">${iconBtns}</div>
    <div class="mt-2 pt-2 border-t border-[var(--border-light)] flex items-center justify-between text-[10px]">
      <span class="text-[var(--text-muted)]">Selected:</span>
      <span class="icon-current-label text-[var(--primary)] font-semibold flex items-center gap-1"><i class="fas ${cur}"></i> ${curName}</span>
    </div>
  </div>`;
}
function filterIconPicker(pickerId, query) {
  const picker = document.getElementById(pickerId); if (!picker) return;
  query = (query || '').toLowerCase().trim();
  const activeCat = picker.getAttribute('data-active-cat') || 'all';
  let visible = 0;
  picker.querySelectorAll('.icon-btn').forEach(btn => {
    const cat = btn.getAttribute('data-cat');
    const name = btn.getAttribute('data-name') || '';
    const catOk = activeCat === 'all' || cat === activeCat;
    const nameOk = !query || name.includes(query);
    const show = catOk && nameOk;
    btn.style.display = show ? '' : 'none';
    if (show) visible++;
  });
  const countEl = picker.querySelector('.icon-count');
  if (countEl) countEl.textContent = visible + ' / ' + ICON_LIBRARY.length + ' icons';
}
function setIconPickerCategory(pickerId, cat) {
  const picker = document.getElementById(pickerId); if (!picker) return;
  picker.setAttribute('data-active-cat', cat);
  picker.querySelectorAll('.icon-cat-tab').forEach(tab => {
    const isOn = tab.getAttribute('data-cat') === cat;
    tab.className = 'icon-cat-tab px-2 py-1 text-[10px] rounded-md font-semibold transition-colors ' + (isOn ? 'bg-[var(--primary)] text-white' : 'bg-[var(--surface)] text-[var(--text-muted)] hover:bg-[var(--surface-hover)]');
  });
  const searchInput = picker.querySelector('input[type="text"]');
  filterIconPicker(pickerId, searchInput ? searchInput.value : '');
}
function toggleIconPicker(id) {
  document.querySelectorAll('[id^="icon-picker-"]').forEach(p => { if(p.id !== id) p.classList.add('hidden'); });
  const el = document.getElementById(id);
  if (el) {
    el.classList.toggle('hidden');
    if (!el.classList.contains('hidden')) {
      // Reset search + category on each open
      el.setAttribute('data-active-cat', 'all');
      el.querySelectorAll('.icon-cat-tab').forEach(tab => {
        const isOn = tab.getAttribute('data-cat') === 'all';
        tab.className = 'icon-cat-tab px-2 py-1 text-[10px] rounded-md font-semibold transition-colors ' + (isOn ? 'bg-[var(--primary)] text-white' : 'bg-[var(--surface)] text-[var(--text-muted)] hover:bg-[var(--surface-hover)]');
      });
      const searchInput = el.querySelector('input[type="text"]');
      if (searchInput) searchInput.value = '';
      filterIconPicker(id, '');
      // Scroll selected icon into view
      const sel = el.querySelector('.icon-btn.bg-\\[var\\(--surface-hover\\)\\]') || el.querySelector('.icon-btn[style*="ring"]');
      if (sel) sel.scrollIntoView({block: 'center'});
    }
  }
}
function selectReasonIcon(index, iconClass) {if(state.settings.returnReasons) state.settings.returnReasons[index].icon = iconClass;const el = document.getElementById('icon-picker-reason-'+index);if(el) el.classList.add('hidden');renderReasonsEditor();saveSettingsBackend().then(()=>showToast('Icon saved','success')).catch(()=>{});}
function selectSourceIcon(index, iconClass) {if(state.settings.wayOfSources) state.settings.wayOfSources[index].icon = iconClass;const el = document.getElementById('icon-picker-source-'+index);if(el) el.classList.add('hidden');renderSourcesEditor();saveSettingsBackend().then(()=>showToast('Icon saved','success')).catch(()=>{});}

function renderSourcesEditor(){
  const ed=document.getElementById('sources-editor');if(!ed)return;
  const r=state.settings.wayOfSources||[];
  ed.innerHTML=r.map((src,i)=>`<div class="p-3 rounded-lg bg-[var(--bg)] border border-[var(--border)] ${src.enabled===false?'opacity-60':''}"><div class="flex items-center gap-2 mb-2"><div class="relative icon-picker-container"><button type="button" class="w-11 h-11 flex items-center justify-center rounded-lg bg-[var(--surface)] border border-[var(--border-light)] text-sky-400 text-lg" onclick="event.stopPropagation(); toggleIconPicker('icon-picker-source-${i}')"><i class="fas ${src.icon||'fa-tag'}"></i></button>${buildIconPickerHTML('icon-picker-source-'+i, src.icon, 'selectSourceIcon', i)}</div><input type="text" value="${src.name}" class="input-field flex-1" style="padding:0.5rem;" onchange="updateWayOfSource(${i},'name',this.value)"><button onclick="removeWayOfSource(${i})" class="text-red-400 hover:bg-red-500/10 p-2 rounded-lg"><i class="fas fa-xmark"></i></button></div><div class="flex items-center gap-4 pl-2 flex-wrap"><label class="flex items-center gap-2 text-xs cursor-pointer"><span class="text-emerald-400 font-semibold">Enabled</span><label class="toggle toggle-emerald"><input type="checkbox" ${src.enabled!==false?'checked':''} onchange="updateWayOfSource(${i},'enabled',this.checked)"><span class="slider-track"></span></label></label><label class="flex items-center gap-2 text-xs cursor-pointer"><span class="text-sky-400 font-semibold">Custom Text Input</span><label class="toggle toggle-sky"><input type="checkbox" ${src.customEnabled?'checked':''} onchange="updateWayOfSource(${i},'customEnabled',this.checked)"><span class="slider-track"></span></label></label></div></div>`).join('');
}
function addWayOfSource(){const n=document.getElementById('new-source-name').value.trim();if(!n)return showToast('Enter source name','error');if(!state.settings.wayOfSources)state.settings.wayOfSources=[];state.settings.wayOfSources.push({name:n,icon:'fa-tag',customEnabled:false,enabled:true});document.getElementById('new-source-name').value='';renderSourcesEditor();saveSettingsBackend().then(()=>{showToast('Source added & saved','success');refreshFeatureEditorsOrReport();if(state.isDashboardUser)renderDashReport();}).catch(()=>{});}
function updateWayOfSource(i,field,v){if(state.settings.wayOfSources)state.settings.wayOfSources[i][field]=v;saveSettingsBackend().then(()=>{showToast('Source updated & saved','success');refreshFeatureEditorsOrReport();if(state.isDashboardUser)renderDashReport();}).catch(()=>{});}
function removeWayOfSource(i){if(!state.settings.wayOfSources)return;if(!confirm('Delete this way of source? Existing entries will keep their recorded source name.'))return;state.settings.wayOfSources.splice(i,1);renderSourcesEditor();saveSettingsBackend().then(()=>{showToast('Source deleted & saved','success');refreshFeatureEditorsOrReport();if(state.isDashboardUser)renderDashReport();}).catch(()=>{});}
// Smart refresh: when on feature-settings screen, re-render the editors in place (avoids wiping them to empty);
// otherwise re-render the current report so dashboards/reports stay in sync.
function refreshFeatureEditorsOrReport(){
  if(state.currentReport==='feature-settings'){
    // Re-render editors in place - do NOT call renderCurrentReport() because it would wipe editors
    setTimeout(()=>{renderSourcesEditor();renderReasonsEditor();renderPurchaseSourcesEditor();},50);
  } else {
    renderCurrentReport();
  }
}

function renderReasonsEditor(){
  const ed=document.getElementById('reasons-editor');if(!ed)return;
  const r=state.settings.returnReasons||[];
  ed.innerHTML=r.map((reason,i)=>`<div class="p-3 rounded-lg bg-[var(--bg)] border border-[var(--border)]"><div class="flex items-center gap-2 mb-2"><div class="relative icon-picker-container"><button type="button" class="w-11 h-11 flex items-center justify-center rounded-lg bg-[var(--surface)] border border-[var(--border-light)] text-red-400 text-lg" onclick="event.stopPropagation(); toggleIconPicker('icon-picker-reason-${i}')"><i class="fas ${reason.icon||'fa-tag'}"></i></button>${buildIconPickerHTML('icon-picker-reason-'+i, reason.icon, 'selectReasonIcon', i)}</div><input type="text" value="${reason.name}" class="input-field flex-1" style="padding:0.5rem;" onchange="updateReturnReason(${i},'name',this.value)"><button onclick="removeReturnReason(${i})" class="text-red-400 hover:bg-red-500/10 p-2 rounded-lg"><i class="fas fa-xmark"></i></button></div><div class="flex items-center gap-4 pl-2 flex-wrap"><label class="flex items-center gap-2 text-xs cursor-pointer"><span class="text-cyan-400 font-semibold">Reason</span><label class="toggle toggle-cyan"><input type="checkbox" ${reason.commentEnabled?'checked':''} onchange="updateReturnReason(${i},'commentEnabled',this.checked)"><span class="slider-track"></span></label></label><label class="flex items-center gap-2 text-xs cursor-pointer"><span class="text-emerald-400 font-semibold">Image</span><label class="toggle toggle-emerald"><input type="checkbox" ${reason.imageEnabled?'checked':''} onchange="updateReturnReason(${i},'imageEnabled',this.checked)"><span class="slider-track"></span></label></label><label class="flex items-center gap-2 text-xs cursor-pointer"><span class="text-pink-400 font-semibold">Mobile</span><label class="toggle toggle-pink"><input type="checkbox" ${reason.mobileEnabled?'checked':''} onchange="updateReturnReason(${i},'mobileEnabled',this.checked)"><span class="slider-track"></span></label></label><label class="flex items-center gap-2 text-xs cursor-pointer"><span class="text-red-400 font-semibold">Req</span><label class="toggle toggle-red"><input type="checkbox" ${reason.mobileRequired?'checked':''} onchange="updateReturnReason(${i},'mobileRequired',this.checked)"><span class="slider-track"></span></label></label></div></div>`).join('');
}
function addReturnReason(){const n=document.getElementById('new-reason-name').value.trim();if(!n)return showToast('Enter reason name','error');if(!state.settings.returnReasons)state.settings.returnReasons=[];state.settings.returnReasons.push({name:n,commentEnabled:false,imageEnabled:false,mobileEnabled:false,mobileRequired:false,icon:'fa-tag'});document.getElementById('new-reason-name').value='';renderReasonsEditor();}
function updateReturnReason(i,field,v){if(state.settings.returnReasons)state.settings.returnReasons[i][field]=v;}
function removeReturnReason(i){if(state.settings.returnReasons)state.settings.returnReasons.splice(i,1);renderReasonsEditor();}
// === v3.1 PURCHASE SOURCE EDITOR ===
function renderPurchaseSourcesEditor(){
  const ed=document.getElementById('purchase-sources-editor');if(!ed)return;
  const r=state.settings.purchaseSources||[];
  ed.innerHTML=r.map((src,i)=>`<div class="p-3 rounded-lg bg-[var(--bg)] border border-[var(--border)] ${src.enabled===false?'opacity-60':''}"><div class="flex items-center gap-2 mb-2"><div class="relative icon-picker-container"><button type="button" class="w-11 h-11 flex items-center justify-center rounded-lg bg-[var(--surface)] border border-[var(--border-light)] text-amber-400 text-lg" onclick="event.stopPropagation(); toggleIconPicker('icon-picker-purchase-source-${i}')"><i class="fas ${src.icon||'fa-tag'}"></i></button>${buildIconPickerHTML('icon-picker-purchase-source-'+i, src.icon, 'selectPurchaseSourceIcon', i)}</div><input type="text" value="${src.name}" class="input-field flex-1" style="padding:0.5rem;" onchange="updatePurchaseSource(${i},'name',this.value)"><button onclick="removePurchaseSource(${i})" class="text-red-400 hover:bg-red-500/10 p-2 rounded-lg"><i class="fas fa-xmark"></i></button></div><div class="flex items-center gap-4 pl-2 flex-wrap"><label class="flex items-center gap-2 text-xs cursor-pointer"><span class="text-emerald-400 font-semibold">Enabled</span><label class="toggle toggle-emerald"><input type="checkbox" ${src.enabled!==false?'checked':''} onchange="updatePurchaseSource(${i},'enabled',this.checked)"><span class="slider-track"></span></label></label><label class="flex items-center gap-2 text-xs cursor-pointer"><span class="text-amber-400 font-semibold">Custom Text Input</span><label class="toggle toggle-amber"><input type="checkbox" ${src.customEnabled?'checked':''} onchange="updatePurchaseSource(${i},'customEnabled',this.checked)"><span class="slider-track"></span></label></label></div></div>`).join('');
}
function selectPurchaseSourceIcon(index, iconClass){if(state.settings.purchaseSources) state.settings.purchaseSources[index].icon=iconClass;const el=document.getElementById('icon-picker-purchase-source-'+index);if(el) el.classList.add('hidden');renderPurchaseSourcesEditor();saveSettingsBackend().then(()=>showToast('Icon saved','success')).catch(()=>{});}
function addPurchaseSource(){const n=document.getElementById('new-purchase-source-name').value.trim();if(!n)return showToast('Enter purchase source name','error');if(!state.settings.purchaseSources)state.settings.purchaseSources=[];state.settings.purchaseSources.push({name:n,icon:'fa-tag',customEnabled:false,enabled:true});document.getElementById('new-purchase-source-name').value='';renderPurchaseSourcesEditor();saveSettingsBackend().then(()=>{showToast('Purchase source added & saved','success');refreshFeatureEditorsOrReport();}).catch(()=>{});}
function updatePurchaseSource(i,field,v){if(state.settings.purchaseSources)state.settings.purchaseSources[i][field]=v;saveSettingsBackend().then(()=>{showToast('Purchase source updated & saved','success');refreshFeatureEditorsOrReport();}).catch(()=>{});}
function removePurchaseSource(i){if(!state.settings.purchaseSources)return;if(!confirm('Delete this purchase source? Existing exits will keep their recorded source name.'))return;state.settings.purchaseSources.splice(i,1);renderPurchaseSourcesEditor();saveSettingsBackend().then(()=>{showToast('Purchase source deleted & saved','success');refreshFeatureEditorsOrReport();}).catch(()=>{});}
function renderReturnWayEntriesEditor(){
  const ed=document.getElementById('return-way-entries-editor');if(!ed)return;
  const r=state.settings.returnWayOfEntries||[];
  ed.innerHTML=r.map((w,i)=>`<div class="p-3 rounded-lg bg-[var(--bg)] border border-[var(--border)] ${w.enabled===false?'opacity-60':''}"><div class="flex items-center gap-2 mb-2"><div class="relative icon-picker-container"><button type="button" class="w-11 h-11 flex items-center justify-center rounded-lg bg-[var(--surface)] border border-[var(--border-light)] text-amber-400 text-lg" onclick="event.stopPropagation(); toggleIconPicker('icon-picker-return-way-${i}')"><i class="fas ${w.icon||'fa-tag'}"></i></button>${buildIconPickerHTML('icon-picker-return-way-'+i, w.icon, 'selectReturnWayIcon', i)}</div><input type="text" value="${w.name}" class="input-field flex-1" style="padding:0.5rem;" onchange="updateReturnWayEntry(${i},'name',this.value)"><button onclick="removeReturnWayEntry(${i})" class="text-red-400 hover:bg-red-500/10 p-2 rounded-lg"><i class="fas fa-xmark"></i></button></div><div class="flex items-center gap-4 pl-2 flex-wrap"><label class="flex items-center gap-2 text-xs cursor-pointer"><span class="text-emerald-400 font-semibold">Enabled</span><label class="toggle toggle-emerald"><input type="checkbox" ${w.enabled!==false?'checked':''} onchange="updateReturnWayEntry(${i},'enabled',this.checked)"><span class="slider-track"></span></label></label><label class="flex items-center gap-2 text-xs cursor-pointer"><span class="text-amber-400 font-semibold">Custom Text Input</span><label class="toggle toggle-amber"><input type="checkbox" ${w.customEnabled?'checked':''} onchange="updateReturnWayEntry(${i},'customEnabled',this.checked)"><span class="slider-track"></span></label></label></div></div>`).join('');
}
function selectReturnWayIcon(index,iconClass){if(state.settings.returnWayOfEntries)state.settings.returnWayOfEntries[index].icon=iconClass;const el=document.getElementById('icon-picker-return-way-'+index);if(el)el.classList.add('hidden');renderReturnWayEntriesEditor();saveSettingsBackend().then(()=>showToast('Icon saved','success')).catch(()=>{});}
function addReturnWayEntry(){const n=document.getElementById('new-return-way-name').value.trim();if(!n)return showToast('Enter return way of entry name','error');if(!state.settings.returnWayOfEntries)state.settings.returnWayOfEntries=[];state.settings.returnWayOfEntries.push({name:n,icon:'fa-tag',customEnabled:false,enabled:true});document.getElementById('new-return-way-name').value='';renderReturnWayEntriesEditor();saveSettingsBackend().then(()=>{showToast('Return way of entry added & saved','success');refreshFeatureEditorsOrReport();}).catch(()=>{});}
function updateReturnWayEntry(i,field,v){if(state.settings.returnWayOfEntries)state.settings.returnWayOfEntries[i][field]=v;saveSettingsBackend().then(()=>{showToast('Return way of entry updated & saved','success');refreshFeatureEditorsOrReport();}).catch(()=>{});}
function removeReturnWayEntry(i){if(!state.settings.returnWayOfEntries)return;if(!confirm('Delete this return way of entry? Existing exits will keep their recorded value.'))return;state.settings.returnWayOfEntries.splice(i,1);renderReturnWayEntriesEditor();saveSettingsBackend().then(()=>{showToast('Return way of entry deleted & saved','success');refreshFeatureEditorsOrReport();}).catch(()=>{});}
async function saveFeatureSettings(){state.settings.enableEmployeeName=document.getElementById('feat-emp-name').checked;state.settings.enableAdminCall=document.getElementById('feat-admin-call').checked;state.settings.enableWayOfSource=document.getElementById('feat-way-of-source').checked;state.settings.enablePurchaseSource=document.getElementById('feat-purchase-source').checked;state.settings.enableReturnWayOfEntry=document.getElementById('feat-return-way-of-entry').checked;try{await saveSettingsBackend();updateLoginFields();renderReasonFilter();setupCallPolling();refreshFeatureEditorsOrReport();if(state.isDashboardUser)renderDashReport();showToast('Feature Settings Saved!','success');}catch(e){}}
const _openReport=openReport;openReport=function(id){_openReport(id);if(id==='feature-settings')setTimeout(()=>{renderReasonsEditor();renderSourcesEditor();renderPurchaseSourcesEditor();renderReturnWayEntriesEditor();},100);};
function applyThemeColor(c){document.documentElement.style.setProperty('--primary',c);document.documentElement.style.setProperty('--primary-glow',getGlowColor(c));document.getElementById('sys-primary-color').value=c;document.querySelectorAll('.color-swatch').forEach(s=>s.classList.toggle('active',s.style.background.includes(c)||rgbToHex(s.style.backgroundColor)===c));}
function applyEntryExitColors(){const ec=document.getElementById('sys-entry-color').value,xc=document.getElementById('sys-exit-color').value;document.documentElement.style.setProperty('--entry-neon',ec);document.documentElement.style.setProperty('--entry-glow',getGlowColor(ec));document.documentElement.style.setProperty('--exit-neon',xc);document.documentElement.style.setProperty('--exit-glow',getGlowColor(xc));}
function rgbToHex(r){if(!r)return"";const m=r.match(/^rgb\((\d+),\s*(\d+),\s*(\d+)\)$/);return m?"#"+m.slice(1).map(x=>parseInt(x).toString(16).padStart(2,'0')).join(''):r;}
async function saveSystemSettings(){state.settings.primaryColor=document.getElementById('sys-primary-color').value;state.settings.entryColor=document.getElementById('sys-entry-color').value;state.settings.exitColor=document.getElementById('sys-exit-color').value;state.settings.enableIcons=document.getElementById('sys-enable-icons').checked;state.settings.enableNewUI=document.getElementById('sys-enable-new-ui').checked;state.settings.enableEntrySound=document.getElementById('sys-entry-sound').checked;state.settings.enableExitSound=document.getElementById('sys-exit-sound').checked;state.settings.autoBackup.enabled=document.getElementById('auto-backup-enabled').checked;state.settings.autoBackup.time=document.getElementById('auto-backup-time').value||"02:00";state.settings.autoBackup.retentionDays=parseInt(document.getElementById('auto-backup-retention').value)||10;state.settings.backupLocation=document.getElementById('auto-backup-location').value.trim()||"backups";try{await saveSettingsBackend();applyTheme();applyBrandUI();setupAutoBackup();renderSidebarNav();showToast('Saved!','success');}catch(e){}}

function rLiveMessages(){const m=state.messages.slice().reverse();const sh=`<div class="card p-6 mb-6"><div class="flex items-center justify-between mb-4"><h3 class="font-display font-extrabold text-lg">Send Message</h3><div class="flex gap-2">${m.length>0?`<button onclick="clearLiveMessages()" class="py-2 px-4 rounded-lg bg-red-500 hover:bg-red-600 text-white font-bold text-sm transition-all"><i class="fas fa-trash mr-2"></i>Clear All</button>`:''}</div></div><div class="space-y-4"><textarea id="msg-text" class="input-field" rows="3" placeholder="Type message..."></textarea><div class="flex items-center gap-4 flex-wrap"><select id="msg-target" class="input-field" style="max-width:200px;"><option value="All">All Floors</option>${state.floors.map(f=>`<option value="${f.name}">${f.name}</option>`).join('')}</select><label class="flex items-center gap-2 text-sm cursor-pointer"><span>Reply Required</span><label class="toggle toggle-pink"><input type="checkbox" id="msg-reply-req"><span class="slider-track"></span></label></label><button onclick="sendLiveMessage()" class="ml-auto py-2 px-4 rounded-lg bg-pink-500 hover:bg-pink-600 text-white font-bold text-sm"><i class="fas fa-paper-plane mr-2"></i>Send</button></div></div></div>`;const lh=m.map(msg=>`<div class="card p-4 mb-3 border-l-4 border-l-pink-500 relative"><div class="flex justify-between mb-2"><span class="font-bold text-sm">${msg.target}</span><span class="text-xs text-[var(--text-muted)]">${new Date(msg.timestamp).toLocaleString()}</span></div><p class="text-sm mb-2">${msg.text}</p><button onclick="deleteMessage(${msg.id})" class="absolute top-2 right-2 text-red-400 hover:text-red-600 text-sm bg-[var(--surface-hover)] p-1.5 rounded-md transition-all" title="Delete Message"><i class="fas fa-xmark"></i></button>${msg.replies&&msg.replies.length>0?`<div class="mt-3 pt-3 border-t border-[var(--border)] space-y-2">${msg.replies.map(r=>`<div class="text-xs bg-[var(--bg)] p-2 rounded-lg"><strong>${r.floor}:</strong> ${r.text}</div>`).join('')}</div>`:''}</div>`).join('');return sh+`<div><h3 class="font-display font-extrabold text-lg mb-4">History</h3>${lh||'<div class="text-center p-8 text-[var(--text-muted)]">No messages</div>'}</div>`;}
async function sendLiveMessage(){const t=document.getElementById('msg-text').value.trim();if(!t)return showToast('Empty','error');const tg=document.getElementById('msg-target').value;const replyRequired=document.getElementById('msg-reply-req').checked;const m={id:Date.now(),text:t,target:tg,replyRequired:replyRequired,timestamp:Date.now(),replies:[]};await fetch(SERVER_API+'?action=addMessage&data='+encodeURIComponent(JSON.stringify(m))+(state.isAdmin&&_adminPass?'&authPassword='+encodeURIComponent(_adminPass):''));showToast('Sent','success');renderCurrentReport();}
async function clearLiveMessages(){if(!confirm('Clear all chat messages? This cannot be undone.'))return;try{await fetch(SERVER_API+'?action=clearMessages',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:(state.isAdmin&&_adminPass?'authPassword='+encodeURIComponent(_adminPass):'')});state.messages=[];showToast('Chat cleared','success');renderCurrentReport();}catch(e){showToast('Failed to clear','error');}}
async function deleteMessage(id){if(!confirm('Delete this message and its replies?'))return;try{const res=await fetch(SERVER_API+'?action=deleteMessage&msgId='+id+(state.isAdmin&&_adminPass?'&authPassword='+encodeURIComponent(_adminPass):''));const data=await res.json();if(data.error)throw new Error(data.error);showToast('Message deleted','success');renderCurrentReport();}catch(e){showToast('Failed to delete','error');}}
function rCustomLog(x){const s=x.slice().reverse();const totalRow=s.length>0?`<tfoot><tr><td colspan="8" class="text-right font-extrabold">TOTAL LOGS</td><td class="font-extrabold">${s.length}</td></tr></tfoot>`:'';return`<div class="card overflow-hidden"><table class="data-table"><thead><tr><th>#</th><th>Floor</th><th>Type</th><th>Reason</th><th>Mobile</th><th>Image</th><th>Date</th><th>Time</th><th>Employee</th></tr></thead><tbody>${s.map((d,i)=>`<tr><td>${i+1}</td><td>${d.floor||'-'}</td><td>${d.type==='Purchase'?'<span class="badge badge-emerald">Purchase</span>':'<span class="badge badge-red">Return</span>'}</td><td>${d.reason||'-'}</td><td style="color:#f472b6;font-weight:600;">${d.mobile||'-'}</td><td>${d.image?`<img src="${d.image}" class="w-10 h-10 rounded object-cover cursor-pointer" onclick="window.open('${d.image}','_blank')">`:'-'}</td><td>${d.date}</td><td>${d.time}</td><td>${d.employee||'-'}</td></tr>`).join('')||'<tr><td colspan="9" class="text-center p-8">No data</td></tr>'}</tbody>${totalRow}</table></div>`;}

// --- PDF / EXPORT MATRIX GENERATION ---
function getReportMatrix(id,e,x){
  const floors=getActiveFloors();
  const reasons=state.settings.returnReasons.map(r=>r.name);
  const sources=state.settings.wayOfSources.map(s=>s.name);
  if(id==='floor-consolidated'){
    const reasons=state.settings.returnReasons.map(r=>r.name);
    const nR = reasons.length;
    // Two-tier header structure (with Total Returns column added):
    // Row 1: Floor Name | Entries (colspan 3) | Total Entries | Purchase | Returns (colspan nR) | Total Returns | Total Exits
    // Row 2: Single | Couple | Family | [reason names]
    const headerRow1 = ['__ROWSPAN2__FLOOR NAME', 'Entries'];
    for (let k = 1; k < 3; k++) headerRow1.push('__COLSPAN__');
    headerRow1.push('__ROWSPAN2__TOTAL ENTRIES', '__ROWSPAN2__PURCHASE', 'Returns');
    for (let k = 1; k < nR; k++) headerRow1.push('__COLSPAN__');
    headerRow1.push('__ROWSPAN2__TOTAL RETURNS', '__ROWSPAN2__TOTAL EXITS');
    // Row 2 sub-headers
    const headerRow2 = ['', 'Single', 'Couple', 'Family', '', '', ...reasons, '', ''];
    let main = [headerRow1, headerRow2];
    floors.forEach(f => {
      const s = e.filter(i => i.floor === f.name && i.category === 'Single').length;
      const c = e.filter(i => i.floor === f.name && i.category === 'Couple').length;
      const fm = e.filter(i => i.floor === f.name && i.category === 'Family').length;
      const p = x.filter(i => i.floor === f.name && i.type === 'Purchase').length;
      const rd = reasons.map(rs => x.filter(i => i.floor === f.name && i.type === 'Return' && i.reason && i.reason.includes(rs)).length);
      const totalE = s + c + fm;
      const totalR = rd.reduce((a,b)=>a+b,0);
      const totalX = p + totalR;
      main.push([f.name, s, c, fm, totalE, p, ...rd, totalR, totalX]);
    });
    if (floors.length > 0) {
      const totS = e.filter(i => floors.some(f => f.name === i.floor) && i.category === 'Single').length;
      const totC = e.filter(i => floors.some(f => f.name === i.floor) && i.category === 'Couple').length;
      const totFm = e.filter(i => floors.some(f => f.name === i.floor) && i.category === 'Family').length;
      const totP = x.filter(i => floors.some(f => f.name === i.floor) && i.type === 'Purchase').length;
      const totRd = reasons.map(rs => x.filter(i => floors.some(f => f.name === i.floor) && i.type === 'Return' && i.reason && i.reason.includes(rs)).length);
      const totEntryAll = totS + totC + totFm;
      const totReturnAll = totRd.reduce((a,b)=>a+b,0);
      const totExitAll = totP + totReturnAll;
      main.push(['TOTAL', totS, totC, totFm, totEntryAll, totP, ...totRd, totReturnAll, totExitAll]);
    }
    const others = x.filter(i => i.type === 'Return' && i.reason && i.reason.toLowerCase().startsWith('other')).slice().reverse();
    let othersMatrix = [['#','Floor Name','Reason','Mobile','Attached Report','Date','Time','Employee']];
    others.forEach((dd,i) => {
      let reasonText = dd.reason || '';
      if (reasonText.toLowerCase().startsWith('other:')) reasonText = reasonText.substring(6).trim();
      const cIdx = reasonText.toLowerCase().indexOf('| comment:');
      if (cIdx !== -1) reasonText = reasonText.substring(0, cIdx).trim();
      othersMatrix.push([i+1, dd.floor, reasonText, dd.mobile||'-', dd.image?'[Attached]':'-', dd.date, dd.time, dd.employee||'-']);
    });
    // Mark two-tier with header spec for buildPDF
    main.__twoTier = true;
    main.__headerSpec = [
      {rowspan: 2, label: 'FLOOR NAME'},
      {colspan: 3, label: 'Entries'},
      {rowspan: 2, label: 'TOTAL ENTRIES'},
      {rowspan: 2, label: 'PURCHASE'},
      {colspan: nR, label: 'Returns'},
      {rowspan: 2, label: 'TOTAL RETURNS'},
      {rowspan: 2, label: 'TOTAL EXITS'}
    ];

    // Build Way of Source Summary (Category-wise) matrix for PDF export
    // Mirrors buildWayOfSourceSummary() — same source iteration + custom text detail rows
    let wayOfSourceMatrix = null;
    if (state.settings.enableWayOfSource !== false) {
      const srcList = state.settings.wayOfSources || [];
      if (srcList.length > 0) {
        const cats = ['Single', 'Couple', 'Family'];
        const allEntries = e.filter(i => floorsContain(i.floor));
        wayOfSourceMatrix = [['Way of Source', 'Single', 'Couple', 'Family', 'Total Count']];
        let grandTotal = 0;
        // First pass: emit one row per source
        const customTextMap = {}; // { srcName: [{text, count, byCat}] }
        srcList.forEach(src => {
          const srcName = src.name || '';
          const isCustom = src.customEnabled || srcName.toLowerCase().startsWith('other');
          let matching;
          if (isCustom) {
            matching = allEntries.filter(i => {
              if (!i.wayOfSource) return false;
              if (i.wayOfSource === srcName) return true;
              if (srcName.toLowerCase().startsWith('other') && i.wayOfSource.toLowerCase().startsWith('other:')) return true;
              return i.wayOfSource === srcName;
            });
          } else {
            matching = allEntries.filter(i => i.wayOfSource === srcName);
          }
          const perCat = cats.map(cat => matching.filter(i => i.category === cat).length);
          const total = matching.length;
          grandTotal += total;
          wayOfSourceMatrix.push([srcName, perCat[0], perCat[1], perCat[2], total]);
          // Collect custom text detail rows for this source
          if (isCustom) {
            const customEntries = allEntries.filter(i => {
              if (!i.wayOfSource) return false;
              if (srcName.toLowerCase().startsWith('other') && i.wayOfSource.toLowerCase().startsWith('other:')) return true;
              return false;
            });
            const groups = {};
            customEntries.forEach(i => {
              let customText = i.wayOfSource;
              if (customText.toLowerCase().startsWith('other:')) customText = customText.substring(6).trim();
              const pipeIdx = customText.toLowerCase().indexOf('| comment:');
              if (pipeIdx !== -1) customText = customText.substring(0, pipeIdx).trim();
              if (!groups[customText]) groups[customText] = { count: 0, byCat: {Single:0, Couple:0, Family:0} };
              groups[customText].count++;
              if (groups[customText].byCat[i.category] !== undefined) groups[customText].byCat[i.category]++;
            });
            const customTexts = Object.keys(groups).sort((a,b) => groups[b].count - groups[a].count);
            if (customTexts.length > 0) {
              customTextMap[srcName] = customTexts.map(text => ({ text, ...groups[text] }));
            }
          }
        });
        // Second pass: append custom detail rows grouped by parent source (mirrors HTML order)
        Object.keys(customTextMap).forEach(srcName => {
          customTextMap[srcName].forEach(item => {
            wayOfSourceMatrix.push(['  -> ' + item.text, item.byCat.Single, item.byCat.Couple, item.byCat.Family, item.count]);
          });
        });
        // Grand total row
        const totS = allEntries.filter(i => i.category === 'Single').length;
        const totC = allEntries.filter(i => i.category === 'Couple').length;
        const totFm = allEntries.filter(i => i.category === 'Family').length;
        wayOfSourceMatrix.push(['GRAND TOTAL', totS, totC, totFm, grandTotal]);
      }
    }

    return {main, others: othersMatrix, hasOthers: others.length > 0, othersImages: others, wayOfSource: wayOfSourceMatrix};
  }
  if(id==='entry-summary-report'){
    let main=[['Floor','Total Entries','Single','Couple','Family',...sources]];
    floors.forEach(f=>{const sCount=e.filter(i=>i.floor===f.name&&i.category==='Single').length;const cCount=e.filter(i=>i.floor===f.name&&i.category==='Couple').length;const fCount=e.filter(i=>i.floor===f.name&&i.category==='Family').length;const totalEntry=sCount+cCount+fCount;const sd=sources.map(src=>e.filter(i=>i.floor===f.name&&(i.wayOfSource===src||(src.toLowerCase().startsWith('other')&&i.wayOfSource&&i.wayOfSource.toLowerCase().startsWith('other')))).length);main.push([f.name,totalEntry,sCount,cCount,fCount,...sd]);});
    if(floors.length>0){const tS=e.filter(i=>floors.some(f=>f.name===i.floor)&&i.category==='Single').length;const tC=e.filter(i=>floors.some(f=>f.name===i.floor)&&i.category==='Couple').length;const tFm=e.filter(i=>floors.some(f=>f.name===i.floor)&&i.category==='Family').length;const tE=tS+tC+tFm;const tSd=sources.map(src=>e.filter(i=>floors.some(f=>f.name===i.floor)&&(i.wayOfSource===src||(src.toLowerCase().startsWith('other')&&i.wayOfSource&&i.wayOfSource.toLowerCase().startsWith('other')))).length);main.push(['TOTAL',tE,tS,tC,tFm,...tSd]);}
    return main;
  }
  if(id==='entry-source-summary'){
    // v3.6: Combined Way of Source Summary — Source | Count
    const counts={};
    const addC=(n)=>{if(n&&n.trim()){counts[n]=(counts[n]||0)+1;}};
    e.forEach(i=>addC(i.wayOfSource));
    x.filter(i=>i.type==='Purchase').forEach(i=>addC(i.purchaseSource));
    x.filter(i=>i.type==='Return').forEach(i=>addC(i.returnWayOfEntry));
    const sorted=Object.entries(counts).sort((a,b)=>b[1]-a[1]);
    let main=[['Source','Count']];
    sorted.forEach(([name,c])=>main.push([name,c]));
    if(sorted.length>0){const total=sorted.reduce((s,[,c])=>s+c,0);main.push(['TOTAL',total]);}
    return main;
  }
  if(id==='entry-breakdown'){
    const cats=['Single','Couple','Family'];
    const nSrc=sources.length;
    // Two-tier header structure (driven by __headerSpec):
    // Row 1: Floor Name (rowspan 2) | Single (colspan nSrc) | Couple (colspan nSrc) | Family (colspan nSrc)
    // Row 2: [source names] | [source names] | [source names]
    const headerRow1=['__ROWSPAN2__FLOOR NAME'];
    cats.forEach(cat=>{
      headerRow1.push(cat);
      for(let k=1;k<nSrc;k++) headerRow1.push('__COLSPAN__');
    });
    const headerRow2=[''];
    cats.forEach(()=>{sources.forEach(src=>headerRow2.push(src));});
    let main=[headerRow1, headerRow2];
    let grandTotals=new Array(cats.length*nSrc).fill(0);
    let allTotal=0;
    floors.forEach(f=>{
      let row=[f.name];
      cats.forEach((cat,catIdx)=>{
        sources.forEach((src,srcIdx)=>{
          const count=e.filter(i=>i.floor===f.name&&i.category===cat&&(i.wayOfSource===src||(src.toLowerCase().startsWith('other')&&i.wayOfSource&&i.wayOfSource.toLowerCase().startsWith('other')))).length;
          row.push(count);
          grandTotals[catIdx*nSrc+srcIdx]+=count;
          allTotal+=count;
        });
      });
      main.push(row);
    });
    if(floors.length>0){
      let totalRow=['TOTAL'];
      grandTotals.forEach(c=>totalRow.push(c));
      main.push(totalRow);
    }
    // Mark two-tier with header spec for buildPDF
    main.__twoTier=true;
    main.__headerSpec=[
      {rowspan: 2, label: 'FLOOR NAME'},
      ...cats.map(cat => ({colspan: nSrc, label: cat}))
    ];
    return main;
  }
  if(id==='dashboard'||id==='floor-inout'){let d=[['Floor','Total Entries','Total Exits','Current In Store']];floors.forEach(f=>{const fe=e.filter(i=>i.floor===f.name).length,fx=x.filter(i=>i.floor===f.name).length;d.push([f.name,fe,fx,Math.max(0,fe-fx)]);});if(floors.length>0)d.push(['TOTAL',e.length,x.length,Math.max(0,e.length-x.length)]);return d;}
  else if(id==='entry-detailed'){let d=[['#','Floor','Category','Way of Source','Date','Time','Employee']];e.slice().reverse().forEach((dd,i)=>d.push([i+1,dd.floor,dd.category,dd.wayOfSource||'-',dd.date,dd.time,dd.employee||'-']));if(e.length>0)d.push(['TOTAL','','','','','',e.length]);return d;}
  else if(id==='exit-detailed'||id==='custom-log'){let d=[['#','Floor','Type','Reason','Mobile','Date','Time','Employee']];x.slice().reverse().forEach((dd,i)=>d.push([i+1,dd.floor,dd.type,dd.reason||'-',dd.mobile||'-',`${dd.date} ${dd.time}`,dd.employee||'-']));if(x.length>0)d.push(['TOTAL','','','','','','',x.length]);return d;}
  else if(id==='exit-summary'){let d=[['Floor','Purchases','Returns','Total Exits']];floors.forEach(f=>{const p=x.filter(i=>i.floor===f.name&&i.type==='Purchase').length,r=x.filter(i=>i.floor===f.name&&i.type==='Return').length;d.push([f.name,p,r,p+r]);});if(floors.length>0){const totP=x.filter(i=>floors.some(f=>f.name===i.floor)&&i.type==='Purchase').length,totR=x.filter(i=>floors.some(f=>f.name===i.floor)&&i.type==='Return').length;d.push(['TOTAL',totP,totR,totP+totR]);}return d;}
  else if(id==='exit-return'){let d=[['Floor',...reasons,'Total Returns']];floors.forEach(f=>{const rd=reasons.map(rs=>x.filter(i=>i.floor===f.name&&i.reason&&i.reason.includes(rs)).length);const tot=x.filter(i=>i.floor===f.name&&i.type==='Return').length;d.push([f.name,...rd,tot]);});if(floors.length>0){const totRd=reasons.map(rs=>x.filter(i=>floors.some(f=>f.name===i.floor)&&i.reason&&i.reason.includes(rs)).length);const grandTot=x.filter(i=>floors.some(f=>f.name===i.floor)&&i.type==='Return').length;d.push(['TOTAL',...totRd,grandTot]);}return d;}
  else if(id==='exit-others-detailed'){let d=[['#','Floor Name','Reason','Mobile','Attached Report','Date','Time','Employee']];const s=x.filter(i=>i.type==='Return'&&i.reason&&i.reason.toLowerCase().startsWith('other')).slice().reverse();s.forEach((dd,i)=>{let reasonText=dd.reason||'';if(reasonText.toLowerCase().startsWith('other:'))reasonText=reasonText.substring(6).trim();const cIdx=reasonText.toLowerCase().indexOf('| comment:');if(cIdx!==-1)reasonText=reasonText.substring(0,cIdx).trim();d.push([i+1,dd.floor,reasonText,dd.mobile||'-',dd.image?'[Attached]':'-',dd.date,dd.time,dd.employee||'-']);});if(s.length>0)d.push(['TOTAL','','','','','','',s.length]);return d;}
  else if(id==='notifications'){let d=[['Type','Floor','Category/Reason','Mobile','Date','Time','Employee']];const all=[...e.map(dd=>({...dd,kind:'Entry'})),...x.map(dd=>({...dd,kind:'Exit'}))].sort((a,b)=>b.timestamp-a.timestamp);all.forEach(dd=>d.push([dd.kind,dd.floor,dd.kind==='Entry'?dd.category+` (${dd.wayOfSource||'-'})`:`${dd.type} ${dd.reason||''}`,dd.mobile||'-',dd.date,dd.time,dd.employee||'-']));if(all.length>0)d.push(['TOTAL','','','','','',all.length]);return d;}
  return[];
}

function getReportFilterLabel(prefix){const modeEl=document.getElementById(prefix+'filter-mode');const m=modeEl?modeEl.value:'today';let label='';if(m==='today')label='Date: '+getTodayStr();else if(m==='yesterday')label='Date: '+getYesterdayStr();else if(m==='custom'){const dv=document.getElementById(prefix+'filter-date').value;label='Date: '+(dv?formatDate(new Date(dv)):'-');}else if(m==='range'){const dfv=document.getElementById(prefix+'filter-date-from').value;const dtv=document.getElementById(prefix+'filter-date-to').value;label='From: '+(dfv?formatDate(new Date(dfv)):'-')+'   To: '+(dtv?formatDate(new Date(dtv)):'-');}else if(m==='month'){const mo=document.getElementById(prefix+'filter-month').value;label='Month: '+(mo||'-');}else if(m==='all')label='All Time';return label;}
function exportCurrentReport(f){const{entries,exits}=getFilteredData();const c=REPORTS_CONFIG.find(r=>r.id===state.currentReport);const m=getReportMatrix(c.id,entries,exits);const fl=getReportFilterLabel('');if(f==='pdf'){buildPDF(c.title,m,exits,fl);showToast('PDF exported','success');}else if(f==='excel'){buildExcel(c.title,m,fl);showToast('Excel exported','success');}}

function buildPDF(t,matrix,exits,fl){
  const{jsPDF}=window.jspdf;
  let mainMatrix,othersMatrix=null,othersImages=[],wayOfSourceMatrix=null;
  if(matrix&&!Array.isArray(matrix)&&matrix.main){mainMatrix=matrix.main;othersMatrix=matrix.others;othersImages=matrix.othersImages||[];wayOfSourceMatrix=matrix.wayOfSource||null;}else{mainMatrix=matrix;}
  // Detect two-tier header structure (e.g., entry-breakdown, floor-consolidated)
  const isTwoTier = mainMatrix && mainMatrix.__twoTier === true;
  const headerSpec = isTwoTier ? (mainMatrix.__headerSpec || []) : [];
  // Compute per-column role from headerSpec: each entry describes one or more actual columns
  // role: {type:'standalone'|'groupStart'|'groupChild'|'rowspan2', colspan, rowspan, label, groupLabel, groupColor}
  let columnRoles = [];
  headerSpec.forEach(spec => {
    if (spec.rowspan && spec.rowspan >= 2) {
      // Standalone cell spanning 2 rows
      columnRoles.push({type:'rowspan2', rowspan: spec.rowspan, label: spec.label, colorBoost: spec.colorBoost || 0.85});
    } else if (spec.colspan && spec.colspan > 1) {
      // Group: first cell is groupStart (colspan), remaining are groupChild (absorbed)
      columnRoles.push({type:'groupStart', colspan: spec.colspan, label: spec.label, colorBoost: spec.colorBoost || 0.7});
      for (let k = 1; k < spec.colspan; k++) {
        columnRoles.push({type:'groupChild', colorBoost: spec.colorBoost || 0.7});
      }
    } else {
      // Single-cell column (acts as rowspan 1)
      columnRoles.push({type:'standalone', label: spec.label, colorBoost: spec.colorBoost || 1.0});
    }
  });
  const isWide=isTwoTier || (mainMatrix[0]&&mainMatrix[0].length>6);
  const d=new jsPDF({orientation:isWide?'landscape':'portrait',unit:'mm',format:'a4'});
  const pw=d.internal.pageSize.getWidth(),ph=d.internal.pageSize.getHeight();
  const mg=14;
  let hex=state.settings.primaryColor.replace('#','');
  let r=parseInt(hex.substring(0,2),16),g=parseInt(hex.substring(2,4),16),b=parseInt(hex.substring(4,6),16);
  let tx=mg;
  if(state.settings.logo){try{let img=new Image();img.src=state.settings.logo;let mW=18,mH=18,ra=img.width/img.height,lW,lH;if(ra>1){lW=mW;lH=mW/ra;if(lH>mH){lH=mH;lW=mH*ra;}}else{lH=mH;lW=mH*ra;if(lW>mW){lW=mW;lH=mW/ra;}}d.addImage(state.settings.logo,'JPEG',mg,12,lW,lH);tx=mg+lW+5;}catch(e){}}
  d.setFont('helvetica','bold');d.setFontSize(16);d.setTextColor(r,g,b);d.text(state.settings.companyName||'CustomerFlow',tx,18);
  d.setFont('helvetica','normal');d.setFontSize(12);d.setTextColor(80,80,80);d.text(t,tx,24);
  d.setFontSize(8);d.setTextColor(150,150,150);d.text('Generated: '+new Date().toLocaleString(),tx,29);
  let _lineY=32,_finalY=38;
  if(fl){d.setFontSize(9);d.setTextColor(80,80,80);d.text(fl,tx,34);_lineY=37;_finalY=43;}
  d.setDrawColor(r,g,b);d.setLineWidth(0.5);d.line(mg,_lineY,pw-mg,_lineY);
  d.setTextColor(40,40,40);
  let finalY=_finalY;
  // For two-tier: pass BOTH header rows as head; for single-tier: only the first row
  const headRows = isTwoTier ? [mainMatrix[0], mainMatrix[1]] : [mainMatrix[0]];
  const bodyStart = isTwoTier ? 2 : 1;
  const bodyRows = mainMatrix.slice(bodyStart);
  // Clean the header rows: remove our internal markers (__COLSPAN__, __ROWSPAN2__) and replace with empty strings
  const cleanedHead = headRows.map(row => row.map(cell => {
    if (typeof cell === 'string') {
      if (cell === '__COLSPAN__') return '';
      if (cell.startsWith('__ROWSPAN2__')) return cell.substring('__ROWSPAN2__'.length);
    }
    return cell;
  }));
  d.autoTable({
    head:cleanedHead,
    body:bodyRows,
    startY:finalY,
    margin:{left:mg,right:mg,top:10,bottom:20},
    headStyles:{fillColor:[r,g,b],textColor:[255,255,255],halign:'center',valign:'middle',fontStyle:'bold',fontSize:8.5,lineColor:[255,255,255],lineWidth:0.3,cellPadding:2.5},
    bodyStyles:{fontSize:8.5,halign:'center',valign:'middle',textColor:[50,50,50],lineColor:[180,180,180],lineWidth:0.2,cellPadding:2,overflow:'linebreak'},
    alternateRowStyles:{fillColor:[248,248,250]},
    columnStyles:isTwoTier
      ? {0:{cellWidth:65,halign:'left',fontStyle:'bold',overflow:'linebreak',cellPadding:2.5,fontSize:8}}
      : {0:{cellWidth:65,halign:'left',fontStyle:'bold',overflow:'linebreak',cellPadding:2.5,fontSize:8}},
    didParseCell:function(data){
      // Bold + grey background for the TOTAL row (last body row)
      if(bodyRows.length>0 && data.row.index===bodyRows.length-1 && data.section==='body'){
        data.cell.styles.fontStyle='bold';
        data.cell.styles.fillColor=[235,238,245];
        if(data.column.index===0) data.cell.styles.textColor=[r,g,b];
      }
      // Two-tier header colspan/rowspan logic — driven by columnRoles
      if(isTwoTier && data.section==='head'){
        const role = columnRoles[data.column.index] || {type:'standalone'};
        const boost = role.colorBoost || 1.0;
        const baseFill = [Math.round(r*boost), Math.round(g*boost), Math.round(b*boost)];
        if(data.row.index===0){
          // Header row 1
          if(role.type==='rowspan2'){
            // Floor Name or other standalone spanning 2 rows
            data.cell.rowSpan = role.rowspan || 2;
            data.cell.styles.valign='middle';
            data.cell.styles.fillColor = baseFill;
            data.cell.styles.fontSize = (role.label && String(role.label).length > 12) ? 9 : 10;
          } else if(role.type==='groupStart'){
            // Category group label (Single, Couple, Family, Entries, Returns, etc.)
            data.cell.colSpan = role.colspan;
            data.cell.styles.fillColor = baseFill;
            data.cell.styles.fontSize = 10;
          } else if(role.type==='groupChild'){
            // Absorbed by colSpan - hide
            data.cell.styles.fillColor=[255,255,255];
            data.cell.styles.textColor=[255,255,255];
            data.cell.text='';
          } else {
            // Single-cell standalone in row 0 (no rowspan)
            data.cell.styles.fillColor = baseFill;
          }
        }
        if(data.row.index===1){
          // Header row 2 (sub-headers)
          if(role.type==='rowspan2'){
            // Cell under a rowspan2 cell - absorbed, hide
            data.cell.styles.fillColor=[255,255,255];
            data.cell.styles.textColor=[255,255,255];
            data.cell.text='';
          } else {
            // Sub-header cell (source name or reason name) - lighter shade
            data.cell.styles.fillColor=[Math.round(r*0.6),Math.round(g*0.6),Math.round(b*0.6)];
            data.cell.styles.fontSize=7;
            data.cell.styles.fontStyle='normal';
          }
        }
      }
    },
    didDrawPage:function(data){const pc=d.internal.getNumberOfPages();d.setFontSize(7);d.setTextColor(150,150,150);d.text(state.settings.companyName||'CustomerFlow',mg,ph-6);d.text('Page '+data.pageNumber+' of '+pc,pw-25,ph-6);d.setDrawColor(220,220,220);d.setLineWidth(0.3);d.line(mg,ph-9,pw-mg,ph-9);}
  });
  finalY=d.lastAutoTable.finalY+14;
  // Way of Source Summary (Category-wise) — styled to match the main Floor Consolidated table (primaryColor theme)
  if(wayOfSourceMatrix&&wayOfSourceMatrix.length>1){
    if(finalY+40>ph-25){d.addPage();finalY=20;}
    const wosHeadingH=18;
    d.setFillColor(r,g,b); // primaryColor — matches main table heading
    d.rect(mg,finalY-2,pw-2*mg,wosHeadingH,'F');
    d.setFont('helvetica','bold');d.setFontSize(13);d.setTextColor(255,255,255);
    d.text('Way of Source Summary (Category-wise)',mg+8,finalY+5);
    d.setFont('helvetica','normal');d.setFontSize(8);d.setTextColor(255,255,255);
    d.text('Entry count by way of source, broken down by Single/Couple/Family',mg+8,finalY+11);
    finalY+=wosHeadingH+4;
    const wosBody=wayOfSourceMatrix.slice(1);
    d.autoTable({
      head:[wayOfSourceMatrix[0]],
      body:wosBody,
      startY:finalY,
      margin:{left:mg,right:mg,top:8,bottom:20},
      headStyles:{fillColor:[r,g,b],textColor:[255,255,255],halign:'center',valign:'middle',fontStyle:'bold',fontSize:10,lineColor:[255,255,255],lineWidth:0.3,cellPadding:3.5},
      bodyStyles:{fontSize:10,halign:'center',valign:'middle',textColor:[20,20,20],lineColor:[180,180,180],lineWidth:0.2,cellPadding:3,overflow:'linebreak'},
      alternateRowStyles:{fillColor:[248,248,250]},
      columnStyles:{0:{cellWidth:65,halign:'left',fontStyle:'bold',overflow:'linebreak',cellPadding:3,fontSize:8}},
      didParseCell:function(data){
        // Bold + grey fill for the GRAND TOTAL row (last body row) — matches main table TOTAL style
        if(wosBody.length>0 && data.row.index===wosBody.length-1 && data.section==='body'){
          data.cell.styles.fontStyle='bold';
          data.cell.styles.fillColor=[235,238,245];
          if(data.column.index===0) data.cell.styles.textColor=[r,g,b];
        }
        // Custom detail rows (label starts with two spaces and "-> ") — render muted, indented look
        if(data.section==='body' && data.column.index===0){
          const cellVal=String(wosBody[data.row.index][0]||'');
          if(cellVal.indexOf('  -> ')===0){
            data.cell.styles.fontStyle='normal';
            data.cell.styles.textColor=[120,120,120];
          }
        }
      },
      didDrawPage:function(data){const pc=d.internal.getNumberOfPages();d.setFontSize(7);d.setTextColor(150,150,150);d.text(state.settings.companyName||'CustomerFlow',mg,ph-6);d.text('Page '+data.pageNumber+' of '+pc,pw-25,ph-6);d.setDrawColor(220,220,220);d.setLineWidth(0.3);d.line(mg,ph-9,pw-mg,ph-9);}
    });
    finalY=d.lastAutoTable.finalY+12;
  }
  if(othersMatrix&&othersMatrix.length>1){
    if(finalY+40>ph-25){d.addPage();finalY=20;}
    // Heading bar — primaryColor theme to match main Floor Consolidated table
    const headingH=22;
    d.setFillColor(r,g,b); // primaryColor — matches main table heading
    d.rect(mg,finalY-2,pw-2*mg,headingH,'F');
    // Thin accent strip below heading bar for definition (darker shade of primaryColor)
    d.setFillColor(Math.round(r*0.7),Math.round(g*0.7),Math.round(b*0.7));
    d.rect(mg,finalY-2+headingH,pw-2*mg,1.2,'F');
    d.setFont('helvetica','bold');d.setFontSize(14);d.setTextColor(255,255,255);
    d.text('Other Reasons Detailed Report',mg+8,finalY+8);
    d.setFont('helvetica','normal');d.setFontSize(9);d.setTextColor(255,255,255);
    d.text('Floor-wise custom return reasons with comments and attached report',mg+8,finalY+15);
    finalY+=headingH+6;
    const othersBody=othersMatrix.slice(1);
    d.autoTable({
      head:[othersMatrix[0]],
      body:othersBody,
      startY:finalY,
      margin:{left:mg,right:mg,top:8,bottom:20},
      // Header: primaryColor, white text, larger font, white grid lines
      headStyles:{fillColor:[r,g,b],textColor:[255,255,255],halign:'center',valign:'middle',fontStyle:'bold',fontSize:10,lineColor:[255,255,255],lineWidth:0.3,cellPadding:3.5,minCellHeight:9},
      // Body: dark near-black text, light gridlines, larger font, more padding — matches main table
      bodyStyles:{fontSize:10,halign:'left',valign:'middle',textColor:[20,20,20],lineColor:[180,180,180],lineWidth:0.2,cellPadding:3.5,overflow:'linebreak',minCellHeight:8},
      // Same alternate row fill as main table
      alternateRowStyles:{fillColor:[248,248,250]},
      // Reasonable column widths — wider for Floor/Reason/Comment, narrower for #/Time
      columnStyles:{
        0:{cellWidth:12,halign:'center',fontStyle:'bold',textColor:[r,g,b]},
        1:{cellWidth:55,halign:'left',fontStyle:'bold',textColor:[r,g,b],overflow:'linebreak',fontSize:8},
        2:{cellWidth:'auto',overflow:'linebreak'},
        3:{cellWidth:40,overflow:'linebreak'},
        4:{cellWidth:28,halign:'center'},
        5:{cellWidth:24,halign:'center'},
        6:{cellWidth:26,halign:'center'},
        7:{cellWidth:22,halign:'center'},
        8:{cellWidth:28,overflow:'linebreak'}
      },
      didParseCell:function(data){
        // TOTAL row (last body row) — grey fill + primaryColor text in col 0, matches main table TOTAL style
        if(othersBody.length>0 && data.row.index===othersBody.length-1 && data.section==='body'){
          data.cell.styles.fontStyle='bold';
          data.cell.styles.fillColor=[235,238,245];
          if(data.column.index===0) data.cell.styles.textColor=[r,g,b];
        }
      },
      didDrawPage:function(data){const pc=d.internal.getNumberOfPages();d.setFontSize(7);d.setTextColor(150,150,150);d.text(state.settings.companyName||'CustomerFlow',mg,ph-6);d.text('Page '+data.pageNumber+' of '+pc,pw-25,ph-6);d.setDrawColor(220,220,220);d.setLineWidth(0.3);d.line(mg,ph-9,pw-mg,ph-9);}
    });
    finalY=d.lastAutoTable.finalY+12;
  }
  const imgExits=(exits||state.exits).filter(x=>x.image);
  if(imgExits.length>0){if(finalY+25>ph-20){d.addPage();finalY=20;}d.setFont('helvetica','bold');d.setFontSize(11);d.setTextColor(r,g,b);d.text('Attached Images Report:',mg,finalY);finalY+=8;let imgW=40,imgH=30,gap=10;let x=mg;imgExits.forEach((ex,i)=>{if(x+imgW>pw-mg){x=mg;finalY+=imgH+gap+10;}if(finalY+imgH+15>ph-15){d.addPage();finalY=20;x=mg;}try{d.addImage(ex.image,'JPEG',x,finalY,imgW,imgH);d.setFontSize(6);d.setTextColor(100,100,100);d.text((ex.floor+' - '+(ex.reason||'')).substring(0,30),x,finalY+imgH+4);x+=imgW+gap;if(x+imgW>pw-mg){x=mg;finalY+=imgH+gap+10;}}catch(e){}});}
  d.save(t.replace(/\s+/g,'-')+'.pdf');
}

function buildExcel(t,matrix,fl){
  const w=XLSX.utils.book_new();
  let mainMatrix,othersMatrix=null;
  if(matrix&&!Array.isArray(matrix)&&matrix.main){mainMatrix=matrix.main;othersMatrix=matrix.others;}else{mainMatrix=matrix;}
  const data=[[state.settings.companyName||'CustomerFlow'],[t],['Generated: '+new Date().toLocaleString()],fl?[fl]:[],[],...mainMatrix];
  const s=XLSX.utils.aoa_to_sheet(data);
  const cw=mainMatrix[0].map((_,i)=>{let mx=0;mainMatrix.forEach(r=>{if(r[i]&&String(r[i]).length>mx)mx=String(r[i]).length;});return{wch:mx+2};});
  s['!cols']=cw;
  XLSX.utils.book_append_sheet(w,s,'Report');
  if(othersMatrix&&othersMatrix.length>1){const od=[[state.settings.companyName||'CustomerFlow'],['Other Reasons Detailed Report'],['Generated: '+new Date().toLocaleString()],fl?[fl]:[],[],...othersMatrix];const os=XLSX.utils.aoa_to_sheet(od);const ocw=othersMatrix[0].map((_,i)=>{let mx=0;othersMatrix.forEach(r=>{if(r[i]&&String(r[i]).length>mx)mx=String(r[i]).length;});return{wch:mx+2};});os['!cols']=ocw;XLSX.utils.book_append_sheet(w,os,'Others Report');}
  XLSX.writeFile(w,t.replace(/\s+/g,'-')+'.xlsx');
}

function showToast(m,t='info'){const c=document.getElementById('toast-container');const el=document.createElement('div');const col={success:'border-emerald-500/40',error:'border-red-500/40',info:'border-pink-500/40'};const ic={success:'text-emerald-400',error:'text-red-400',info:'text-pink-400'};const i={success:'fa-circle-check',error:'fa-bell',info:'fa-info-circle'};el.className='toast '+col[t]+' border';el.innerHTML='<i class="fas '+i[t]+' '+ic[t]+'"></i><span class="text-sm font-semibold">'+m+'</span>';c.appendChild(el);setTimeout(()=>{el.style.animation='slide-out 0.3s ease forwards';setTimeout(()=>el.remove(),300);},3500);}

// === Cross-IP session fix ===
// When a client on a different IP/host accesses this JSP (cross-origin), browsers default fetch()
// to NOT send cookies (JSESSIONID). This breaks session-based auth for ALL fetch calls except the
// single one (getData) that already had credentials:'same-origin'. Result: "Unauthorized" errors
// when Dashboard User / Admin / Floor tries to save settings, add entries, send messages, etc.
// This global fetch override ensures EVERY fetch() in the app sends credentials (cookies) along,
// so the session JSESSIONID is always included — fixing cross-IP auth once and for all.
(function(){
  const _origFetch=window.fetch;
  window.fetch=function(input,init){
    if(!init)init={};
    if(!init.credentials)init.credentials='same-origin';
    return _origFetch.call(this,input,init);
  };
})();
initSystem();
</script>
</body>
</html>