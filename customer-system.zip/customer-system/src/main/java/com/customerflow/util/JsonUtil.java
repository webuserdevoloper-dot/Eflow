package com.customerflow.util;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonArray;

/**
 * Central JSON helper built on Gson.
 * Keeps all JSON (de)serialisation in one place so the rest of the
 * codebase stays clean and free of manual string concatenation.
 */
public final class JsonUtil {

    private static final Gson GSON = new GsonBuilder().disableHtmlEscaping().create();

    private JsonUtil() {}

    public static Gson gson() { return GSON; }

    public static String toJson(Object o) {
        return GSON.toJson(o);
    }

    public static JsonObject parseObject(String json) {
        return JsonParser.parseString(json).getAsJsonObject();
    }

    public static JsonArray parseArray(String json) {
        return JsonParser.parseString(json).getAsJsonArray();
    }

    public static JsonElement parse(String json) {
        return JsonParser.parseString(json);
    }

    /** Safely read a string member, returning "" when missing. */
    public static String str(JsonObject o, String key) {
        if (o == null || !o.has(key) || o.get(key).isJsonNull()) return "";
        return o.get(key).getAsString();
    }

    /** Safely read a boolean member, returning false when missing. */
    public static boolean bool(JsonObject o, String key) {
        if (o == null || !o.has(key) || o.get(key).isJsonNull()) return false;
        return o.get(key).getAsBoolean();
    }

    /** Safely read an int member, returning 0 when missing. */
    public static int Int(JsonObject o, String key) {
        if (o == null || !o.has(key) || o.get(key).isJsonNull()) return 0;
        try { return o.get(key).getAsInt(); } catch (Exception e) { return 0; }
    }

    /** Safely read a long member, returning 0 when missing. */
    public static long lon(JsonObject o, String key) {
        if (o == null || !o.has(key) || o.get(key).isJsonNull()) return 0L;
        try { return o.get(key).getAsLong(); } catch (Exception e) { return 0L; }
    }

    /** Escape a string for safe embedding inside a JSON string literal. */
    public static String esc(String s) {
        if (s == null) return "";
        return GSON.toJson(s); // returns "..." with proper escaping
    }
}
