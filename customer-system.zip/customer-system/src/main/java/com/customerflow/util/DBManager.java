package com.customerflow.util;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * DBManager — the single JDBC/SQLite access layer for CustomerFlow.
 *
 * Storage layout
 * --------------
 *   Database file : <dbPath>  (default C:/CustomerFlow/customerflow.db)
 *                   Override with JVM property: -Dcustomerflow.db.path=/your/path.db
 *
 * Tables
 * ------
 *   entries   — relational table for every customer entry (high volume, SQL-queryable)
 *   exits     — relational table for every customer exit  (high volume, SQL-queryable)
 *   app_data  — key/value store (section TEXT PK, content TEXT) holding the rich
 *               nested JSON config: settings, passwords, floors, messages,
 *               employees, call_state.
 *
 * Why a hybrid?
 *   The high-volume transactional rows (entries/exits) live in real relational
 *   tables so reports can use SQL filtering/counting. The deeply-nested config
 *   (settings with wayOfSources, returnReasons, network, autoBackup ...) is kept
 *   as JSON documents inside app_data — this preserves 100% feature parity with
 *   the original single-file app while still being genuine JDBC + SQLite.
 */
public final class DBManager {

    private static String dbPath;
    private static String dbDirPath;

    private DBManager() {}

    /** Initialise the DB path + create schema. Called once by AppBootstrapListener. */
    public static synchronized void init(String configuredPath) {
        // JVM property overrides web.xml config
        String path = System.getProperty("customerflow.db.path");
        if (path == null || path.trim().isEmpty()) path = configuredPath;
        if (path == null || path.trim().isEmpty()) path = "C:/CustomerFlow/customerflow.db";

        // Normalise Windows backslashes
        dbPath = path.replace('\\', '/');
        File f = new File(dbPath);
        dbDirPath = f.getParent();
        if (dbDirPath != null && !dbDirPath.isEmpty()) {
            new File(dbDirPath).mkdirs();
        }
        createSchema();
    }

    public static String getDbPath() { return dbPath; }
    public static String getDbDirPath() { return dbDirPath; }

    /** Open a fresh JDBC connection. SQLite auto-creates the file on first connect. */
    public static Connection conn() throws SQLException {
        try {
            Class.forName("org.sqlite.JDBC");
        } catch (ClassNotFoundException e) {
            throw new SQLException("SQLite JDBC driver not found on classpath", e);
        }
        Connection c = DriverManager.getConnection("jdbc:sqlite:" + dbPath);
        try (Statement st = c.createStatement()) {
            // Speed up SQLite writes — fine for single-process web app
            st.execute("PRAGMA journal_mode=WAL");
            st.execute("PRAGMA synchronous=NORMAL");
        }
        return c;
    }

    /** Create all tables if they do not exist, and migrate older schemas. */
    private static void createSchema() {
        try (Connection c = conn(); Statement st = c.createStatement()) {
            st.execute(
                "CREATE TABLE IF NOT EXISTS entries (" +
                "  id INTEGER PRIMARY KEY," +
                "  floor TEXT, category TEXT, way_of_source TEXT," +
                "  timestamp INTEGER, date TEXT, time TEXT, hour INTEGER," +
                "  branch TEXT, employee TEXT, shift TEXT)"
            );
            st.execute(
                "CREATE TABLE IF NOT EXISTS exits (" +
                "  id INTEGER PRIMARY KEY," +
                "  floor TEXT, type TEXT, reason TEXT, comment TEXT," +
                "  mobile TEXT, image TEXT, purchase_source TEXT," +
                "  return_way_of_entry TEXT," +
                "  timestamp INTEGER, date TEXT, time TEXT," +
                "  branch TEXT, employee TEXT, shift TEXT)"
            );
            st.execute(
                "CREATE TABLE IF NOT EXISTS app_data (" +
                "  section TEXT PRIMARY KEY, content TEXT)"
            );
            st.execute(
                "CREATE TABLE IF NOT EXISTS employees (" +
                "  floor TEXT PRIMARY KEY, name TEXT, shift TEXT, ts INTEGER)"
            );
            // Migration: add purchase_source column to pre-v3.1 exits tables
            try {
                st.execute("ALTER TABLE exits ADD COLUMN purchase_source TEXT");
            } catch (SQLException migrationIgnored) {
                // column already exists — fine
            }
            // v3.5: add return_way_of_entry column to pre-v3.5 exits tables
            try {
                st.execute("ALTER TABLE exits ADD COLUMN return_way_of_entry TEXT");
            } catch (SQLException migrationIgnored) {
                // column already exists — fine
            }
            // Helpful indexes for report filtering
            st.execute("CREATE INDEX IF NOT EXISTS idx_entries_floor ON entries(floor)");
            st.execute("CREATE INDEX IF NOT EXISTS idx_entries_date ON entries(date)");
            st.execute("CREATE INDEX IF NOT EXISTS idx_exits_floor ON exits(floor)");
            st.execute("CREATE INDEX IF NOT EXISTS idx_exits_date ON exits(date)");
            st.execute("CREATE INDEX IF NOT EXISTS idx_exits_type ON exits(type)");
            st.execute("CREATE INDEX IF NOT EXISTS idx_exits_reason ON exits(reason)");
            st.execute("CREATE INDEX IF NOT EXISTS idx_exits_psource ON exits(purchase_source)");
        } catch (SQLException e) {
            throw new RuntimeException("Failed to initialise SQLite schema at " + dbPath, e);
        }
    }

    // ====================================================================
    //  app_data (key/value JSON) helpers
    // ====================================================================

    public static String readSection(String section) {
        try (Connection c = conn();
             PreparedStatement ps = c.prepareStatement("SELECT content FROM app_data WHERE section=?")) {
            ps.setString(1, section);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getString("content") : null;
            }
        } catch (SQLException e) {
            throw new RuntimeException("readSection(" + section + ") failed", e);
        }
    }

    public static void writeSection(String section, String content) {
        try (Connection c = conn();
             PreparedStatement ps = c.prepareStatement(
                 "INSERT INTO app_data(section,content) VALUES(?,?) " +
                 "ON CONFLICT(section) DO UPDATE SET content=excluded.content")) {
            ps.setString(1, section);
            ps.setString(2, content);
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("writeSection(" + section + ") failed", e);
        }
    }

    public static JsonObject readSectionObject(String section) {
        String s = readSection(section);
        if (s == null || s.trim().isEmpty()) return new JsonObject();
        return JsonUtil.parseObject(s);
    }

    public static JsonArray readSectionArray(String section) {
        String s = readSection(section);
        if (s == null || s.trim().isEmpty()) return new JsonArray();
        return JsonUtil.parseArray(s);
    }

    public static boolean hasSection(String section) {
        return readSection(section) != null;
    }

    // ====================================================================
    //  Setup / config
    // ====================================================================

    public static boolean isSetupComplete() {
        return hasSection("settings") && hasSection("passwords") && hasSection("floors");
    }

    public static JsonObject getSettings() { return readSectionObject("settings"); }
    public static void saveSettings(JsonObject s) { writeSection("settings", s.toString()); }

    public static JsonObject getPasswords() { return readSectionObject("passwords"); }
    public static void savePasswords(JsonObject p) { writeSection("passwords", p.toString()); }

    public static JsonArray getFloors() { return readSectionArray("floors"); }
    public static void saveFloors(JsonArray f) { writeSection("floors", f.toString()); }

    public static JsonArray getMessages() { return readSectionArray("messages"); }
    public static void saveMessages(JsonArray m) { writeSection("messages", m.toString()); }

    public static JsonObject getCallState() { return readSectionObject("call_state"); }
    public static void saveCallState(JsonObject cs) { writeSection("call_state", cs.toString()); }
    public static void clearCallState() {
        try (Connection c = conn();
             PreparedStatement ps = c.prepareStatement("DELETE FROM app_data WHERE section='call_state'")) {
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("clearCallState failed", e);
        }
    }

    // ====================================================================
    //  Auth helpers
    // ====================================================================

    public static boolean verifyPassword(String role, String password) {
        if (password == null || password.trim().isEmpty()) return false;
        JsonObject p = getPasswords();
        if (!p.has(role) || p.get(role).isJsonNull()) {
            // Dashboard defaults to "Elive" when not set
            if ("dashboard".equals(role) && "Elive".equals(password)) return true;
            return false;
        }
        String actual = p.get(role).getAsString();
        if (actual == null || actual.trim().isEmpty()) {
            if ("dashboard".equals(role) && "Elive".equals(password)) return true;
            return false;
        }
        return actual.equals(password);
    }

    public static boolean verifyFloorPin(String floor, String pin) {
        if (floor == null || pin == null || floor.trim().isEmpty() || pin.trim().isEmpty()) return false;
        for (var fe : getFloors()) {
            JsonObject f = fe.getAsJsonObject();
            if (floor.equals(JsonUtil.str(f, "name")) && pin.equals(JsonUtil.str(f, "pin"))) {
                return true;
            }
        }
        return false;
    }

    // ====================================================================
    //  Entries
    // ====================================================================

    public static void addEntry(JsonObject e) {
        try (Connection c = conn();
             PreparedStatement ps = c.prepareStatement(
                 "INSERT INTO entries(id,floor,category,way_of_source,timestamp,date,time,hour,branch,employee,shift) " +
                 "VALUES(?,?,?,?,?,?,?,?,?,?,?)")) {
            ps.setLong(1, JsonUtil.lon(e, "id"));
            ps.setString(2, JsonUtil.str(e, "floor"));
            ps.setString(3, JsonUtil.str(e, "category"));
            ps.setString(4, JsonUtil.str(e, "wayOfSource"));
            ps.setLong(5, JsonUtil.lon(e, "timestamp"));
            ps.setString(6, JsonUtil.str(e, "date"));
            ps.setString(7, JsonUtil.str(e, "time"));
            ps.setInt(8, JsonUtil.Int(e, "hour"));
            ps.setString(9, JsonUtil.str(e, "branch"));
            ps.setString(10, JsonUtil.str(e, "employee"));
            ps.setString(11, JsonUtil.str(e, "shift"));
            ps.executeUpdate();
        } catch (SQLException ex) {
            throw new RuntimeException("addEntry failed", ex);
        }
    }

    public static JsonArray getEntries() {
        JsonArray out = new JsonArray();
        try (Connection c = conn();
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery("SELECT * FROM entries ORDER BY timestamp DESC")) {
            while (rs.next()) {
                JsonObject e = new JsonObject();
                e.addProperty("id", rs.getLong("id"));
                e.addProperty("floor", nz(rs.getString("floor")));
                e.addProperty("category", nz(rs.getString("category")));
                e.addProperty("wayOfSource", nz(rs.getString("way_of_source")));
                e.addProperty("timestamp", rs.getLong("timestamp"));
                e.addProperty("date", nz(rs.getString("date")));
                e.addProperty("time", nz(rs.getString("time")));
                e.addProperty("hour", rs.getInt("hour"));
                e.addProperty("branch", nz(rs.getString("branch")));
                e.addProperty("employee", nz(rs.getString("employee")));
                e.addProperty("shift", nz(rs.getString("shift")));
                out.add(e);
            }
        } catch (SQLException ex) {
            throw new RuntimeException("getEntries failed", ex);
        }
        return out;
    }

    // ====================================================================
    //  Exits
    // ====================================================================

    public static void addExit(JsonObject x) {
        try (Connection c = conn();
             PreparedStatement ps = c.prepareStatement(
                 "INSERT INTO exits(id,floor,type,reason,comment,mobile,image,purchase_source,return_way_of_entry,timestamp,date,time,branch,employee,shift) " +
                 "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)")) {
            ps.setLong(1, JsonUtil.lon(x, "id"));
            ps.setString(2, JsonUtil.str(x, "floor"));
            ps.setString(3, JsonUtil.str(x, "type"));
            ps.setString(4, JsonUtil.str(x, "reason"));
            ps.setString(5, JsonUtil.str(x, "comment"));
            ps.setString(6, JsonUtil.str(x, "mobile"));
            ps.setString(7, JsonUtil.str(x, "image"));
            ps.setString(8, JsonUtil.str(x, "purchaseSource"));
            ps.setString(9, JsonUtil.str(x, "returnWayOfEntry"));
            ps.setLong(10, JsonUtil.lon(x, "timestamp"));
            ps.setString(11, JsonUtil.str(x, "date"));
            ps.setString(12, JsonUtil.str(x, "time"));
            ps.setString(13, JsonUtil.str(x, "branch"));
            ps.setString(14, JsonUtil.str(x, "employee"));
            ps.setString(15, JsonUtil.str(x, "shift"));
            ps.executeUpdate();
        } catch (SQLException ex) {
            throw new RuntimeException("addExit failed", ex);
        }
    }

    public static JsonArray getExits() {
        JsonArray out = new JsonArray();
        try (Connection c = conn();
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery("SELECT * FROM exits ORDER BY timestamp DESC")) {
            while (rs.next()) {
                JsonObject x = new JsonObject();
                x.addProperty("id", rs.getLong("id"));
                x.addProperty("floor", nz(rs.getString("floor")));
                x.addProperty("type", nz(rs.getString("type")));
                x.addProperty("reason", nz(rs.getString("reason")));
                x.addProperty("comment", nz(rs.getString("comment")));
                x.addProperty("mobile", nz(rs.getString("mobile")));
                x.addProperty("image", nz(rs.getString("image")));
                String psrc = rs.getString("purchase_source");
                x.addProperty("purchaseSource", psrc == null ? "" : psrc);
                String rwoe = rs.getString("return_way_of_entry");
                x.addProperty("returnWayOfEntry", rwoe == null ? "" : rwoe);
                x.addProperty("timestamp", rs.getLong("timestamp"));
                x.addProperty("date", nz(rs.getString("date")));
                x.addProperty("time", nz(rs.getString("time")));
                x.addProperty("branch", nz(rs.getString("branch")));
                x.addProperty("employee", nz(rs.getString("employee")));
                x.addProperty("shift", nz(rs.getString("shift")));
                out.add(x);
            }
        } catch (SQLException ex) {
            throw new RuntimeException("getExits failed", ex);
        }
        return out;
    }

    // ====================================================================
    //  Reset (clear entries + exits)
    // ====================================================================

    public static void clearEntriesExits() {
        try (Connection c = conn(); Statement st = c.createStatement()) {
            st.execute("DELETE FROM entries");
            st.execute("DELETE FROM exits");
        } catch (SQLException ex) {
            throw new RuntimeException("clearEntriesExits failed", ex);
        }
    }

    // ====================================================================
    //  Messages (with replies) — stored as JSON document in app_data
    // ====================================================================

    public static void addMessage(JsonObject m) {
        JsonArray msgs = getMessages();
        msgs.add(m);
        saveMessages(msgs);
    }

    public static void addReply(String msgId, String floor, String text) {
        JsonArray msgs = getMessages();
        for (int i = 0; i < msgs.size(); i++) {
            JsonObject m = msgs.get(i).getAsJsonObject();
            if (String.valueOf(JsonUtil.lon(m, "id")).equals(msgId) ||
                JsonUtil.str(m, "id").equals(msgId)) {
                JsonArray replies = m.has("replies") && m.get("replies").isJsonArray()
                    ? m.getAsJsonArray("replies") : new JsonArray();
                JsonObject r = new JsonObject();
                r.addProperty("floor", floor == null ? "" : floor);
                r.addProperty("text", text == null ? "" : text);
                replies.add(r);
                m.add("replies", replies);
                saveMessages(msgs);
                return;
            }
        }
        throw new RuntimeException("Message not found: " + msgId);
    }

    public static void clearMessages() {
        saveMessages(new JsonArray());
    }

    public static void deleteMessage(String msgId) {
        JsonArray msgs = getMessages();
        JsonArray out = new JsonArray();
        for (int i = 0; i < msgs.size(); i++) {
            JsonObject m = msgs.get(i).getAsJsonObject();
            String id = m.has("id") && m.get("id").isJsonPrimitive()
                ? m.get("id").getAsString() : "";
            if (!id.equals(msgId)) out.add(m);
        }
        saveMessages(out);
    }

    // ====================================================================
    //  Employees — relational table (one per floor)
    // ====================================================================

    public static void saveEmployee(String floor, String name, String shift) {
        try (Connection c = conn();
             PreparedStatement ps = c.prepareStatement(
                 "INSERT INTO employees(floor,name,shift,ts) VALUES(?,?,?,?) " +
                 "ON CONFLICT(floor) DO UPDATE SET name=excluded.name, shift=excluded.shift, ts=excluded.ts")) {
            ps.setString(1, floor);
            ps.setString(2, name);
            ps.setString(3, shift);
            ps.setLong(4, System.currentTimeMillis());
            ps.executeUpdate();
        } catch (SQLException ex) {
            throw new RuntimeException("saveEmployee failed", ex);
        }
    }

    public static JsonObject getEmployee(String floor) {
        try (Connection c = conn();
             PreparedStatement ps = c.prepareStatement("SELECT * FROM employees WHERE floor=?")) {
            ps.setString(1, floor);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    JsonObject o = new JsonObject();
                    o.addProperty("floor", nz(rs.getString("floor")));
                    o.addProperty("name", nz(rs.getString("name")));
                    o.addProperty("shift", nz(rs.getString("shift")));
                    o.addProperty("timestamp", rs.getLong("ts"));
                    return o;
                }
            }
        } catch (SQLException ex) {
            throw new RuntimeException("getEmployee failed", ex);
        }
        return new JsonObject();
    }

    public static JsonArray getEmployees() {
        JsonArray out = new JsonArray();
        try (Connection c = conn();
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery("SELECT * FROM employees")) {
            while (rs.next()) {
                JsonObject o = new JsonObject();
                o.addProperty("floor", nz(rs.getString("floor")));
                o.addProperty("name", nz(rs.getString("name")));
                o.addProperty("shift", nz(rs.getString("shift")));
                o.addProperty("timestamp", rs.getLong("ts"));
                out.add(o);
            }
        } catch (SQLException ex) {
            throw new RuntimeException("getEmployees failed", ex);
        }
        return out;
    }

    // ====================================================================
    //  Call state (WebRTC signalling) — JSON doc in app_data
    // ====================================================================

    public static void updateCallSignal(String type, String data) {
        JsonObject cs = getCallState();
        if (cs == null || cs.size() == 0) throw new RuntimeException("No active call");
        JsonObject sig = JsonUtil.parseObject(data);
        cs.add(type, sig);
        if ("answer".equals(type)) cs.addProperty("status", "connected");
        saveCallState(cs);
    }

    // ====================================================================
    //  getData — assemble the full document the frontend expects
    // ====================================================================

    public static JsonObject getDataForFrontend() {
        JsonObject root = new JsonObject();
        root.add("floors", getFloors());
        root.add("entries", getEntries());
        root.add("exits", getExits());
        root.add("messages", getMessages());
        root.add("employees", getEmployees());
        root.add("settings", getSettings());
        // passwords intentionally stripped — frontend must never see them
        root.add("passwords", new JsonObject());
        return root;
    }

    // ====================================================================
    //  Snapshot (backup / restore)
    // ====================================================================

    public static JsonObject exportSnapshot() {
        JsonObject snap = new JsonObject();
        snap.add("floors", getFloors());
        snap.add("entries", getEntries());
        snap.add("exits", getExits());
        snap.add("messages", getMessages());
        snap.add("employees", getEmployees());
        snap.add("settings", getSettings());
        snap.add("passwords", getPasswords());
        return snap;
    }

    public static void importSnapshot(JsonObject snap) {
        if (snap.has("floors")) saveFloors(snap.getAsJsonArray("floors"));
        if (snap.has("settings")) saveSettings(snap.getAsJsonObject("settings"));
        if (snap.has("passwords")) savePasswords(snap.getAsJsonObject("passwords"));
        if (snap.has("messages")) saveMessages(snap.getAsJsonArray("messages"));
        if (snap.has("employees")) {
            // Replace employees table
            try (Connection c = conn(); Statement st = c.createStatement()) {
                st.execute("DELETE FROM employees");
            } catch (SQLException ignored) {}
            for (var e : snap.getAsJsonArray("employees")) {
                JsonObject o = e.getAsJsonObject();
                saveEmployee(JsonUtil.str(o, "floor"), JsonUtil.str(o, "name"), JsonUtil.str(o, "shift"));
            }
        }
        if (snap.has("entries")) {
            try (Connection c = conn(); Statement st = c.createStatement()) { st.execute("DELETE FROM entries"); } catch (SQLException ignored) {}
            for (var e : snap.getAsJsonArray("entries")) addEntry(e.getAsJsonObject());
        }
        if (snap.has("exits")) {
            try (Connection c = conn(); Statement st = c.createStatement()) { st.execute("DELETE FROM exits"); } catch (SQLException ignored) {}
            for (var x : snap.getAsJsonArray("exits")) addExit(x.getAsJsonObject());
        }
    }

    /**
     * Import a v2 flowdata.json document (the format the original single-file
     * JSP app used). Top-level keys: floors, entries, exits, messages,
     * employees, settings, passwords, hoData. Migration-safe: picks up
     * existing settings fields and adds the new v3.1 defaults
     * (enablePurchaseSource, purchaseSources) if missing.
     *
     * Returns a small summary object: {entries, exits, floors, ...}
     */
    public static JsonObject importFromFlowData(JsonObject fd) {
        JsonObject summary = new JsonObject();
        // Floors
        if (fd.has("floors") && fd.get("floors").isJsonArray()) {
            saveFloors(fd.getAsJsonArray("floors"));
            summary.addProperty("floors", fd.getAsJsonArray("floors").size());
        }
        // Settings — migrate to ensure v3.2 fields exist
        if (fd.has("settings") && fd.get("settings").isJsonObject()) {
            JsonObject s = fd.getAsJsonObject("settings");
            // Ensure new v3.1 toggles + lists exist
            if (!s.has("enablePurchaseSource")) s.addProperty("enablePurchaseSource", false);
            if (!s.has("purchaseSources") || !s.get("purchaseSources").isJsonArray()) {
                s.add("purchaseSources", defaultPurchaseSources());
            }
            // v3.5: return way-of-entry (shown when customer returns)
            if (!s.has("enableReturnWayOfEntry")) s.addProperty("enableReturnWayOfEntry", false);
            if (!s.has("returnWayOfEntries") || !s.get("returnWayOfEntries").isJsonArray()) {
                s.add("returnWayOfEntries", defaultReturnWayOfEntries());
            }
            // v3.2: migrate autoBackup to time-based (daily at HH:MM) — drop interval
            if (s.has("autoBackup") && s.get("autoBackup").isJsonObject()) {
                JsonObject ab = s.getAsJsonObject("autoBackup");
                if (!ab.has("time") || JsonUtil.str(ab, "time").isEmpty()) {
                    ab.addProperty("time", "02:00");
                }
                // Remove legacy interval field (no longer used — only daily time-based backup)
                ab.remove("interval");
            } else {
                JsonObject ab = new JsonObject();
                ab.addProperty("enabled", true);
                ab.addProperty("time", "02:00");
                ab.addProperty("retentionDays", 10);
                s.add("autoBackup", ab);
            }
            if (!s.has("version")) s.addProperty("version", "3.5.0");
            saveSettings(s);
            summary.addProperty("settings", true);
        }
        // Passwords
        if (fd.has("passwords") && fd.get("passwords").isJsonObject()) {
            savePasswords(fd.getAsJsonObject("passwords"));
            summary.addProperty("passwords", true);
        }
        // Messages
        if (fd.has("messages") && fd.get("messages").isJsonArray()) {
            saveMessages(fd.getAsJsonArray("messages"));
            summary.addProperty("messages", fd.getAsJsonArray("messages").size());
        }
        // Employees (clear + re-insert)
        try (Connection c = conn(); Statement st = c.createStatement()) {
            st.execute("DELETE FROM employees");
        } catch (SQLException ignored) {}
        int empCount = 0;
        if (fd.has("employees") && fd.get("employees").isJsonArray()) {
            for (var e : fd.getAsJsonArray("employees")) {
                JsonObject o = e.getAsJsonObject();
                saveEmployee(JsonUtil.str(o, "floor"), JsonUtil.str(o, "name"), JsonUtil.str(o, "shift"));
                empCount++;
            }
        }
        summary.addProperty("employees", empCount);
        // Entries (clear + re-insert)
        try (Connection c = conn(); Statement st = c.createStatement()) { st.execute("DELETE FROM entries"); } catch (SQLException ignored) {}
        int entryCount = 0;
        if (fd.has("entries") && fd.get("entries").isJsonArray()) {
            for (var e : fd.getAsJsonArray("entries")) {
                addEntry(e.getAsJsonObject());
                entryCount++;
            }
        }
        summary.addProperty("entries", entryCount);
        // Exits (clear + re-insert)
        try (Connection c = conn(); Statement st = c.createStatement()) { st.execute("DELETE FROM exits"); } catch (SQLException ignored) {}
        int exitCount = 0;
        if (fd.has("exits") && fd.get("exits").isJsonArray()) {
            for (var x : fd.getAsJsonArray("exits")) {
                addExit(x.getAsJsonObject());
                exitCount++;
            }
        }
        summary.addProperty("exits", exitCount);
        return summary;
    }

    /** v3.5: Default return way-of-entry list (shown when a customer returns). */
    public static JsonArray defaultReturnWayOfEntries() {
        JsonArray arr = new JsonArray();
        String[][] defaults = {
            {"Same Day Return", "fa-rotate-left"},
            {"Next Day Return", "fa-clock-rotate-left"},
            {"Within Week", "fa-calendar-week"},
            {"Others", "fa-ellipsis"}
        };
        for (String[] d : defaults) {
            JsonObject o = new JsonObject();
            o.addProperty("name", d[0]);
            o.addProperty("icon", d[1]);
            o.addProperty("customEnabled", "Others".equals(d[0]));
            o.addProperty("enabled", true);
            arr.add(o);
        }
        return arr;
    }

    /** Default purchase-source list (mirrors the default way-of-sources list). */
    public static JsonArray defaultPurchaseSources() {
        JsonArray arr = new JsonArray();
        String[][] defaults = {
            {"Direct Purchase", "fa-store"},
            {"Online Order Pickup", "fa-box"},
            {"Phone Order", "fa-phone"},
            {"WhatsApp Order", "fa-whatsapp"},
            {"Referral Purchase", "fa-user-group"},
            {"Others", "fa-ellipsis"}
        };
        for (String[] d : defaults) {
            JsonObject o = new JsonObject();
            o.addProperty("name", d[0]);
            o.addProperty("icon", d[1]);
            o.addProperty("customEnabled", "Others".equals(d[0]));
            o.addProperty("enabled", true);
            arr.add(o);
        }
        return arr;
    }

    /**
     * Build a hierarchical tree view of all data: floor -> entries/exits ->
     * categories/reasons/sources -> counts. Returned as a JSON tree the
     * frontend can render with expand/collapse.
     */
    public static JsonObject getTreeView(String dateFilter) {
        JsonObject tree = new JsonObject();
        tree.addProperty("filterDate", dateFilter == null ? "" : dateFilter);
        JsonArray floorsNode = new JsonArray();

        JsonArray floors = getFloors();
        JsonArray entries = getEntries();
        JsonArray exits = getExits();

        for (var fe : floors) {
            String floorName = JsonUtil.str(fe.getAsJsonObject(), "name");
            JsonObject fNode = new JsonObject();
            fNode.addProperty("name", floorName);
            fNode.addProperty("type", "floor");

            // Entries for this floor (filtered by date if provided)
            int entryCount = 0;
            JsonObject entryCats = new JsonObject(); // category -> count
            for (var ee : entries) {
                JsonObject e = ee.getAsJsonObject();
                if (!floorName.equals(JsonUtil.str(e, "floor"))) continue;
                if (dateFilter != null && !dateFilter.isEmpty() && !dateFilter.equals(JsonUtil.str(e, "date"))) continue;
                entryCount++;
                String cat = JsonUtil.str(e, "category");
                if (cat.isEmpty()) cat = "(uncategorised)";
                entryCats.addProperty(cat, entryCats.has(cat) ? entryCats.get(cat).getAsInt() + 1 : 1);
            }
            fNode.addProperty("entries", entryCount);

            // Exits for this floor
            int exitCount = 0;
            int purchaseCount = 0;
            int returnCount = 0;
            JsonObject purchaseSources = new JsonObject();
            JsonObject returnReasons = new JsonObject();
            for (var xe : exits) {
                JsonObject x = xe.getAsJsonObject();
                if (!floorName.equals(JsonUtil.str(x, "floor"))) continue;
                if (dateFilter != null && !dateFilter.isEmpty() && !dateFilter.equals(JsonUtil.str(x, "date"))) continue;
                exitCount++;
                String type = JsonUtil.str(x, "type");
                if ("Purchase".equals(type)) {
                    purchaseCount++;
                    String psrc = JsonUtil.str(x, "purchaseSource");
                    if (psrc.isEmpty()) psrc = "(unspecified)";
                    purchaseSources.addProperty(psrc, purchaseSources.has(psrc) ? purchaseSources.get(psrc).getAsInt() + 1 : 1);
                } else if ("Return".equals(type)) {
                    returnCount++;
                    String reason = JsonUtil.str(x, "reason");
                    if (reason.isEmpty()) reason = "(no reason)";
                    returnReasons.addProperty(reason, returnReasons.has(reason) ? returnReasons.get(reason).getAsInt() + 1 : 1);
                }
            }
            fNode.addProperty("exits", exitCount);
            fNode.addProperty("inStore", Math.max(0, entryCount - exitCount));
            fNode.addProperty("purchases", purchaseCount);
            fNode.addProperty("returns", returnCount);
            fNode.add("entryCategories", entryCats);
            fNode.add("purchaseSources", purchaseSources);
            fNode.add("returnReasons", returnReasons);
            floorsNode.add(fNode);
        }
        tree.add("floors", floorsNode);
        return tree;
    }

    private static String nz(String s) { return s == null ? "" : s; }
}
