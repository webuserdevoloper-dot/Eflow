package com.customerflow.util;

import com.google.gson.JsonObject;

import jakarta.servlet.ServletContext;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

/**
 * BackupManager — writes JSON snapshots of the SQLite database to disk.
 *
 * Backup layout (relative to the deployed webapp root, unless an absolute
 * path is configured in settings.backupLocation):
 *
 *   backups/
 *     backup_YYYYMMDD_HHmmss.json        <- manual backups
 *     preReset_YYYYMMDD_HHmmss.json      <- automatic safety backup before a reset
 *     autobackup/
 *       DD-MM-YYYY/
 *         backup_YYYYMMDD_HHmmss.json    <- automatic periodic backups
 *
 * Retention: auto-backup day-folders older than settings.backupRetentionDays
 * are deleted on each auto-backup run.
 */
public final class BackupManager {

    private static Timer autoTimer;
    private static ServletContext ctx;

    private BackupManager() {}

    public static void init(ServletContext context) {
        ctx = context;
    }

    /** Resolve the backup root dir from settings (may be absolute or webapp-relative). */
    public static File resolveBackupDir() {
        JsonObject settings = DBManager.getSettings();
        String loc = JsonUtil.str(settings, "backupLocation");
        if (loc.isEmpty()) loc = "backups";
        if (loc.matches("^[A-Za-z]:[\\\\/].*") || loc.startsWith("/")) {
            return new File(loc);
        }
        String real = ctx != null ? ctx.getRealPath("/") : new File(".").getAbsolutePath();
        return new File(real, loc.isEmpty() ? "backups" : loc);
    }

    /** Manual backup -> backups/backup_*.json */
    public static String manualBackup() {
        File dir = resolveBackupDir();
        if (!dir.exists()) dir.mkdirs();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd_HHmmss");
        String ts = sdf.format(new Date());
        File f = new File(dir, "backup_" + ts + ".json");
        int c = 1;
        while (f.exists()) { f = new File(dir, "backup_" + ts + "_" + c + ".json"); c++; }
        writeSnapshot(f);
        return "Backup successful";
    }

    /** Safety backup taken just before a data reset. */
    public static String preResetBackup() {
        try {
            File dir = resolveBackupDir();
            if (!dir.exists()) dir.mkdirs();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd_HHmmss");
            File f = new File(dir, "preReset_" + sdf.format(new Date()) + ".json");
            int c = 1;
            while (f.exists()) { f = new File(dir, "preReset_" + sdf.format(new Date()) + "_" + c + ".json"); c++; }
            writeSnapshot(f);
        } catch (Exception ignored) {}
        return "ok";
    }

    /** Auto backup -> backups/autobackup/DD-MM-YYYY/backup_*.json (+ retention cleanup). */
    public static void autoBackup() {
        try {
            File root = resolveBackupDir();
            File autoRoot = new File(root, "autobackup");
            if (!autoRoot.exists()) autoRoot.mkdirs();

            // retention cleanup
            int retentionDays = 10;
            JsonObject settings = DBManager.getSettings();
            if (settings.has("autoBackup") && settings.get("autoBackup").isJsonObject()) {
                JsonObject ab = settings.getAsJsonObject("autoBackup");
                if (ab.has("retentionDays")) retentionDays = ab.get("retentionDays").getAsInt();
            }
            if (settings.has("backupRetentionDays")) {
                try { retentionDays = settings.get("backupRetentionDays").getAsInt(); } catch (Exception ignored) {}
            }
            long cutoff = System.currentTimeMillis() - (retentionDays * 24L * 60 * 60 * 1000);
            File[] dayFolders = autoRoot.listFiles(File::isDirectory);
            if (dayFolders != null) {
                for (File day : dayFolders) {
                    if (day.lastModified() < cutoff) deleteDir(day);
                }
            }

            SimpleDateFormat dayFmt = new SimpleDateFormat("dd-MM-yyyy");
            File dayDir = new File(autoRoot, dayFmt.format(new Date()));
            if (!dayDir.exists()) dayDir.mkdirs();
            SimpleDateFormat timeFmt = new SimpleDateFormat("yyyyMMdd_HHmmss");
            File f = new File(dayDir, "backup_" + timeFmt.format(new Date()) + ".json");
            int c = 1;
            while (f.exists()) { f = new File(dayDir, "backup_" + timeFmt.format(new Date()) + "_" + c + ".json"); c++; }
            writeSnapshot(f);
        } catch (Exception ignored) {}
    }

    private static void writeSnapshot(File f) {
        try {
            JsonObject snap = DBManager.exportSnapshot();
            snap.addProperty("_backupTime", System.currentTimeMillis());
            snap.addProperty("_backupType", f.getName().startsWith("preReset") ? "preReset" : "backup");
            Files.write(f.toPath(), snap.toString().getBytes(StandardCharsets.UTF_8));
        } catch (Exception e) {
            throw new RuntimeException("Backup write failed: " + e.getMessage(), e);
        }
    }

    /**
     * Start (or restart) the auto-backup timer based on current settings.
     *
     * v3.2: Auto-backup is now TIME-BASED (runs daily at a set time, e.g.
     * "02:00"). The old interval-based mode (every N minutes) is no longer
     * used — only the daily scheduled backup runs automatically. Manual
     * backups (admin button) and pre-reset safety backups still work on
     * demand but are never scheduled.
     *
     * Settings.autoBackup format:
     *   { enabled: true, time: "02:00", retentionDays: 10 }
     *   (legacy "interval" field is ignored if present)
     */
    public static synchronized void startAutoTimer() {
        stopAutoTimer();
        JsonObject settings = DBManager.getSettings();
        if (!settings.has("autoBackup")) return;
        JsonObject ab = settings.getAsJsonObject("autoBackup");
        if (!JsonUtil.bool(ab, "enabled")) return;

        // Parse the daily backup time (default 02:00)
        String timeStr = JsonUtil.str(ab, "time");
        if (timeStr.isEmpty()) timeStr = "02:00";
        int[] hm = parseTime(timeStr);
        int hour = hm[0];
        int minute = hm[1];

        // Schedule the first run for today at HH:MM (or tomorrow if already passed)
        java.util.Calendar cal = java.util.Calendar.getInstance();
        cal.set(java.util.Calendar.HOUR_OF_DAY, hour);
        cal.set(java.util.Calendar.MINUTE, minute);
        cal.set(java.util.Calendar.SECOND, 0);
        cal.set(java.util.Calendar.MILLISECOND, 0);
        if (cal.getTimeInMillis() <= System.currentTimeMillis()) {
            cal.add(java.util.Calendar.DAY_OF_MONTH, 1);
        }
        java.util.Date firstRun = cal.getTime();
        long period = 24L * 60 * 60 * 1000; // 24 hours (daily)

        autoTimer = new Timer("CF-AutoBackup", true);
        autoTimer.scheduleAtFixedRate(new TimerTask() {
            public void run() { try { autoBackup(); } catch (Exception ignored) {} }
        }, firstRun, period);

        // Log next run time
        try {
            ctx.log("CustomerFlow: auto-backup scheduled daily at " + timeStr +
                    ". Next run: " + firstRun);
        } catch (Exception ignored) {}
    }

    /** Parse "HH:MM" (24-hour) into [hour, minute]. Falls back to 02:00 on error. */
    private static int[] parseTime(String s) {
        try {
            String[] parts = s.trim().split(":");
            int h = Integer.parseInt(parts[0]);
            int m = parts.length > 1 ? Integer.parseInt(parts[1]) : 0;
            if (h < 0 || h > 23) h = 2;
            if (m < 0 || m > 59) m = 0;
            return new int[]{h, m};
        } catch (Exception e) {
            return new int[]{2, 0}; // default 02:00
        }
    }

    public static synchronized void stopAutoTimer() {
        if (autoTimer != null) { try { autoTimer.cancel(); } catch (Exception ignored) {} autoTimer = null; }
    }

    private static void deleteDir(File f) {
        if (f.isDirectory()) {
            File[] kids = f.listFiles();
            if (kids != null) for (File k : kids) deleteDir(k);
        }
        f.delete();
    }
}
