package com.customerflow.listener;

import com.customerflow.util.BackupManager;
import com.customerflow.util.DBManager;

import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletContextEvent;
import jakarta.servlet.ServletContextListener;

import java.io.File;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;

/**
 * Runs once when Tomcat deploys the webapp:
 *   1. If no SQLite DB exists at the configured path, seed it from the bundled
 *      prebuilt DB (WEB-INF/classes/customerflow.db) — this ships the user's
 *      existing data inside the WAR so first start is ready-to-go.
 *   2. Initialises the SQLite database (creates schema if needed, runs
 *      migrations on existing DBs).
 *   3. Wires BackupManager with the servlet context.
 *   4. Starts the auto-backup timer if the system is already set up.
 *
 * The DB path comes from web.xml (context-param "dbPath") and can be
 * overridden with the JVM property -Dcustomerflow.db.path=/your/path.db
 */
public class AppBootstrapListener implements ServletContextListener {

    /** Resource path of the prebuilt DB shipped inside the WAR. */
    private static final String PREBUILT_DB_RESOURCE = "/WEB-INF/classes/customerflow.db";

    @Override
    public void contextInitialized(ServletContextEvent sce) {
        ServletContext ctx = sce.getServletContext();
        String configured = ctx.getInitParameter("dbPath");

        // JVM property overrides web.xml
        String path = System.getProperty("customerflow.db.path");
        if (path == null || path.trim().isEmpty()) path = configured;
        if (path == null || path.trim().isEmpty()) path = "C:/CustomerFlow/customerflow.db";
        path = path.replace('\\', '/');

        File targetFile = new File(path);
        File targetDir = targetFile.getParentFile();
        if (targetDir != null && !targetDir.exists()) targetDir.mkdirs();

        // If the target DB doesn't exist yet, seed it from the prebuilt DB
        // shipped inside the WAR (so the user's existing data is there on
        // first start). If no prebuilt DB is bundled, DBManager.init() will
        // create a fresh empty one.
        if (!targetFile.exists()) {
            String realPath = ctx.getRealPath(PREBUILT_DB_RESOURCE);
            File prebuiltFile = realPath != null ? new File(realPath) : null;
            boolean seeded = false;
            if (prebuiltFile != null && prebuiltFile.exists()) {
                try {
                    Files.copy(prebuiltFile.toPath(), targetFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
                    seeded = true;
                    ctx.log("CustomerFlow: seeded DB from bundled prebuilt (" + prebuiltFile.length() + " bytes).");
                } catch (Exception e) {
                    ctx.log("CustomerFlow: prebuilt seed copy failed, will create fresh DB: " + e.getMessage());
                }
            } else {
                // Try as a classpath resource stream (some configs don't expose real paths)
                try (InputStream in = ctx.getResourceAsStream(PREBUILT_DB_RESOURCE)) {
                    if (in != null) {
                        Files.copy(in, targetFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
                        seeded = true;
                        ctx.log("CustomerFlow: seeded DB from classpath resource.");
                    }
                } catch (Exception e) {
                    ctx.log("CustomerFlow: prebuilt seed via stream failed: " + e.getMessage());
                }
            }
            if (!seeded) {
                ctx.log("CustomerFlow: no prebuilt DB found — a fresh empty DB will be created.");
            }
        }

        DBManager.init(configured);
        BackupManager.init(ctx);

        ctx.log("CustomerFlow v3.1: SQLite database ready at " + DBManager.getDbPath());

        if (DBManager.isSetupComplete()) {
            BackupManager.startAutoTimer();
            ctx.log("CustomerFlow: auto-backup timer started. Setup complete.");
        } else {
            ctx.log("CustomerFlow: setup not yet complete — visit /setup.jsp to configure.");
        }
    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) {
        BackupManager.stopAutoTimer();
    }
}
