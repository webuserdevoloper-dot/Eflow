package com.customerflow.servlet;

import com.customerflow.util.BackupManager;
import com.customerflow.util.DBManager;
import com.customerflow.util.JsonUtil;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.annotation.MultipartConfig;

import java.io.IOException;
import java.io.PrintWriter;

/**
 * ApiServlet — the single API endpoint that backs the CustomerFlow frontend.
 *
 * URL:  /api?action=<action>[&...params]
 *
 * Every action the original index.jsp scriptlet handled is implemented here
 * using the SQLite/JDBC layer (DBManager). Session-based auth is used with a
 * password-parameter fallback so the app keeps working across IPs/hosts where
 * the session cookie may not be sent.
 *
 * Actions
 *   getData, auth, getPasswords, savePasswords, getFloorsWithPins, updateFloors,
 *   saveSettings, entry, exit, addMessage, addReply, clearMessages,
 *   deleteMessage, saveEmployee, getEmployee, adminCallFloor, getCallState,
 *   saveCallSignal, endCall, backup, reset
 */
@MultipartConfig(
    maxFileSize = -1,    // -1 = unlimited file size
    maxRequestSize = -1, // -1 = unlimited request size
    fileSizeThreshold = 0 // 0 = always stream, never buffer to disk
)
public class ApiServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        handle(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        handle(req, resp);
    }

    @Override
    protected void doOptions(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        setCorsHeaders(req, resp);
        resp.setStatus(200);
    }

    private void handle(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        setCorsHeaders(req, resp);
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        resp.setHeader("Cache-Control", "no-cache,no-store,must-revalidate");
        resp.setHeader("Pragma", "no-cache");
        PrintWriter out = resp.getWriter();

        try {
            String action = req.getParameter("action");
            if (action == null) {
                // No action -> serve a friendly status object (keeps /api GET browser-testable)
                out.print("{\"name\":\"Customer-System API\",\"status\":\"running\",\"db\":\"" + DBManager.getDbPath() + "\",\"setupComplete\":" + DBManager.isSetupComplete() + "}");
                return;
            }

            switch (action) {
                case "getData":          handleGetData(req, resp, out); break;
                case "auth":             handleAuth(req, resp, out); break;
                case "getPasswords":     handleGetPasswords(req, resp, out); break;
                case "savePasswords":    handleSavePasswords(req, resp, out); break;
                case "getFloorsWithPins":handleGetFloorsWithPins(req, resp, out); break;
                case "updateFloors":     handleUpdateFloors(req, resp, out); break;
                case "saveSettings":     handleSaveSettings(req, resp, out); break;
                case "entry":            handleEntry(req, resp, out); break;
                case "exit":             handleExit(req, resp, out); break;
                case "addMessage":       handleAddMessage(req, resp, out); break;
                case "addReply":         handleAddReply(req, resp, out); break;
                case "clearMessages":    handleClearMessages(req, resp, out); break;
                case "deleteMessage":    handleDeleteMessage(req, resp, out); break;
                case "saveEmployee":     handleSaveEmployee(req, resp, out); break;
                case "getEmployee":      handleGetEmployee(req, resp, out); break;
                case "adminCallFloor":   handleAdminCallFloor(req, resp, out); break;
                case "getCallState":     handleGetCallState(req, resp, out); break;
                case "saveCallSignal":   handleSaveCallSignal(req, resp, out); break;
                case "endCall":          handleEndCall(out); break;
                case "backup":           handleBackup(out); break;
                case "reset":            handleReset(req, resp, out); break;
                case "importData":       handleImportData(req, resp, out); break;
                case "getTree":          handleGetTree(req, resp, out); break;
                default:
                    out.print("{\"error\":\"Unknown action: " + action + "\"}");
            }
        } catch (AuthException ae) {
            out.print("{\"error\":\"Unauthorized\"}");
        } catch (Exception e) {
            out.print("{\"error\":\"Backend Exception: " + esc(e.getMessage()) + "\"}");
        }
        out.flush();
    }

    // ============================================================= getData
    private void handleGetData(HttpServletRequest req, HttpServletResponse resp, PrintWriter out) {
        if (!DBManager.isSetupComplete()) {
            out.print("{\"setupRequired\":true}");
            return;
        }
        JsonObject data = DBManager.getDataForFrontend();
        out.print(data.toString());
    }

    // ============================================================= auth
    private void handleAuth(HttpServletRequest req, HttpServletResponse resp, PrintWriter out) {
        String type = req.getParameter("type");
        String pass = req.getParameter("password");
        HttpSession session = req.getSession(true);

        if ("loginFloor".equals(type)) {
            String floor = req.getParameter("floor");
            if (DBManager.verifyFloorPin(floor, pass)) {
                session.setAttribute("currentFloor", floor);
                out.print("{\"status\":\"success\"}");
            } else {
                out.print("{\"status\":\"error\",\"message\":\"Wrong PIN\"}");
            }
            return;
        }

        if (DBManager.verifyPassword(type, pass)) {
            session.setAttribute("auth_" + type, true);
            if ("admin".equals(type)) session.setAttribute("isAdmin", true);
            if ("floorMgmt".equals(type)) {
                // Return floors data inline (cross-IP fix — avoids a second call)
                JsonObject resp2 = new JsonObject();
                resp2.addProperty("status", "success");
                resp2.add("floors", DBManager.getFloors());
                out.print(resp2.toString());
            } else {
                out.print("{\"status\":\"success\"}");
            }
        } else {
            out.print("{\"status\":\"error\",\"message\":\"Wrong Password\"}");
        }
    }

    // ============================================================= passwords
    private void handleGetPasswords(HttpServletRequest req, HttpServletResponse resp, PrintWriter out) {
        if (!isAuth(req, "passMgr")) {
            out.print("{\"error\":\"Unauthorized\"}");
            return;
        }
        out.print(DBManager.getPasswords().toString());
    }

    private void handleSavePasswords(HttpServletRequest req, HttpServletResponse resp, PrintWriter out) {
        if (!isAuth(req, "passMgr")) {
            out.print("{\"error\":\"Unauthorized\"}");
            return;
        }
        JsonObject p = new JsonObject();
        p.addProperty("admin", p(req, "admin"));
        p.addProperty("dashboard", p(req, "dashboard"));
        p.addProperty("floorMgmt", p(req, "floorMgmt"));
        p.addProperty("backup", p(req, "backup"));
        p.addProperty("clear", p(req, "clear"));
        p.addProperty("passMgr", p(req, "passMgr"));
        p.addProperty("ho", p(req, "ho"));
        DBManager.savePasswords(p);
        out.print("{\"status\":\"success\"}");
    }

    // ============================================================= floors
    private void handleGetFloorsWithPins(HttpServletRequest req, HttpServletResponse resp, PrintWriter out) {
        if (!isFloorMgmtOrAdmin(req)) {
            out.print("{\"error\":\"Unauthorized\"}");
            return;
        }
        JsonObject o = new JsonObject();
        o.add("floors", DBManager.getFloors());
        out.print(o.toString());
    }

    private void handleUpdateFloors(HttpServletRequest req, HttpServletResponse resp, PrintWriter out) {
        if (!isFloorMgmtOrAdmin(req)) {
            out.print("{\"error\":\"Unauthorized\"}");
            return;
        }
        String floorsJson = req.getParameter("floors");
        JsonArray floors = JsonUtil.parseArray(floorsJson);
        DBManager.saveFloors(floors);
        out.print("{\"status\":\"success\"}");
    }

    // ============================================================= settings
    private void handleSaveSettings(HttpServletRequest req, HttpServletResponse resp, PrintWriter out) {
        if (!isAdminOrDashboard(req)) {
            out.print("{\"error\":\"Unauthorized\"}");
            return;
        }
        String settingsJson = req.getParameter("settings");
        if (settingsJson == null || !settingsJson.trim().startsWith("{")) {
            out.print("{\"error\":\"Invalid settings data\"}");
            return;
        }
        JsonObject settings = JsonUtil.parseObject(settingsJson);
        DBManager.saveSettings(settings);
        // Restart auto-backup timer if autoBackup config changed
        BackupManager.startAutoTimer();
        out.print("{\"status\":\"success\"}");
    }

    // ============================================================= entry / exit
    private void handleEntry(HttpServletRequest req, HttpServletResponse resp, PrintWriter out) {
        ensureFloorAuth(req);
        String data = req.getParameter("data");
        JsonObject e = JsonUtil.parseObject(data);
        DBManager.addEntry(e);
        out.print("{\"status\":\"success\"}");
    }

    private void handleExit(HttpServletRequest req, HttpServletResponse resp, PrintWriter out) {
        ensureFloorAuth(req);
        String data = req.getParameter("data");
        JsonObject x = JsonUtil.parseObject(data);
        DBManager.addExit(x);
        out.print("{\"status\":\"success\"}");
    }

    // ============================================================= messages
    private void handleAddMessage(HttpServletRequest req, HttpServletResponse resp, PrintWriter out) {
        ensureAdmin(req);
        String data = req.getParameter("data");
        JsonObject m = JsonUtil.parseObject(data);
        DBManager.addMessage(m);
        out.print("{\"status\":\"success\"}");
    }

    private void handleAddReply(HttpServletRequest req, HttpServletResponse resp, PrintWriter out) {
        String msgId = req.getParameter("msgId");
        String text = req.getParameter("text");
        String floor = req.getParameter("floor");
        HttpSession session = req.getSession(false);
        if (floor == null && session != null) floor = (String) session.getAttribute("currentFloor");
        if (floor == null || session == null || session.getAttribute("currentFloor") == null) {
            // cross-IP fallback — verify floor PIN
            String flrParam = req.getParameter("floor");
            String pinParam = req.getParameter("pin");
            if (!DBManager.verifyFloorPin(flrParam, pinParam)) {
                out.print("{\"error\":\"Unauthorized\"}");
                return;
            }
            floor = flrParam;
        }
        DBManager.addReply(msgId, floor, text);
        out.print("{\"status\":\"success\"}");
    }

    private void handleClearMessages(HttpServletRequest req, HttpServletResponse resp, PrintWriter out) {
        ensureAdmin(req);
        DBManager.clearMessages();
        out.print("{\"status\":\"success\"}");
    }

    private void handleDeleteMessage(HttpServletRequest req, HttpServletResponse resp, PrintWriter out) {
        ensureAdmin(req);
        String msgId = req.getParameter("msgId");
        DBManager.deleteMessage(msgId);
        out.print("{\"status\":\"success\"}");
    }

    // ============================================================= employees
    private void handleSaveEmployee(HttpServletRequest req, HttpServletResponse resp, PrintWriter out) {
        ensureFloorAuth(req);
        String floor = req.getParameter("floor");
        String name = req.getParameter("name");
        String shift = req.getParameter("shift");
        DBManager.saveEmployee(floor, name, shift);
        out.print("{\"status\":\"success\"}");
    }

    private void handleGetEmployee(HttpServletRequest req, HttpServletResponse resp, PrintWriter out) {
        String floor = req.getParameter("floor");
        out.print(DBManager.getEmployee(floor).toString());
    }

    // ============================================================= WebRTC call
    private void handleAdminCallFloor(HttpServletRequest req, HttpServletResponse resp, PrintWriter out) {
        ensureAdmin(req);
        String floor = req.getParameter("floor");
        JsonObject cs = new JsonObject();
        cs.addProperty("floor", floor == null ? "" : floor);
        cs.addProperty("status", "ringing");
        cs.addProperty("startTime", System.currentTimeMillis());
        cs.add("offer", new JsonObject());
        cs.add("answer", new JsonObject());
        DBManager.saveCallState(cs);
        out.print("{\"status\":\"success\"}");
    }

    private void handleGetCallState(HttpServletRequest req, HttpServletResponse resp, PrintWriter out) {
        JsonObject cs = DBManager.getCallState();
        if (cs == null || cs.size() == 0) {
            out.print("{\"status\":\"none\"}");
        } else {
            out.print(cs.toString());
        }
    }

    private void handleSaveCallSignal(HttpServletRequest req, HttpServletResponse resp, PrintWriter out) {
        String type = req.getParameter("type");
        String data = req.getParameter("data");
        DBManager.updateCallSignal(type, data);
        out.print("{\"status\":\"success\"}");
    }

    private void handleEndCall(PrintWriter out) {
        DBManager.clearCallState();
        out.print("{\"status\":\"success\"}");
    }

    // ============================================================= backup / reset
    private void handleBackup(PrintWriter out) {
        String msg = BackupManager.manualBackup();
        out.print("{\"status\":\"" + msg + "\"}");
    }

    private void handleReset(HttpServletRequest req, HttpServletResponse resp, PrintWriter out) {
        if (!isAuth(req, "clear")) {
            out.print("{\"error\":\"Unauthorized\"}");
            return;
        }
        BackupManager.preResetBackup();
        DBManager.clearEntriesExits();
        out.print("{\"status\":\"success\"}");
    }

    // ============================================================= importData (v2 flowdata.json -> SQLite)
    private void handleImportData(HttpServletRequest req, HttpServletResponse resp, PrintWriter out) {
        ensureAdmin(req);
        try {
            // v3.10: Read raw POST body (text/plain) — no multipart parsing, no size limits
            String json = null;
            // First try: raw body (text/plain content type from frontend)
            String contentType = req.getContentType();
            if (contentType != null && (contentType.contains("text/plain") || contentType.contains("application/json"))) {
                byte[] bodyBytes = req.getInputStream().readAllBytes();
                json = new String(bodyBytes, java.nio.charset.StandardCharsets.UTF_8);
            }
            // Fallback: try getParameter (for form-urlencoded or query string)
            if (json == null || json.trim().isEmpty()) {
                json = req.getParameter("data");
            }
            if (json == null || json.trim().isEmpty()) {
                out.print("{\"error\":\"No data provided\"}");
                return;
            }
            JsonObject fd = JsonUtil.parseObject(json);
            JsonObject summary = DBManager.importFromFlowData(fd);
            out.print("{\"status\":\"success\",\"summary\":" + summary.toString() + "}");
        } catch (Exception e) {
            out.print("{\"error\":\"Import failed: " + esc(e.getMessage()) + "\"}");
        }
    }

    // ============================================================= getTree (hierarchical tree view data)
    private void handleGetTree(HttpServletRequest req, HttpServletResponse resp, PrintWriter out) {
        if (!isAdminOrDashboard(req)) {
            out.print("{\"error\":\"Unauthorized\"}");
            return;
        }
        String dateFilter = req.getParameter("date");
        if (dateFilter == null) dateFilter = "";
        JsonObject tree = DBManager.getTreeView(dateFilter);
        out.print(tree.toString());
    }

    // ============================================================= auth helpers
    private boolean isAuth(HttpServletRequest req, String role) {
        HttpSession s = req.getSession(false);
        if (s != null && Boolean.TRUE.equals(s.getAttribute("auth_" + role))) return true;
        // password-param fallback
        String pwd = req.getParameter("password");
        if (pwd == null || pwd.isEmpty()) pwd = req.getParameter("authPassword");
        return pwd != null && !pwd.isEmpty() && DBManager.verifyPassword(role, pwd);
    }

    private boolean isFloorMgmtOrAdmin(HttpServletRequest req) {
        HttpSession s = req.getSession(false);
        if (s != null && (Boolean.TRUE.equals(s.getAttribute("auth_floorMgmt")) || Boolean.TRUE.equals(s.getAttribute("isAdmin")))) return true;
        String pwd = req.getParameter("password");
        if (pwd == null || pwd.isEmpty()) pwd = req.getParameter("authPassword");
        if (pwd != null && !pwd.isEmpty()) {
            return DBManager.verifyPassword("floorMgmt", pwd) || DBManager.verifyPassword("admin", pwd);
        }
        return false;
    }

    private boolean isAdminOrDashboard(HttpServletRequest req) {
        HttpSession s = req.getSession(false);
        if (s != null && (Boolean.TRUE.equals(s.getAttribute("isAdmin")) || Boolean.TRUE.equals(s.getAttribute("auth_dashboard")))) return true;
        String pwd = req.getParameter("authPassword");
        if (pwd == null || pwd.isEmpty()) pwd = req.getParameter("password");
        if (pwd != null && !pwd.isEmpty()) {
            return DBManager.verifyPassword("admin", pwd) || DBManager.verifyPassword("dashboard", pwd);
        }
        return false;
    }

    private void ensureAdmin(HttpServletRequest req) {
        HttpSession s = req.getSession(false);
        if (s != null && Boolean.TRUE.equals(s.getAttribute("isAdmin"))) return;
        String pwd = req.getParameter("authPassword");
        if (pwd == null || pwd.isEmpty()) pwd = req.getParameter("password");
        if (pwd != null && !pwd.isEmpty() && DBManager.verifyPassword("admin", pwd)) return;
        throw new AuthException();
    }

    private void ensureFloorAuth(HttpServletRequest req) {
        HttpSession s = req.getSession(false);
        if (s != null && s.getAttribute("currentFloor") != null) return;
        String floor = req.getParameter("floor");
        String pin = req.getParameter("pin");
        if (DBManager.verifyFloorPin(floor, pin)) return;
        throw new AuthException();
    }

    // ============================================================= utils
    private void setCorsHeaders(HttpServletRequest req, HttpServletResponse resp) {
        String origin = req.getHeader("Origin");
        if (origin == null || origin.trim().isEmpty()) origin = "*";
        resp.setHeader("Access-Control-Allow-Origin", origin);
        resp.setHeader("Vary", "Origin");
        resp.setHeader("Access-Control-Allow-Methods", "GET,POST,OPTIONS,HEAD");
        resp.setHeader("Access-Control-Allow-Headers", "Content-Type,X-Requested-With,Authorization,X-API-Key");
        resp.setHeader("Access-Control-Allow-Credentials", "true");
        resp.setHeader("Access-Control-Max-Age", "3600");
        resp.setHeader("Permissions-Policy", "storage=*,cookies=*,camera=self,microphone=self");
        resp.setHeader("X-Content-Type-Options", "nosniff");
        resp.setHeader("X-Frame-Options", "SAMEORIGIN");
        resp.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
    }

    private static String p(HttpServletRequest req, String key) {
        String v = req.getParameter(key);
        return v == null ? "" : v;
    }

    private static String esc(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", " ").replace("\r", " ");
    }

    /** Internal signal for auth failure. */
    private static class AuthException extends RuntimeException {

        private static final long serialVersionUID = 1L;
    }
}
