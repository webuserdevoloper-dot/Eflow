package com.customerflow.servlet;

import com.customerflow.util.BackupManager;
import com.customerflow.util.DBManager;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

/**
 * SetupServlet — handles the initial system configuration (replaces the old
 * setup.jsp scriptlet). On POST it creates default floors, default settings,
 * and the passwords block inside the SQLite database, then redirects to the
 * login page.
 *
 * If the system is already configured, GET shows a "already configured" page.
 */
public class SetupServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("text/html;charset=UTF-8");
        if (DBManager.isSetupComplete()) {
            resp.getWriter().print(alreadyConfiguredHtml());
            return;
        }
        // Forward to the setup.jsp UI
        req.getRequestDispatcher("/setup.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        String admin = p(req, "admin", "Eadmin@3377");
        String floorMgmt = p(req, "floorMgmt", "Efloor@3377");
        String backup = p(req, "backup", "Ebackup@3377");
        String clear = p(req, "clear", "Eclear@3377");
        String passMgr = p(req, "passMgr", "2200");
        String ho = p(req, "ho", "EHO@3377");
        String dashboard = p(req, "dashboard", "Elive");
        String defaultPin = p(req, "defaultPin", "2003");

        // Default 16 floors matching the original system
        JsonArray floors = new JsonArray();
        String[] floorNames = {
            "SST-BASEMENT", "SST-GROUND-F-FRONT", "SST-GROUND-F-BACK",
            "SST-1ST", "SST-2ND", "SST-3RD", "SST-4TH", "SST-5TH",
            "ELITE-BASEMENT", "ELITE-GROUND-F-FRONT", "ELITE-GROUND-F-BACK",
            "ELITE-1ST", "ELITE-2ND", "ELITE-3RD",
            "DIAMOND-FRONT-ENTRANCE", "DIAMOND-BACK-ENTRANCE"
        };
        for (String n : floorNames) {
            JsonObject f = new JsonObject();
            f.addProperty("name", n);
            f.addProperty("pin", defaultPin);
            floors.add(f);
        }

        // Default way of sources
        JsonArray wayOfSources = new JsonArray();
        wayOfSources.add(src("Direct Visit", "fa-store", false, true));
        wayOfSources.add(src("Social Media", "fa-share-nodes", false, true));
        wayOfSources.add(src("Advertisement / Newspaper", "fa-newspaper", false, true));
        wayOfSources.add(src("Referral", "fa-user-group", false, true));
        wayOfSources.add(src("Others", "fa-ellipsis", true, true));

        // Default return reasons
        JsonArray returnReasons = new JsonArray();
        returnReasons.add(reason("High Wastage", "fa-money-bill-wave"));
        returnReasons.add(reason("Design Not Satisfied", "fa-pen-ruler"));
        returnReasons.add(reason("Just Visit", "fa-eye"));
        returnReasons.add(reason("Other", "fa-ellipsis"));

        // Settings
        JsonObject settings = new JsonObject();
        settings.addProperty("companyName", "CustomerFlow");
        settings.addProperty("logo", "");
        settings.addProperty("primaryColor", "#ec4899");
        settings.addProperty("companyFont", "'Bricolage Grotesque', sans-serif");
        settings.addProperty("entryColor", "#0ea5e9");
        settings.addProperty("exitColor", "#10b981");
        settings.addProperty("version", "3.5.0");
        settings.addProperty("developer", "Sathish");
        JsonObject network = new JsonObject();
        network.addProperty("mode", "HO");
        network.addProperty("branchName", "HO");
        network.addProperty("hoUrl", "");
        network.add("branchUrls", new JsonArray());
        settings.add("network", network);
        JsonObject autoBackup = new JsonObject();
        autoBackup.addProperty("enabled", true);
        autoBackup.addProperty("time", "02:00");
        autoBackup.addProperty("retentionDays", 10);
        settings.add("autoBackup", autoBackup);
        settings.addProperty("backupLocation", "backups");
        settings.addProperty("backupRetentionDays", 10);
        settings.addProperty("enableEmployeeName", false);
        settings.addProperty("enableAdminCall", false);
        settings.addProperty("enableIcons", true);
        settings.addProperty("enableEntrySound", true);
        settings.addProperty("enableExitSound", true);
        settings.addProperty("enableWayOfSource", true);
        settings.addProperty("enableNewUI", true);
        // v3.1: purchase source flow (4th step in exit when type=Purchase)
        settings.addProperty("enablePurchaseSource", false);
        settings.add("purchaseSources", DBManager.defaultPurchaseSources());
        // v3.5: return way-of-entry (shown when customer returns)
        settings.addProperty("enableReturnWayOfEntry", false);
        settings.add("returnWayOfEntries", DBManager.defaultReturnWayOfEntries());
        JsonArray dashAccess = new JsonArray();
        dashAccess.add("dashboard");
        settings.add("dashboardAccess", dashAccess);
        settings.add("wayOfSources", wayOfSources);
        settings.add("returnReasons", returnReasons);

        // Passwords
        JsonObject passwords = new JsonObject();
        passwords.addProperty("admin", admin);
        passwords.addProperty("dashboard", dashboard);
        passwords.addProperty("floorMgmt", floorMgmt);
        passwords.addProperty("backup", backup);
        passwords.addProperty("clear", clear);
        passwords.addProperty("passMgr", passMgr);
        passwords.addProperty("ho", ho);

        // Write everything to SQLite
        DBManager.saveSettings(settings);
        DBManager.savePasswords(passwords);
        DBManager.saveFloors(floors);
        DBManager.saveMessages(new JsonArray());

        // Start the auto-backup timer now that setup is complete
        BackupManager.startAutoTimer();

        resp.sendRedirect("index.jsp");
    }

    private static JsonObject src(String name, String icon, boolean custom, boolean enabled) {
        JsonObject o = new JsonObject();
        o.addProperty("name", name);
        o.addProperty("icon", icon);
        o.addProperty("customEnabled", custom);
        o.addProperty("enabled", enabled);
        return o;
    }

    private static JsonObject reason(String name, String icon) {
        JsonObject o = new JsonObject();
        o.addProperty("name", name);
        o.addProperty("commentEnabled", false);
        o.addProperty("imageEnabled", false);
        o.addProperty("mobileEnabled", false);
        o.addProperty("mobileRequired", false);
        o.addProperty("required", false);
        o.addProperty("icon", icon);
        return o;
    }

    private static String p(HttpServletRequest req, String key, String def) {
        String v = req.getParameter(key);
        return (v == null || v.trim().isEmpty()) ? def : v.trim();
    }

    private static String alreadyConfiguredHtml() {
        return "<div style='text-align:center;padding:50px;font-family:sans-serif;color:#333;background:#0a0a0f;height:100vh;display:flex;align-items:center;justify-content:center;'>" +
            "<div style='background:#13131a;border:1px solid #2f2f3a;padding:40px;border-radius:16px;display:inline-block;box-shadow:0 20px 60px rgba(0,0,0,0.6);'>" +
            "<h2 style='color:#10b981;margin:0 0 8px;'>CustomerFlow v3.0 — Already Configured</h2>" +
            "<p style='color:#a1a1aa;'>To reconfigure, delete the SQLite database file at:<br><code style='background:#26262f;color:#f472b6;padding:4px 8px;border-radius:6px;'>" + DBManager.getDbPath() + "</code></p><br>" +
            "<a href='index.jsp' style='background:linear-gradient(to right,#f43f5e,#14b8a6);color:white;padding:12px 24px;border-radius:10px;text-decoration:none;display:inline-block;font-weight:700;'>Go to Login</a>" +
            "</div></div>";
    }
}
