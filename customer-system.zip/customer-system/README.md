# CustomerFlow 3.1 — Onyx Pro | Tomcat + Maven + JDBC + SQLite

A professional, multi-floor **customer entry / exit flow management system** rebuilt
from a single-file JSP into a proper **Maven web application** that runs on
**Apache Tomcat 10.1+** inside **Eclipse**, with a genuine **JDBC + SQLite**
backend. **CustomerFlow 3.1** introduces the Onyx Pro visual overhaul —
indigo (#6366f1) + amber (#f59e0b) + cyan palette on a deep midnight base, glassmorphism nav, and an
animated split-screen login — while preserving every feature of CustomerFlow 2.0.

All features from the original `index.jsp` / `setup.jsp` are preserved
(floor PIN login, customer entry/exit, admin & dashboard panels, live messaging
with replies, WebRTC admin→floor calling, floor management, password manager,
backup/restore, auto-backup, data reset, PDF/Excel export, filters, etc.).

---

## 1. Tech Stack

| Layer        | Technology                                      |
|--------------|-------------------------------------------------|
| Server       | Apache Tomcat 10.1+ (Jakarta EE 10)             |
| Build        | Maven (pom.xml → WAR)                           |
| Language     | Java 17 + JSP                                   |
| Database     | SQLite (via JDBC, `sqlite-jdbc` driver)         |
| JSON         | Gson                                            |
| UI           | Tailwind CDN + Font Awesome + vanilla JS        |
| IDE          | Eclipse (with m2e + WTP)                        |

---

## What's New in v3.1 (Onyx Pro)

- **全新 Onyx Pro 主题** — Indigo (#6366f1) + Amber (#f59e0b) + Cyan palette on deep midnight background
- **Split-screen login** — animated onyx hero panel + glassmorphism login card
- **Glassmorphism navigation** — frosted glass top bar + sidebar with backdrop-blur
- **Purchase Source flow** — new 4th step when a customer makes a purchase (Direct / Online / Phone / WhatsApp / Referral, fully configurable)
- **Tree Branch View** — hierarchical expandable tree showing floor → entries/exits → categories/sources/reasons with counts
- **Import Data tool** — upload an existing `flowdata.json` to migrate entries, exits and settings straight into SQLite
- **Updated icons & colors** — refreshed Font Awesome icons, cohesive color system
- **Maven badge** in footer alongside SQLite + Tomcat
- **Enhanced ambient lighting** — multi-layer radial gradients
- All v2.0 features preserved (21 API actions, WebRTC calling, live chat, PDF/Excel export, etc.)

---

## 2. Project Structure

```
customerflow/                          <- Eclipse project root (import this folder)
├── pom.xml                            <- Maven build (deps: servlet-api, sqlite-jdbc, gson)
├── .project / .classpath              <- Eclipse project files
├── .gitignore
├── README.md                          <- this file
├── src/main/java/com/customerflow/
│   ├── listener/
│   │   └── AppBootstrapListener.java  <- creates SQLite DB + schema + auto-backup timer on startup
│   ├── servlet/
│   │   ├── ApiServlet.java            <- /api  (ALL action handlers, JDBC-backed)
│   │   └── SetupServlet.java          <- /setup (initial system configuration)
│   └── util/
│       ├── DBManager.java             <- JDBC/SQLite access layer (schema + CRUD)
│       ├── BackupManager.java         <- JSON snapshot backups + auto-backup timer
│       └── JsonUtil.java              <- Gson helper
├── src/main/webapp/
│   ├── WEB-INF/
│   │   └── web.xml                    <- servlets, listener, DB path config
│   ├── index.jsp                      <- main app UI (entry/exit/admin/dashboard/…)
│   └── setup.jsp                      <- initial setup form (POSTs to /setup)
└── backups/                           <- runtime backups land here (auto-created)
```

### 3. Database & Storage Path

The SQLite database file is created automatically on first startup at:

```
C:\systemdata\customerflow.db        (Windows — default)
```

You can change it two ways:

1. **`web.xml`** → `<context-param><param-name>dbPath</param-name>`
2. **JVM property** (overrides web.xml):
   `-Dcustomerflow.db.path=/opt/customerflow/customerflow.db`

### Schema (created automatically)

```sql
CREATE TABLE entries (              -- customer entries (relational, SQL-queryable)
  id INTEGER PRIMARY KEY, floor TEXT, category TEXT, way_of_source TEXT,
  timestamp INTEGER, date TEXT, time TEXT, hour INTEGER,
  branch TEXT, employee TEXT, shift TEXT);

CREATE TABLE exits (                -- customer exits (relational)
  id INTEGER PRIMARY KEY, floor TEXT, type TEXT, reason TEXT, comment TEXT,
  mobile TEXT, image TEXT, timestamp INTEGER, date TEXT, time TEXT,
  branch TEXT, employee TEXT, shift TEXT);

CREATE TABLE employees (            -- one employee record per floor
  floor TEXT PRIMARY KEY, name TEXT, shift TEXT, ts INTEGER);

CREATE TABLE app_data (             -- JSON documents for nested config
  section TEXT PRIMARY KEY, content TEXT);
-- sections: settings, passwords, floors, messages, call_state
```

**Backups** are JSON snapshots exported to `backups/`:
- `backups/backup_YYYYMMDD_HHmmss.json` — manual backups
- `backups/preReset_YYYYMMDD_HHmmss.json` — safety backup before a reset
- `backups/autobackup/DD-MM-YYYY/backup_*.json` — auto backups (every 10 min, 10-day retention)

---

## 4. Prerequisites

1. **JDK 17+** — install and set `JAVA_HOME`.
2. **Apache Tomcat 10.1+** — download from https://tomcat.apache.org, extract somewhere
   e.g. `C:\apache-tomcat-10.1.x`. (Do **not** use Tomcat 9 — this project uses Jakarta EE 10.)
3. **Eclipse IDE for Enterprise Java & Web Developers** (includes m2e + WTP).
4. **Internet access** the first time you build (Maven downloads sqlite-jdbc + gson).

---

## 5. Run in Eclipse + Tomcat (Step by Step)

### Step 1 — Import the project
1. Eclipse → **File → Import…**
2. Choose **Maven → Existing Maven Projects** → Next.
3. **Root Directory** = the `customerflow` folder you unzipped.
4. The `pom.xml` appears checked → **Finish**.
5. Wait for Maven to download dependencies (progress in bottom-right).

### Step 2 — Add Tomcat to Eclipse (if not already added)
1. **Window → Preferences → Server → Runtime Environments → Add…**
2. Pick **Apache Tomcat v10.1** → point to your Tomcat install folder → Finish.

### Step 3 — Add the project to Tomcat
1. Bottom panel → **Servers** tab → right-click your Tomcat → **Add and Remove…**
2. Move `customerflow` from *Available* to *Configured* → **Finish**.

### Step 4 — (Optional) change the DB path
Edit `src/main/webapp/WEB-INF/web.xml` → `<param-value>` of `dbPath`,
or pass `-Dcustomerflow.db.path=...` as a VM argument in the server's
*Open launch configuration* dialog.

### Step 5 — Start Tomcat
1. In the **Servers** tab, click the green **Start** button (or right-click → Start).
2. Watch the **Console** tab — you should see:
   ```
   CustomerFlow: SQLite database ready at C:/systemdata/customerflow.db
   ```

### Step 6 — Open the app
1. Browser → `http://localhost:8080/customerflow/`
2. **First run only:** you are redirected to the **Setup** page. Fill the default
   PIN and the security passwords (defaults are pre-filled) → **Create Database & Setup System**.
3. You are sent back to the login page. Pick a floor → enter PIN (`2003` by default) → use the app.

---

## 6. Run from Command Line (without Eclipse)

```bash
# 1. Build the WAR
cd customerflow
mvn clean package
# -> target/customerflow.war

# 2. Deploy to Tomcat
copy target\customerflow.war  %TOMCAT_HOME%\webapps\

# 3. Start Tomcat
%TOMCAT_HOME%\bin\startup.bat        (Windows)
$TOMCAT_HOME/bin/startup.sh         (Linux/Mac)

# 4. Open
#    http://localhost:8080/customerflow/
```

To override the DB path on the command line:

```bash
# Linux/Mac
export CATALINA_OPTS="-Dcustomerflow.db.path=/opt/customerflow/customerflow.db"

# Windows
set CATALINA_OPTS=-Dcustomerflow.db.path=D:/data/customerflow.db
```

---

## 7. API Reference (ApiServlet — `POST/GET /api?action=…`)

| Action            | Auth                          | Purpose                                  |
|-------------------|-------------------------------|------------------------------------------|
| `getData`         | —                             | Full dataset (passwords/pins stripped)   |
| `auth`            | —                             | Login (`type` = loginFloor/admin/…)      |
| `getPasswords`    | passMgr                       | Read password block                      |
| `savePasswords`   | passMgr                       | Update password block                    |
| `getFloorsWithPins` | floorMgmt/admin             | Floors + PINs (management)               |
| `updateFloors`    | floorMgmt/admin               | Save floors list                         |
| `saveSettings`    | admin/dashboard               | Persist settings                         |
| `entry`           | floor session / floor PIN     | Record a customer entry                  |
| `exit`            | floor session / floor PIN     | Record a customer exit                   |
| `addMessage`      | admin                         | Admin broadcasts a message               |
| `addReply`        | floor session / floor PIN     | Floor replies to a message               |
| `clearMessages`   | admin                         | Clear all messages                       |
| `deleteMessage`   | admin                         | Delete one message + replies             |
| `saveEmployee`    | floor session / floor PIN     | Save floor employee info                 |
| `getEmployee`     | —                             | Get employee for a floor                 |
| `adminCallFloor`  | admin                         | Start a WebRTC call to a floor           |
| `getCallState`    | —                             | Poll call signalling state               |
| `saveCallSignal`  | —                             | Save WebRTC offer/answer                 |
| `endCall`         | —                             | End the active call                      |
| `backup`          | —                             | Manual JSON backup                       |
| `reset`           | clear                         | Clear all entries+exits (safety backup)  |

Session-based auth is used with a **password-parameter fallback** so the app keeps
working across IPs/hosts where the session cookie may not be sent.

---

## 8. Default Passwords (set on the Setup page — v3.1)

| Role            | Default          |
|-----------------|------------------|
| Floor PIN       | `2003`           |
| Admin           | `Eadmin@3377`    |
| Dashboard       | `Elive`          |
| Password Mgr    | `2200`           |
| Floor Mgmt      | `Efloor@3377`    |
| Backup          | `Ebackup@3377`   |
| Clear           | `Eclear@3377`    |
| HO/Branch       | `EHO@3377`       |

Change them all from the **Passwords** modal inside the Admin panel.

---

## 9. Reconfigure / Reset

- **Reconfigure from scratch:** stop Tomcat, delete
  `C:\systemdata\customerflow.db`, restart, visit `/customerflow/` → Setup page.
- **Clear entries/exits only:** Admin → **Clear** (takes a safety backup first).
- **Manual backup:** Admin → **Backup**.
- **Restore:** a backup `.json` is a full snapshot — to restore, stop Tomcat,
  delete `customerflow.db`, restart (re-runs Setup), then re-import the snapshot
  by replacing the `app_data` rows / entries / exits. (A one-click restore UI is
  a planned enhancement.)

---

## 10. Troubleshooting

| Symptom | Fix |
|---|---|
| `ClassNotFoundException: org.sqlite.JDBC` | Maven didn't fetch deps — right-click project → Maven → Update Project. |
| 404 on `/customerflow/` | Project not deployed to Tomcat — Servers tab → Add and Remove. |
| Blank page / setup loop | Delete `customerflow.db` and re-run Setup. |
| `C:\systemdata` not writable | Run Tomcat as admin, or change `dbPath` in web.xml to a writable folder. |
| "Not Secure" in address bar | Normal for HTTP. To remove, enable HTTPS on Tomcat (out of scope here). |
| Port 8080 in use | Edit Tomcat `conf/server.xml` or Eclipse server port. |

---

## 11. Features (all preserved from the original JSP)

- Floor selection + PIN login
- Customer **Entry** (with category + way-of-source) and **Exit** (Purchase / Return with reason, comment, image, mobile)
- Live **Today's Entries / In Store / Exits** counters
- **Admin panel**: dashboard report, entries report, exits report, "others" (return reasons) report, floor-wise summary, live chat
- **Dashboard panel** (separate login) for read-only reporting
- Filters: floor (multi-select), date mode (today/yesterday/custom/range/month/all), type, reason
- **PDF / Excel export** of any report
- **Floor management** (add/rename/reorder floors + PINs)
- **Password manager** (all 7 roles)
- **Backup / Restore** + **auto-backup** (configurable interval + retention)
- **Clear data** (with safety backup)
- **WebRTC admin → floor voice call** (offer/answer signalling via the API)
- **Live messaging** admin → floors with replies
- **Employee name/shift** capture per floor
- Customisable company name, logo, colours, fonts
- Cross-IP access support (CORS + storage polyfill)
- Professional dark neon theme, fully responsive

---

*CustomerFlow v3.1.0 Onyx Pro — Maven + Tomcat + JDBC + SQLite edition.*
